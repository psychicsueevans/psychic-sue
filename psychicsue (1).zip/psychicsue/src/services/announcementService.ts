import { supabase } from '@/lib/supabase';
import type { InsertAnnouncement, UpdateAnnouncement } from '@/types/admin.types';

export const announcementService = {
  // Get all announcements
  getAllAnnouncements: async () => {
    return await supabase
      .from('announcements')
      .select('*')
      .order('created_at', { ascending: false });
  },

  // Get announcement by ID
  getAnnouncementById: async (id: string) => {
    return await supabase
      .from('announcements')
      .select('*')
      .eq('id', id)
      .single();
  },

  // Get published announcements
  getPublishedAnnouncements: async () => {
    return await supabase
      .from('announcements')
      .select('*')
      .eq('is_published', true)
      .order('created_at', { ascending: false });
  },

  // Create new announcement
  createAnnouncement: async (announcement: InsertAnnouncement) => {
    return await supabase
      .from('announcements')
      .insert(announcement)
      .select()
      .single();
  },

  // Update announcement
  updateAnnouncement: async (id: string, updates: UpdateAnnouncement) => {
    return await supabase
      .from('announcements')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
  },

  // Delete announcement
  deleteAnnouncement: async (id: string) => {
    return await supabase
      .from('announcements')
      .delete()
      .eq('id', id);
  },

  // Publish announcement
  publishAnnouncement: async (id: string) => {
    return await supabase
      .from('announcements')
      .update({ is_published: true, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
  },

  // Unpublish announcement
  unpublishAnnouncement: async (id: string) => {
    return await supabase
      .from('announcements')
      .update({ is_published: false, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
  },

  // Mark announcement as sent
  markAsSent: async (id: string) => {
    return await supabase
      .from('announcements')
      .update({ 
        is_sent: true, 
        sent_at: new Date().toISOString(),
        updated_at: new Date().toISOString() 
      })
      .eq('id', id)
      .select()
      .single();
  }
};