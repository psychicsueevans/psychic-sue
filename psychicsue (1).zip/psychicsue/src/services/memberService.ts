import { supabase } from '../lib/supabase';
import { Member, ServiceResponse, MembershipTier } from '../types/admin.types';

export const memberService = {
  async getAllMembers(): Promise<ServiceResponse<Member[]>> {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getActiveMembers(): Promise<ServiceResponse<Member[]>> {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMembersByTier(tier: MembershipTier): Promise<ServiceResponse<Member[]>> {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .eq('membership_tier', tier)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMemberById(id: string): Promise<ServiceResponse<Member>> {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMemberStats(): Promise<ServiceResponse<{
    total: number;
    active: number;
    circle: number;
    vip: number;
  }>> {
    try {
      const { data, error } = await supabase
        .from('members')
        .select('id, is_active, membership_tier');

      if (error) throw error;

      const stats = {
        total: (data || []).length,
        active: (data || []).filter(m => m.is_active).length,
        circle: (data || []).filter(m => m.membership_tier === 'circle_member').length,
        vip: (data || []).filter(m => m.membership_tier === 'vip').length
      };

      return { data: stats, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  }
};