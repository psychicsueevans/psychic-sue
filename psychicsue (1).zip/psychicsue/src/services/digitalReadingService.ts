import { supabase } from '../lib/supabase';
import {
  DigitalReading,
  InsertDigitalReading,
  UpdateDigitalReading,
  ServiceResponse,
  ReadingCategory
} from '../types/admin.types';

export const digitalReadingService = {
  async getAllReadings(): Promise<ServiceResponse<DigitalReading[]>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .select('*')
        .order('card_number', { ascending: true });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getReadingsByCategory(category: ReadingCategory): Promise<ServiceResponse<DigitalReading[]>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .select('*')
        .eq('category', category)
        .order('card_number', { ascending: true });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getReadingById(id: string): Promise<ServiceResponse<DigitalReading>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getReadingByCardNumber(
    category: ReadingCategory,
    cardNumber: number
  ): Promise<ServiceResponse<DigitalReading>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .select('*')
        .eq('category', category)
        .eq('card_number', cardNumber)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async createReading(reading: InsertDigitalReading): Promise<ServiceResponse<DigitalReading>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .insert(reading)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateReading(id: string, updates: UpdateDigitalReading): Promise<ServiceResponse<DigitalReading>> {
    try {
      const { data, error } = await supabase
        .from('digital_readings')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteReading(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('digital_readings')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  }
};