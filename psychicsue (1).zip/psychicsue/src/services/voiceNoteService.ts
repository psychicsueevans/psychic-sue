import { supabase } from '@/lib/supabase';

export interface VoiceNote {
  id: string;
  member_id: string;
  audio_url: string;
  question_topic?: string;
  is_listened: boolean;
  created_at: string;
}

export interface CreateVoiceNoteInput {
  member_id: string;
  audio_url: string;
  question_topic?: string;
}

export const voiceNoteService = {
  /**
   * Upload audio file to Supabase Storage
   */
  async uploadAudioFile(file: File, memberId: string): Promise<{ data: { path: string } | null; error: Error | null }> {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${memberId}/${Date.now()}.${fileExt}`;

      const { data, error } = await supabase.storage
        .from('voice-notes')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (error) {
        return { data: null, error: new Error(error.message) };
      }

      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  /**
   * Get public URL for uploaded audio file
   */
  getAudioUrl(filePath: string): string {
    const { data } = supabase.storage
      .from('voice-notes')
      .getPublicUrl(filePath);

    return data.publicUrl;
  },

  /**
   * Create a new voice note record
   */
  async createVoiceNote(input: CreateVoiceNoteInput): Promise<{ data: VoiceNote | null; error: Error | null }> {
    try {
      const { data, error } = await supabase
        .from('voice_notes')
        .insert([
          {
            member_id: input.member_id,
            audio_url: input.audio_url,
            question_topic: input.question_topic || null,
            is_listened: false,
          },
        ])
        .select()
        .single();

      if (error) {
        return { data: null, error: new Error(error.message) };
      }

      return { data: data as VoiceNote, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  /**
   * Get all voice notes for a specific member
   */
  async getMemberVoiceNotes(memberId: string): Promise<{ data: VoiceNote[] | null; error: Error | null }> {
    try {
      const { data, error } = await supabase
        .from('voice_notes')
        .select('*')
        .eq('member_id', memberId)
        .order('created_at', { ascending: false });

      if (error) {
        return { data: null, error: new Error(error.message) };
      }

      return { data: data as VoiceNote[], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  /**
   * Mark a voice note as listened (admin function)
   */
  async markAsListened(voiceNoteId: string): Promise<{ data: VoiceNote | null; error: Error | null }> {
    try {
      const { data, error } = await supabase
        .from('voice_notes')
        .update({ is_listened: true })
        .eq('id', voiceNoteId)
        .select()
        .single();

      if (error) {
        return { data: null, error: new Error(error.message) };
      }

      return { data: data as VoiceNote, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  /**
   * Delete a voice note
   */
  async deleteVoiceNote(voiceNoteId: string): Promise<{ error: Error | null }> {
    try {
      const { error } = await supabase
        .from('voice_notes')
        .delete()
        .eq('id', voiceNoteId);

      if (error) {
        return { error: new Error(error.message) };
      }

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  },
};