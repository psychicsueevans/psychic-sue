import { supabase } from '@/lib/supabase';
import type { InsertBooking, UpdateBooking } from '@/types/admin.types';

export const bookingService = {
  // Get all bookings
  getAllBookings: async () => {
    return await supabase
      .from('bookings')
      .select('*, members(full_name, email, membership_tier)')
      .order('booking_date', { ascending: false });
  },

  // Get booking by ID
  getBookingById: async (id: string) => {
    return await supabase
      .from('bookings')
      .select('*, members(full_name, email, membership_tier)')
      .eq('id', id)
      .single();
  },

  // Get bookings by member ID
  getBookingsByMemberId: async (memberId: string) => {
    return await supabase
      .from('bookings')
      .select('*')
      .eq('member_id', memberId)
      .order('booking_date', { ascending: false });
  },

  // Get reading history for a member
  getReadingHistoryByMemberId: async (memberId: string) => {
    return await supabase
      .from('reading_history')
      .select('*')
      .eq('member_id', memberId)
      .order('reading_date', { ascending: false });
  },

  // Create new booking
  createBooking: async (booking: InsertBooking) => {
    return await supabase
      .from('bookings')
      .insert(booking)
      .select()
      .single();
  },

  // Update booking
  updateBooking: async (id: string, updates: UpdateBooking) => {
    return await supabase
      .from('bookings')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
  },

  // Delete booking
  deleteBooking: async (id: string) => {
    return await supabase
      .from('bookings')
      .delete()
      .eq('id', id);
  },

  // Get bookings by status
  getBookingsByStatus: async (status: string) => {
    return await supabase
      .from('bookings')
      .select('*, members(full_name, email, membership_tier)')
      .eq('status', status)
      .order('booking_date', { ascending: true });
  }
};