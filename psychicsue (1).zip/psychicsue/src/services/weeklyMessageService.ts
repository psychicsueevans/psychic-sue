import { supabase } from '../lib/supabase';
import {
  WeeklyMessage,
  InsertWeeklyMessage,
  UpdateWeeklyMessage,
  ServiceResponse
} from '../types/admin.types';

export const weeklyMessageService = {
  async getAllMessages(): Promise<ServiceResponse<WeeklyMessage[]>> {
    try {
      const { data, error } = await supabase
        .from('weekly_messages')
        .select('*')
        .order('published_date', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getCurrentMessage(): Promise<ServiceResponse<WeeklyMessage>> {
    try {
      const { data, error } = await supabase
        .from('weekly_messages')
        .select('*')
        .eq('is_current', true)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMessageById(id: string): Promise<ServiceResponse<WeeklyMessage>> {
    try {
      const { data, error } = await supabase
        .from('weekly_messages')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async createMessage(message: InsertWeeklyMessage): Promise<ServiceResponse<WeeklyMessage>> {
    try {
      const { data, error } = await supabase
        .from('weekly_messages')
        .insert(message)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateMessage(id: string, updates: UpdateWeeklyMessage): Promise<ServiceResponse<WeeklyMessage>> {
    try {
      const { data, error } = await supabase
        .from('weekly_messages')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteMessage(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('weekly_messages')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async setCurrentMessage(id: string): Promise<ServiceResponse<null>> {
    try {
      // First, unset all current messages
      const { error: unsetError } = await supabase
        .from('weekly_messages')
        .update({ is_current: false })
        .eq('is_current', true);

      if (unsetError) throw unsetError;

      // Then set the new current message
      const { error: setError } = await supabase
        .from('weekly_messages')
        .update({ is_current: true })
        .eq('id', id);

      if (setError) throw setError;

      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  }
};