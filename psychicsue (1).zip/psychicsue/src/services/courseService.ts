import { supabase } from '../lib/supabase';
import {
  CourseModule,
  CourseLesson,
  ModuleWithLessons,
  InsertCourseModule,
  UpdateCourseModule,
  InsertCourseLesson,
  UpdateCourseLesson,
  ContentStats,
  LessonProgress
} from '../types/course.types';

interface ServiceResponse<T> {
  data: T | null;
  error: Error | null;
}

export const courseService = {
  // Module Operations
  async getAllModules(): Promise<ServiceResponse<CourseModule[]>> {
    try {
      const { data, error } = await supabase
        .from('course_modules')
        .select('*')
        .order('order_position', { ascending: true });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getModulesWithLessons(): Promise<ServiceResponse<ModuleWithLessons[]>> {
    try {
      const { data: modules, error: moduleError } = await supabase
        .from('course_modules')
        .select('*')
        .order('order_position', { ascending: true });

      if (moduleError) throw moduleError;

      const { data: lessons, error: lessonError } = await supabase
        .from('course_lessons')
        .select('*')
        .order('order_position', { ascending: true });

      if (lessonError) throw lessonError;

      const modulesWithLessons: ModuleWithLessons[] = (modules || []).map((module) => ({
        ...module,
        lessons: (lessons || []).filter((lesson) => lesson.module_id === module.id),
        total_lessons: (lessons || []).filter((lesson) => lesson.module_id === module.id).length,
        published_lessons: (lessons || []).filter(
          (lesson) => lesson.module_id === module.id && lesson.is_published
        ).length,
      }));

      return { data: modulesWithLessons, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getModuleById(id: string): Promise<ServiceResponse<CourseModule>> {
    try {
      const { data, error } = await supabase
        .from('course_modules')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async createModule(module: InsertCourseModule): Promise<ServiceResponse<CourseModule>> {
    try {
      const { data, error } = await supabase
        .from('course_modules')
        .insert(module)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateModule(id: string, updates: UpdateCourseModule): Promise<ServiceResponse<CourseModule>> {
    try {
      const { data, error } = await supabase
        .from('course_modules')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteModule(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('course_modules')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async reorderModules(moduleIds: string[]): Promise<ServiceResponse<null>> {
    try {
      const updates = moduleIds.map((id, index) => ({
        id,
        order_position: index + 1,
      }));

      for (const update of updates) {
        const { error } = await supabase
          .from('course_modules')
          .update({ order_position: update.order_position })
          .eq('id', update.id);

        if (error) throw error;
      }

      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  // Lesson Operations
  async getLessonsByModuleId(moduleId: string): Promise<ServiceResponse<CourseLesson[]>> {
    try {
      const { data, error } = await supabase
        .from('course_lessons')
        .select('*')
        .eq('module_id', moduleId)
        .order('order_position', { ascending: true });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  // Alias method for better clarity - maps to getLessonsByModuleId
  async getLessonsByModule(moduleId: string): Promise<ServiceResponse<CourseLesson[]>> {
    return this.getLessonsByModuleId(moduleId);
  },

  async createLesson(lesson: InsertCourseLesson): Promise<ServiceResponse<CourseLesson>> {
    try {
      const { data, error } = await supabase
        .from('course_lessons')
        .insert(lesson)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateLesson(id: string, updates: UpdateCourseLesson): Promise<ServiceResponse<CourseLesson>> {
    try {
      const { data, error } = await supabase
        .from('course_lessons')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteLesson(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('course_lessons')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async reorderLessons(lessonIds: string[]): Promise<ServiceResponse<null>> {
    try {
      const updates = lessonIds.map((id, index) => ({
        id,
        order_position: index + 1,
      }));

      for (const update of updates) {
        const { error } = await supabase
          .from('course_lessons')
          .update({ order_position: update.order_position })
          .eq('id', update.id);

        if (error) throw error;
      }

      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  // Publishing Operations
  async publishModule(id: string): Promise<ServiceResponse<CourseModule>> {
    return this.updateModule(id, { is_published: true });
  },

  async unpublishModule(id: string): Promise<ServiceResponse<CourseModule>> {
    return this.updateModule(id, { is_published: false });
  },

  async publishLesson(id: string): Promise<ServiceResponse<CourseLesson>> {
    return this.updateLesson(id, { is_published: true });
  },

  async unpublishLesson(id: string): Promise<ServiceResponse<CourseLesson>> {
    return this.updateLesson(id, { is_published: false });
  },

  async bulkPublishLessons(lessonIds: string[]): Promise<ServiceResponse<null>> {
    try {
      for (const id of lessonIds) {
        const { error } = await supabase
          .from('course_lessons')
          .update({ is_published: true })
          .eq('id', id);

        if (error) throw error;
      }
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  // Analytics and Progress
  async getContentStats(): Promise<ServiceResponse<ContentStats>> {
    try {
      const { data: modules, error: moduleError } = await supabase
        .from('course_modules')
        .select('id, is_published');

      if (moduleError) throw moduleError;

      const { data: lessons, error: lessonError } = await supabase
        .from('course_lessons')
        .select('id, is_published');

      if (lessonError) throw lessonError;

      const { data: members, error: memberError } = await supabase
        .from('members')
        .select('id')
        .eq('is_active', true);

      if (memberError) throw memberError;

      const { data: progress, error: progressError } = await supabase
        .from('lesson_progress')
        .select('is_completed');

      if (progressError) throw progressError;

      const totalCompleted = (progress || []).filter((p) => p.is_completed).length;
      const totalProgress = (progress || []).length;

      const stats: ContentStats = {
        total_modules: (modules || []).length,
        published_modules: (modules || []).filter((m) => m.is_published).length,
        total_lessons: (lessons || []).length,
        published_lessons: (lessons || []).filter((l) => l.is_published).length,
        total_members: (members || []).length,
        average_completion_rate: totalProgress > 0 ? (totalCompleted / totalProgress) * 100 : 0,
      };

      return { data: stats, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getLessonProgress(lessonId: string): Promise<ServiceResponse<LessonProgress[]>> {
    try {
      const { data, error } = await supabase
        .from('lesson_progress')
        .select('*')
        .eq('lesson_id', lessonId);

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMemberProgress(memberId: string): Promise<ServiceResponse<LessonProgress[]>> {
    try {
      const { data, error } = await supabase
        .from('lesson_progress')
        .select(`
          *,
          lesson:course_lessons(id, title, module_id)
        `)
        .eq('member_id', memberId);

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },
};

// Export types and service
export type { CourseModule, CourseLesson };
function courseLessonService(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: courseLessonService is not implemented yet.', args);
  return null;
}

export { courseLessonService };
function courseModuleService(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: courseModuleService is not implemented yet.', args);
  return null;
}

export { courseModuleService };
function CreateLessonData(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: CreateLessonData is not implemented yet.', args);
  return null;
}

export { CreateLessonData };
function UpdateLessonData(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: UpdateLessonData is not implemented yet.', args);
  return null;
}

export { UpdateLessonData };