import { supabase } from '../lib/supabase';
import {
  Meditation,
  InsertMeditation,
  UpdateMeditation,
  ServiceResponse,
  MeditationCategory
} from '../types/admin.types';

export const meditationService = {
  async getAllMeditations(): Promise<ServiceResponse<Meditation[]>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMeditationsByCategory(category: MeditationCategory): Promise<ServiceResponse<Meditation[]>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .select('*')
        .eq('category', category)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getFeaturedMeditations(): Promise<ServiceResponse<Meditation[]>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .select('*')
        .eq('is_featured', true)
        .eq('is_published', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getMeditationById(id: string): Promise<ServiceResponse<Meditation>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async createMeditation(meditation: InsertMeditation): Promise<ServiceResponse<Meditation>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .insert(meditation)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateMeditation(id: string, updates: UpdateMeditation): Promise<ServiceResponse<Meditation>> {
    try {
      const { data, error } = await supabase
        .from('meditations')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteMeditation(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('meditations')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async togglePublished(id: string, isPublished: boolean): Promise<ServiceResponse<Meditation>> {
    return this.updateMeditation(id, { is_published: isPublished });
  },

  async toggleFeatured(id: string, isFeatured: boolean): Promise<ServiceResponse<Meditation>> {
    return this.updateMeditation(id, { is_featured: isFeatured });
  }
};