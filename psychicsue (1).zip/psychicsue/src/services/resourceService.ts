import { supabase } from '../lib/supabase';
import {
  Resource,
  InsertResource,
  UpdateResource,
  ServiceResponse,
  ResourceCategory
} from '../types/admin.types';

export const resourceService = {
  async getAllResources(): Promise<ServiceResponse<Resource[]>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getResourcesByCategory(category: ResourceCategory): Promise<ServiceResponse<Resource[]>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .eq('category', category)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getFeaturedResources(): Promise<ServiceResponse<Resource[]>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .eq('is_featured', true)
        .eq('is_published', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data: data || [], error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async getResourceById(id: string): Promise<ServiceResponse<Resource>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async createResource(resource: InsertResource): Promise<ServiceResponse<Resource>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .insert(resource)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async updateResource(id: string, updates: UpdateResource): Promise<ServiceResponse<Resource>> {
    try {
      const { data, error } = await supabase
        .from('resources')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async deleteResource(id: string): Promise<ServiceResponse<null>> {
    try {
      const { error } = await supabase
        .from('resources')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { data: null, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async togglePublished(id: string, isPublished: boolean): Promise<ServiceResponse<Resource>> {
    return this.updateResource(id, { is_published: isPublished });
  },

  async toggleFeatured(id: string, isFeatured: boolean): Promise<ServiceResponse<Resource>> {
    return this.updateResource(id, { is_featured: isFeatured });
  }
};