'use client';

import { ReactNode } from 'react';
import Header from './Header';

interface AuthNavigationProps {
  children: ReactNode;
  isAuthenticated?: boolean;
}

const AuthNavigation = ({ children, isAuthenticated = false }: AuthNavigationProps) => {
  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={isAuthenticated} />
      {children}
    </div>
  );
};

export default AuthNavigation;