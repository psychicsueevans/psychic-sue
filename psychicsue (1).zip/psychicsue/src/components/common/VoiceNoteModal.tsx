'use client';

import { useState, useRef } from 'react';
import { voiceNoteService } from '@/services/voiceNoteService';

interface VoiceNoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  memberId: string;
}

const VoiceNoteModal = ({ isOpen, onClose, memberId }: VoiceNoteModalProps) => {
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [questionTopic, setQuestionTopic] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const allowedTypes = ['audio/mpeg', 'audio/mp4', 'audio/wav', 'audio/ogg'];
      if (!allowedTypes.includes(file.type)) {
        setErrorMessage('Please upload a valid audio file (.mp3, .m4a, .wav, or .ogg)');
        setAudioFile(null);
        return;
      }

      // Validate file size (10MB max)
      const maxSize = 10 * 1024 * 1024; // 10MB in bytes
      if (file.size > maxSize) {
        setErrorMessage('File size must be less than 10MB');
        setAudioFile(null);
        return;
      }

      setErrorMessage('');
      setAudioFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!audioFile) {
      setErrorMessage('Please select an audio file to upload');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      // Upload audio file
      const { data: uploadData, error: uploadError } = await voiceNoteService.uploadAudioFile(audioFile, memberId);

      if (uploadError || !uploadData) {
        setErrorMessage('Failed to upload audio file. Please try again.');
        setIsSubmitting(false);
        return;
      }

      // Get public URL
      const audioUrl = voiceNoteService.getAudioUrl(uploadData.path);

      // Create voice note record
      const { data: voiceNote, error: createError } = await voiceNoteService.createVoiceNote({
        member_id: memberId,
        audio_url: audioUrl,
        question_topic: questionTopic || undefined,
      });

      if (createError || !voiceNote) {
        setErrorMessage('Failed to save voice note. Please try again.');
        setIsSubmitting(false);
        return;
      }

      // Success
      setSuccessMessage('Your voice note has been sent! Sue will get back to you soon.');
      
      // Reset form after 2 seconds
      setTimeout(() => {
        setAudioFile(null);
        setQuestionTopic('');
        setSuccessMessage('');
        onClose();
      }, 2000);
    } catch (error) {
      setErrorMessage('An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setAudioFile(null);
      setQuestionTopic('');
      setErrorMessage('');
      setSuccessMessage('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 relative">
        {/* Close Button */}
        {!isSubmitting && (
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
            aria-label="Close modal"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}

        {/* Modal Header */}
        <h2 className="text-2xl font-bold text-purple-950 mb-2">Send a Voice Message to Sue</h2>
        <p className="text-sm text-purple-600 mb-6">
          Record a message on your phone and upload it here. Sue will listen and respond personally.
        </p>

        {/* Success Message */}
        {successMessage && (
          <div className="mb-4 bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start">
              <svg className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <p className="ml-3 text-sm text-green-700 font-medium">{successMessage}</p>
            </div>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start">
              <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <p className="ml-3 text-sm text-red-700">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* File Upload */}
          <div>
            <label htmlFor="audio-file" className="block text-sm font-medium text-purple-950 mb-2">
              Audio File <span className="text-red-500">*</span>
            </label>
            <input
              ref={fileInputRef}
              type="file"
              id="audio-file"
              accept=".mp3,.m4a,.wav,.ogg,audio/mpeg,audio/mp4,audio/wav,audio/ogg"
              onChange={handleFileChange}
              disabled={isSubmitting}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <p className="mt-1 text-xs text-gray-500">Accepts: .mp3, .m4a, .wav, .ogg (Max 10MB)</p>
            {audioFile && (
              <p className="mt-2 text-sm text-green-600 flex items-center">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                {audioFile.name}
              </p>
            )}
          </div>

          {/* Question Topic */}
          <div>
            <label htmlFor="question-topic" className="block text-sm font-medium text-purple-950 mb-2">
              What's your question about? (Optional)
            </label>
            <input
              type="text"
              id="question-topic"
              value={questionTopic}
              onChange={(e) => setQuestionTopic(e.target.value)}
              disabled={isSubmitting}
              placeholder="e.g., Career advice, relationships, spiritual guidance..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
              maxLength={200}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={handleClose}
              disabled={isSubmitting}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !audioFile}
              className="flex-1 px-4 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Sending...
                </>
              ) : (
                'Send Voice Note'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default VoiceNoteModal;