'use client';

import Icon from '@/components/ui/AppIcon';
import { useState, useEffect } from 'react';
import VoiceNoteModal from './VoiceNoteModal';

interface MemberQuickActionsProps {
  onBookReading?: () => void;
  hasNotifications?: boolean;
  memberId: string;
}

const MemberQuickActions = ({ 
  onBookReading, 
  hasNotifications = false,
  memberId
}: MemberQuickActionsProps) => {
  const [isVoiceNoteModalOpen, setIsVoiceNoteModalOpen] = useState(false);
  const [membershipTier, setMembershipTier] = useState<string>('');

  useEffect(() => {
    // Get membership tier from localStorage
    const tier = localStorage.getItem('membershipTier') || 'Circle Member';
    setMembershipTier(tier);
    
    // Listen for storage changes to react to view switching
    const handleStorageChange = () => {
      const updatedTier = localStorage.getItem('membershipTier') || 'Circle Member';
      setMembershipTier(updatedTier);
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Also check periodically for changes within the same tab
    const interval = setInterval(() => {
      const currentTier = localStorage.getItem('membershipTier') || 'Circle Member';
      if (currentTier !== membershipTier) {
        setMembershipTier(currentTier);
      }
    }, 100);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [membershipTier]);

  const handleSendVoiceNote = () => {
    setIsVoiceNoteModalOpen(true);
  };

  // Only render for VIP members
  const isVIPMember = membershipTier === 'VIP Member';

  if (!isVIPMember) {
    return null; // Don't render anything for Circle Members
  }

  return (
    <>
      <div className="bg-card border-b border-border">
        <div className="mx-auto px-6 py-4">
          <div className="flex items-center justify-center gap-4 overflow-x-auto">
            <button
              onClick={handleSendVoiceNote}
              className="relative flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95 whitespace-nowrap"
            >
              <Icon name="MicrophoneIcon" size={20} />
              <span>Send Voice Note</span>
              {hasNotifications && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-error text-error-foreground text-xs font-bold">
                  !
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      <VoiceNoteModal 
        isOpen={isVoiceNoteModalOpen}
        onClose={() => setIsVoiceNoteModalOpen(false)}
        memberId={memberId}
      />
    </>
  );
};

export default MemberQuickActions;