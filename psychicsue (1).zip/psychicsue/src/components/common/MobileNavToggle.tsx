'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface MobileNavToggleProps {
  isAuthenticated?: boolean;
}

const MobileNavToggle = ({ isAuthenticated = false }: MobileNavToggleProps) => {
  const pathname = usePathname();
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);

    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const publicNavItems = [
    { label: 'Home', path: '/homepage', icon: 'HomeIcon' },
    { label: 'Services', path: '/services-booking', icon: 'SparklesIcon' },
    { label: 'Circle', path: '/the-psychic-circle-sales', icon: 'UserGroupIcon' },
    { label: 'Contact', path: '/contact', icon: 'EnvelopeIcon' },
  ];

  const memberNavItems = [
    { label: 'Dashboard', path: '/member-dashboard', icon: 'HomeIcon' },
    { label: 'Readings', path: '/your-readings', icon: 'BookOpenIcon' },
  ];

  const navItems = isAuthenticated ? memberNavItems : publicNavItems;

  const isActivePath = (path: string) => pathname === path;

  if (!isMobile) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-100 bg-card border-t border-border shadow-lg md:hidden">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`flex flex-col items-center justify-center min-w-[60px] px-3 py-2 rounded-lg transition-all duration-250 ${
              isActivePath(item.path)
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-primary hover:bg-muted'
            }`}
          >
            <Icon name={item.icon as any} size={22} />
            <span className="text-xs font-medium mt-1 font-caption">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default MobileNavToggle;