'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface HeaderProps {
  isAuthenticated?: boolean;
}

const Header = ({ isAuthenticated = false }: HeaderProps) => {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const publicNavItems = [
    { label: 'Home', path: '/homepage', icon: 'HomeIcon' },
    { label: 'Book a Reading', path: '/services-booking', icon: 'SparklesIcon' },
    { label: 'The Psychic Circle', path: '/the-psychic-circle-sales', icon: 'UserGroupIcon' },
    { label: 'Contact', path: '/contact', icon: 'EnvelopeIcon' },
    { label: 'Member Login', path: '/member-login', icon: 'ArrowRightOnRectangleIcon' },
  ];

  const memberNavItems = [
    { label: 'Dashboard', path: '/member-dashboard', icon: 'HomeIcon' },
    { label: 'Back to Website', path: '/homepage', icon: 'ArrowLeftIcon' },
    { label: 'Your Readings', path: '/your-readings', icon: 'BookOpenIcon' },
  ];

  const adminNavItems = [
    { label: 'Admin Panel', path: '/admin', icon: 'ShieldCheckIcon' },
  ];

  const isAdminPath = pathname?.startsWith('/admin');
  const navItems = isAdminPath ? adminNavItems : isAuthenticated ? memberNavItems : publicNavItems;

  const isActivePath = (path: string) => pathname === path;

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-100 bg-card shadow-sm transition-all duration-250">
      <div className="mx-auto px-6">
        <div className="flex h-20 items-center justify-between lg:h-20">
          <Link 
            href={isAuthenticated ? '/member-dashboard' : '/homepage'} 
            className="flex items-center transition-transform duration-250 hover:scale-105"
            onClick={closeMobileMenu}
          >
            <svg
              width="160"
              height="40"
              viewBox="0 0 160 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="h-10 w-auto"
            >
              <circle cx="20" cy="20" r="18" fill="var(--color-primary)" opacity="0.1" />
              <circle cx="20" cy="20" r="12" fill="var(--color-primary)" opacity="0.2" />
              <circle cx="20" cy="20" r="6" fill="var(--color-primary)" />
              <path
                d="M20 8L22.5 15H30L24 19.5L26.5 27L20 22L13.5 27L16 19.5L10 15H17.5L20 8Z"
                fill="var(--color-accent)"
              />
              <text
                x="45"
                y="26"
                fontFamily="Crimson Text, serif"
                fontSize="20"
                fontWeight="600"
                fill="var(--color-primary)"
              >
                PsychicSue
              </text>
            </svg>
          </Link>

          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-250 ${
                  isActivePath(item.path)
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-foreground hover:bg-muted hover:text-primary hover:-translate-y-0.5'
                }`}
              >
                <Icon name={item.icon as any} size={20} />
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>

          <button
            onClick={toggleMobileMenu}
            className="md:hidden flex items-center justify-center w-12 h-12 rounded-lg text-foreground hover:bg-muted transition-all duration-250 active:scale-95"
            aria-label="Toggle mobile menu"
            aria-expanded={isMobileMenuOpen}
          >
            <Icon name={isMobileMenuOpen ? 'XMarkIcon' : 'Bars3Icon'} size={24} />
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-card border-t border-border animate-slide-down">
          <nav className="px-6 py-4 space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                onClick={closeMobileMenu}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-all duration-250 ${
                  isActivePath(item.path)
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-foreground hover:bg-muted hover:text-primary'
                }`}
              >
                <Icon name={item.icon as any} size={20} />
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;