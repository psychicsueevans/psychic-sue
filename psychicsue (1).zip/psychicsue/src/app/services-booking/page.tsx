import type { Metadata } from 'next';
import AuthNavigation from '@/components/common/AuthNavigation';
import MobileNavToggle from '@/components/common/MobileNavToggle';
import ServicesBookingInteractive from './components/ServicesBookingInteractive';

export const metadata: Metadata = {
  title: 'Book Your Reading - PsychicSue',
  description:
    'Schedule a personal tarot reading with Psychic Sue. Choose from Quick Insight (20 min), Comprehensive Reading (45 min), or In-Depth Life Session (90 min). All readings include recording and follow-up support.',
};

export default function ServicesBookingPage() {
  return (
    <AuthNavigation isAuthenticated={false}>
      <ServicesBookingInteractive />
      <MobileNavToggle isAuthenticated={false} />
    </AuthNavigation>
  );
}