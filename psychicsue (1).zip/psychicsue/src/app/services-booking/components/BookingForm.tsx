import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface BookingFormData {
  fullName: string;
  email: string;
  phone: string;
  communicationMethod: 'phone' | 'video' | 'email';
  focusArea: string;
  additionalNotes: string;
}

interface BookingFormProps {
  selectedService: string | null;
  selectedDate: Date | null;
  selectedTime: string | null;
  onSubmit: (data: BookingFormData) => void;
}

const BookingForm = ({ selectedService, selectedDate, selectedTime, onSubmit }: BookingFormProps) => {
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    email: '',
    phone: '',
    communicationMethod: 'phone',
    focusArea: '',
    additionalNotes: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof BookingFormData, string>>>({});

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof BookingFormData]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof BookingFormData, string>> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }

    if (!formData.focusArea.trim()) {
      newErrors.focusArea = 'Please describe your focus area';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const isFormComplete = selectedService && selectedDate && selectedTime;

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <h3 className="text-2xl font-semibold text-foreground mb-6">Your Details</h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-foreground mb-2">
            Full Name <span className="text-error">*</span>
          </label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={formData.fullName}
            onChange={handleInputChange}
            className={`w-full px-4 py-3 rounded-lg border ${
              errors.fullName ? 'border-error' : 'border-input'
            } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200`}
            placeholder="Enter your full name"
          />
          {errors.fullName && <p className="mt-1 text-sm text-error">{errors.fullName}</p>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
              Email Address <span className="text-error">*</span>
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 rounded-lg border ${
                errors.email ? 'border-error' : 'border-input'
              } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200`}
              placeholder="your.email@example.com"
            />
            {errors.email && <p className="mt-1 text-sm text-error">{errors.email}</p>}
          </div>

          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-2">
              Phone Number <span className="text-error">*</span>
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 rounded-lg border ${
                errors.phone ? 'border-error' : 'border-input'
              } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200`}
              placeholder="+44 7XXX XXXXXX"
            />
            {errors.phone && <p className="mt-1 text-sm text-error">{errors.phone}</p>}
          </div>
        </div>

        <div>
          <label
            htmlFor="communicationMethod"
            className="block text-sm font-medium text-foreground mb-2"
          >
            Preferred Communication Method <span className="text-error">*</span>
          </label>
          <select
            id="communicationMethod"
            name="communicationMethod"
            value={formData.communicationMethod}
            onChange={handleInputChange}
            className="w-full px-4 py-3 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200"
          >
            <option value="phone">Phone Call</option>
            <option value="video">Video Call (Zoom/WhatsApp)</option>
            <option value="email">Email Reading</option>
          </select>
        </div>

        <div>
          <label htmlFor="focusArea" className="block text-sm font-medium text-foreground mb-2">
            What would you like to focus on? <span className="text-error">*</span>
          </label>
          <textarea
            id="focusArea"
            name="focusArea"
            value={formData.focusArea}
            onChange={handleInputChange}
            rows={3}
            className={`w-full px-4 py-3 rounded-lg border ${
              errors.focusArea ? 'border-error' : 'border-input'
            } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200 resize-none`}
            placeholder="E.g., Career guidance, relationship advice, life direction..."
          />
          {errors.focusArea && <p className="mt-1 text-sm text-error">{errors.focusArea}</p>}
        </div>

        <div>
          <label htmlFor="additionalNotes" className="block text-sm font-medium text-foreground mb-2">
            Additional Notes (Optional)
          </label>
          <textarea
            id="additionalNotes"
            name="additionalNotes"
            value={formData.additionalNotes}
            onChange={handleInputChange}
            rows={3}
            className="w-full px-4 py-3 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200 resize-none"
            placeholder="Any other information you'd like Sue to know..."
          />
        </div>

        <div className="bg-muted rounded-lg p-4 space-y-2">
          <div className="flex items-start space-x-3">
            <Icon name="InformationCircleIcon" size={20} className="text-primary mt-0.5" />
            <div className="text-sm text-foreground">
              <p className="font-medium mb-1">Booking Policy</p>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Free cancellation up to 24 hours before your reading</li>
                <li>• Confirmation email sent within 2 hours</li>
                <li>• Recordings provided for phone and video readings</li>
              </ul>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={!isFormComplete}
          className={`w-full py-4 rounded-lg font-medium transition-all duration-250 ${
            isFormComplete
              ? 'bg-primary text-primary-foreground hover:shadow-md hover:-translate-y-0.5 active:scale-95'
              : 'bg-muted text-muted-foreground cursor-not-allowed'
          }`}
        >
          {isFormComplete ? 'Proceed to Payment' : 'Please select service, date & time'}
        </button>
      </form>
    </div>
  );
};

export default BookingForm;