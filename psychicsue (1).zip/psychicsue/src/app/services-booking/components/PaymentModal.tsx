import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceTitle: string;
  price: string;
  selectedDate: Date | null;
  selectedTime: string | null;
  onConfirmPayment: (method: 'stripe' | 'paypal') => void;
}

const PaymentModal = ({
  isOpen,
  onClose,
  serviceTitle,
  price,
  selectedDate,
  selectedTime,
  onConfirmPayment
}: PaymentModalProps) => {
  if (!isOpen) return null;

  const formatDate = (date: Date | null) => {
    if (!date) return '';
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-xl border border-border max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-card border-b border-border p-6 flex items-center justify-between">
          <h3 className="text-2xl font-semibold text-foreground">Complete Your Booking</h3>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors duration-200"
            aria-label="Close payment modal">

            <Icon name="XMarkIcon" size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-muted rounded-lg p-4 space-y-3">
            <h4 className="font-semibold text-foreground">Booking Summary</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Service:</span>
                <span className="font-medium text-foreground">{serviceTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date:</span>
                <span className="font-medium text-foreground">{formatDate(selectedDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Time:</span>
                <span className="font-medium text-foreground">{selectedTime} GMT</span>
              </div>
              <div className="pt-3 border-t border-border flex justify-between">
                <span className="font-semibold text-foreground">Total:</span>
                <span className="text-xl font-bold text-primary">{price}</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Select Payment Method</h4>
            <div className="space-y-3">
              <button
                onClick={() => onConfirmPayment('stripe')}
                className="w-full flex items-center justify-between p-4 rounded-lg border-2 border-border hover:border-primary hover:bg-muted transition-all duration-200 group">

                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="CreditCardIcon" size={24} className="text-primary" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-foreground">Credit/Debit Card</div>
                    <div className="text-sm text-muted-foreground">Powered by Stripe</div>
                  </div>
                </div>
                <Icon
                  name="ChevronRightIcon"
                  size={20}
                  className="text-muted-foreground group-hover:text-primary transition-colors" />

              </button>

              <button
                onClick={() => onConfirmPayment('paypal')}
                className="w-full flex items-center justify-between p-4 rounded-lg border-2 border-border hover:border-primary hover:bg-muted transition-all duration-200 group">

                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#0070BA]/10 rounded-lg flex items-center justify-center">
                    <AppImage
                      src="https://img.rocket.new/generatedImages/rocket_gen_img_17ddae2d2-1764675976055.png"
                      alt="PayPal logo with blue background and white text"
                      className="w-8 h-8 object-contain" />

                  </div>
                  <div className="text-left">
                    <div className="font-medium text-foreground">PayPal</div>
                    <div className="text-sm text-muted-foreground">Fast & secure</div>
                  </div>
                </div>
                <Icon
                  name="ChevronRightIcon"
                  size={20}
                  className="text-muted-foreground group-hover:text-primary transition-colors" />

              </button>
            </div>
          </div>

          <div className="bg-accent/10 rounded-lg p-4 flex items-start space-x-3">
            <Icon name="ShieldCheckIcon" size={20} className="text-success mt-0.5" />
            <div className="text-sm text-foreground">
              <p className="font-medium mb-1">Secure Payment</p>
              <p className="text-muted-foreground">
                Your payment information is encrypted and secure. We never store your card details.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>);

};

export default PaymentModal;