import Icon from '@/components/ui/AppIcon';

interface ServiceFeature {
  text: string;
  included: boolean;
}

interface ServiceCardProps {
  title: string;
  duration: string;
  price: string;
  description: string;
  features: ServiceFeature[];
  isPopular?: boolean;
  onBookNow: () => void;
}

const ServiceCard = ({
  title,
  duration,
  price,
  description,
  features,
  isPopular = false,
  onBookNow,
}: ServiceCardProps) => {
  return (
    <div
      className={`relative bg-card rounded-xl border-2 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
        isPopular ? 'border-primary shadow-md' : 'border-border'
      }`}
    >
      {isPopular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-6 py-2 rounded-full text-sm font-medium shadow-md">
          Most Popular
        </div>
      )}

      <div className="p-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-2xl font-semibold text-foreground mb-2">{title}</h3>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Icon name="ClockIcon" size={18} />
              <span className="text-sm font-caption">{duration}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary">{price}</div>
            <div className="text-sm text-muted-foreground font-caption">per session</div>
          </div>
        </div>

        <p className="text-foreground mb-6 leading-relaxed">{description}</p>

        <div className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <div key={index} className="flex items-start space-x-3">
              <Icon
                name={feature.included ? 'CheckCircleIcon' : 'XCircleIcon'}
                size={20}
                variant="solid"
                className={feature.included ? 'text-success' : 'text-muted-foreground'}
              />
              <span
                className={`text-sm ${
                  feature.included ? 'text-foreground' : 'text-muted-foreground line-through'
                }`}
              >
                {feature.text}
              </span>
            </div>
          ))}
        </div>

        <button
          onClick={onBookNow}
          className={`w-full py-4 rounded-lg font-medium transition-all duration-250 active:scale-95 ${
            isPopular
              ? 'bg-primary text-primary-foreground hover:shadow-md hover:-translate-y-0.5'
              : 'bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground'
          }`}
        >
          Book This Reading
        </button>
      </div>
    </div>
  );
};

export default ServiceCard;