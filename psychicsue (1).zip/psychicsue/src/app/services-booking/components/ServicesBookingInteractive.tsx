'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

type FilterTab = 'all' | 'love' | 'general' | 'money' | 'express' | 'live';

interface Reading {
  id: string;
  title: string;
  price: string;
  deliveryTime: string;
  description: string;
  fullDescription: string;
  badge?: 'LIVE';
  category: FilterTab[];
  image: string;
  alt: string;
}

const ServicesBookingInteractive = () => {
  const router = useRouter();
  const [isHydrated, setIsHydrated] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterTab>('all');
  const [isVIPMember, setIsVIPMember] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    
    // Check if user is VIP member
    // In a real implementation, this would check authentication and membership tier
    // For now, we check localStorage which is set in member dashboard
    const memberTier = localStorage.getItem('demoMemberTier');
    setIsVIPMember(memberTier === 'VIP');
  }, []);

  const readings: Reading[] = [
    {
      id: 'love-relationships',
      title: 'Love & Relationships Reading',
      price: '$35',
      deliveryTime: '3-5 days',
      description: "Insight into their feelings, intentions, and where the connection is heading.",
      fullDescription: "Get deep insight into your love life and relationships. I'll look at the energy between you and your person, what they're truly feeling, their intentions, and where this connection is heading. Whether you're wondering if they'll come back, if they're being honest, or what the future holds for your relationship, I'll tell you exactly what the cards are showing me. This reading is perfect for anyone seeking clarity on matters of the heart.",
      category: ['all', 'love'],
      image: '/assets/images/love_relationships_tarot_reading.png',
      alt: 'Mystical tarot cards with hearts and roses on purple velvet cloth surrounded by rose quartz crystals and candlelight'
    },
    {
      id: 'general-tarot',
      title: 'General Tarot Reading',
      price: '$35',
      deliveryTime: '3-5 days',
      description: "Guidance on whatever's on your mind — life, decisions, what's coming next.",
      fullDescription: "A comprehensive tarot reading covering whatever is on your mind right now. Whether you have questions about your life path, important decisions you need to make, or you just want to know what's coming next, I'll give you the guidance you need. This reading is flexible and can cover multiple areas of your life including relationships, career, family, and personal growth. I'll tell you what I see and give you honest, direct advice on how to move forward.",
      category: ['all', 'general'],
      image: '/assets/images/general_tarot_reading_spread.png',
      alt: 'Traditional tarot card spread with mystical symbols, cosmic imagery, and amethyst crystals on dark purple velvet'
    },
    {
      id: 'money-career',
      title: 'Money & Career Reading',
      price: '$35',
      deliveryTime: '3-5 days',
      description: 'Clarity on finances, work decisions, and opportunities ahead.',
      fullDescription: "Get clear guidance on your financial situation and career path. I'll look at your current work situation, upcoming opportunities, whether a job change is coming, and what you need to know about your finances. If you're wondering whether to take a new position, start a business, or make a major financial decision, I'll tell you what the cards reveal about your professional future and money matters. This reading helps you make confident decisions about your career and financial life.",
      category: ['all', 'money'],
      image: '/assets/images/money_career_tarot_reading.png',
      alt: 'Tarot cards featuring pentacles and coins representing wealth, surrounded by citrine crystals and gold candles on velvet'
    },
    {
      id: 'express-reading',
      title: 'Express Reading',
      price: '$55',
      deliveryTime: 'Within 24 hours',
      description: 'Quick, focused guidance when you need answers fast.',
      fullDescription: "When you need answers quickly, this express reading delivers focused guidance within 24 hours. Perfect for urgent questions or time-sensitive situations where you need clarity fast. I'll focus on your most pressing question and give you direct, honest insight into what's happening and what you need to know right now. While this is a faster turnaround, you still get my full attention and accurate guidance on your situation.",
      category: ['all', 'express'],
      image: '/assets/images/express_tarot_reading.png',
      alt: 'Glowing tarot cards with urgent energy, surrounded by clear quartz crystals and bright candlelight on mystical cloth'
    },
    {
      id: 'full-in-depth',
      title: 'Full In-Depth Reading',
      price: '$45',
      deliveryTime: '5-7 days',
      description: 'A comprehensive look at all areas of your life — past, present, and future.',
      fullDescription: "This is my most comprehensive written reading, covering all major areas of your life in depth. I'll look at your past influences, current situation, and what's coming in your future across love, career, finances, family, and personal growth. You'll receive detailed insight into the energies surrounding you, upcoming opportunities and challenges, and specific guidance on how to navigate what's ahead. This reading is perfect when you want a complete picture of your life path and need thorough guidance on multiple areas.",
      category: ['all', 'general'],
      image: '/assets/images/full_in_depth_tarot_reading.png',
      alt: 'Complete tarot deck spread showing past, present, and future with mystical crystals, candles, and cosmic imagery'
    },
    {
      id: 'live-phone',
      title: 'Live 30 Min Phone Reading',
      price: '$100',
      deliveryTime: 'Book a time',
      description: 'Speak with me directly for a personal, real-time reading. Book your preferred time and pay securely through our booking system. You\'ll receive instant confirmation and reminders.',
      fullDescription: "Experience a live, personal reading where you can speak with me directly for 30 minutes. This is your opportunity to ask questions in real-time, get immediate answers, and have a genuine conversation about what's happening in your life. I'll do a reading for you over the phone, and you can ask follow-up questions as we go. This is the most personal and interactive reading experience I offer, perfect for those who want direct connection and immediate guidance. After our call, I'll send you a summary of the key points we discussed. Book your preferred time and pay securely through our booking system. You'll receive instant confirmation and reminders.",
      badge: 'LIVE',
      category: ['all', 'live'],
      image: '/assets/images/live_phone_tarot_reading.png',
      alt: 'Phone with mystical aura and tarot cards representing live personal reading session with candles and crystals'
    },
  ];

  const filterTabs: { id: FilterTab; label: string }[] = [
    { id: 'all', label: 'All Readings' },
    { id: 'love', label: 'Love Readings' },
    { id: 'general', label: 'General Readings' },
    { id: 'money', label: 'Money Readings' },
    { id: 'express', label: 'Express' },
    { id: 'live', label: 'Live Readings' },
  ];

  const whyBookFeatures = [
    {
      title: 'Honest & Direct',
      description: "I tell you what I see — no sugarcoating, no false hope. Just the truth you need to hear.",
      icon: 'ChatBubbleLeftRightIcon'
    },
    {
      title: 'Accurate Predictions',
      description: "I don't just tell you what's happening now — I tell you when things will happen and what to do about it.",
      icon: 'SparklesIcon'
    },
    {
      title: 'Personal Care',
      description: "Every reading is done personally by me. You're not getting a generic response — you're getting my full attention.",
      icon: 'HeartIcon'
    },
  ];

  const filteredReadings = readings.filter((reading) =>
    reading.category.includes(activeFilter)
  );

  const handleBookNow = (reading: Reading) => {
    // Special handling for live phone reading - redirect to Calendly
    if (reading.id === 'live-phone') {
      window.open('[PASTE YOUR CALENDLY LIVE READING LINK HERE]', '_blank');
      return;
    }
    
    // All other readings use the normal Stripe checkout flow
    const readingData = encodeURIComponent(JSON.stringify(reading));
    router.push(`/reading-product-page?reading=${readingData}`);
  };

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mx-auto px-6 py-16">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-muted rounded-lg w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-96 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-8">
      <div className="mx-auto px-6 py-16">
        {/* VIP Priority Banner - Only shown for VIP members */}
        {isVIPMember && (
          <div className="mb-8 bg-gradient-to-r from-amber-400 to-amber-500 rounded-xl p-6 shadow-lg">
            <div className="flex items-center justify-center gap-3 text-center">
              <span className="text-3xl">✨</span>
              <div>
                <h2 className="text-xl font-bold text-amber-900 mb-1">
                  VIP Priority Status
                </h2>
                <p className="text-amber-900">
                  As a VIP member, your bookings are always handled first!
                </p>
              </div>
              <span className="text-3xl">✨</span>
            </div>
          </div>
        )}

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Book a Reading
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed italic">
            Every reading is personal, detailed, and delivered straight to you. Choose the reading that calls to you, share your questions, and I will tell you exactly what the cards are showing me.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-250 ${
                activeFilter === tab.id
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-card text-foreground border-2 border-border hover:border-primary'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {filteredReadings.map((reading) => (
            <div
              key={reading.id}
              className="bg-card rounded-xl border-2 border-border overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 cursor-pointer"
              onClick={() => handleBookNow(reading)}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={reading.image}
                  alt={reading.alt}
                  className="w-full h-full object-cover"
                />
                {reading.badge && (
                  <div className="absolute top-4 right-4 bg-amber-500 text-white px-4 py-1.5 rounded-full text-xs font-bold shadow-lg">
                    {reading.badge}
                  </div>
                )}
              </div>

              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {reading.title}
                </h3>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="text-2xl font-bold text-primary">{reading.price}</div>
                  <div className="text-sm text-muted-foreground flex items-center space-x-1">
                    <Icon name="ClockIcon" size={16} />
                    <span>{reading.deliveryTime}</span>
                  </div>
                </div>

                <p className="text-foreground mb-6 leading-relaxed">
                  {reading.description}
                </p>

                <button
                  className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-medium transition-all duration-250 hover:shadow-md hover:-translate-y-0.5 active:scale-95"
                >
                  {reading.id === 'live-phone' ? 'Book & Pay' : 'Book Now'}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-2xl p-12 text-white">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Book With Me</h2>
            <p className="text-lg text-purple-200">50 years of experience, thousands of accurate readings</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {whyBookFeatures.map((feature, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-8 text-center border border-white/20"
              >
                <div className="flex justify-center mb-4">
                  <div className="bg-amber-500 rounded-full p-4">
                    <Icon name={feature.icon as any} size={32} className="text-white" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-purple-100 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesBookingInteractive;