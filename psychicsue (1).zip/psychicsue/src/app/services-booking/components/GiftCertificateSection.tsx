import Icon from '@/components/ui/AppIcon';

interface GiftCertificateSectionProps {
  onPurchaseGift: () => void;
}

const GiftCertificateSection = ({ onPurchaseGift }: GiftCertificateSectionProps) => {
  return (
    <div className="bg-gradient-to-br from-accent/20 to-secondary/20 rounded-xl border border-accent/30 p-8">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-3">
            <Icon name="GiftIcon" size={28} className="text-accent" />
            <h3 className="text-2xl font-semibold text-foreground">Gift a Reading</h3>
          </div>
          <p className="text-foreground mb-4 leading-relaxed">
            Share the gift of spiritual guidance with someone special. Our gift certificates are
            perfect for birthdays, holidays, or any occasion where you want to offer comfort and
            clarity.
          </p>
          <ul className="space-y-2 text-sm text-foreground">
            <li className="flex items-center space-x-2">
              <Icon name="CheckCircleIcon" size={18} variant="solid" className="text-success" />
              <span>Valid for 12 months from purchase</span>
            </li>
            <li className="flex items-center space-x-2">
              <Icon name="CheckCircleIcon" size={18} variant="solid" className="text-success" />
              <span>Beautifully designed digital certificate</span>
            </li>
            <li className="flex items-center space-x-2">
              <Icon name="CheckCircleIcon" size={18} variant="solid" className="text-success" />
              <span>Recipient chooses their preferred reading type</span>
            </li>
          </ul>
        </div>

        <div className="flex-shrink-0">
          <button
            onClick={onPurchaseGift}
            className="px-8 py-4 bg-accent text-accent-foreground rounded-lg font-medium shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-250 active:scale-95 whitespace-nowrap"
          >
            Purchase Gift Certificate
          </button>
        </div>
      </div>
    </div>
  );
};

export default GiftCertificateSection;