import Icon from '@/components/ui/AppIcon';

const BookingPolicies = () => {
  const policies = [
    {
      icon: 'ClockIcon',
      title: 'Response Time',
      description: 'Booking confirmation within 2 hours during business hours (9am-6pm GMT)',
    },
    {
      icon: 'CalendarIcon',
      title: 'Cancellation Policy',
      description: 'Free cancellation up to 24 hours before your scheduled reading',
    },
    {
      icon: 'VideoCameraIcon',
      title: 'Recording Provided',
      description: 'All phone and video readings are recorded and sent to you within 24 hours',
    },
    {
      icon: 'ShieldCheckIcon',
      title: 'Privacy Guarantee',
      description: 'Your information and reading details are completely confidential',
    },
    {
      icon: 'ArrowPathIcon',
      title: 'Rescheduling',
      description: 'Reschedule your reading free of charge with 24 hours notice',
    },
    {
      icon: 'EnvelopeIcon',
      title: 'Follow-up Questions',
      description: 'One follow-up email question included within 7 days of your reading',
    },
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-8">
      <h3 className="text-2xl font-semibold text-foreground mb-6">Booking Policies & Guarantees</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {policies.map((policy, index) => (
          <div key={index} className="flex items-start space-x-4">
            <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name={policy.icon as any} size={24} className="text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-1">{policy.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{policy.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex items-start space-x-3 bg-accent/10 rounded-lg p-4">
          <Icon name="InformationCircleIcon" size={20} className="text-primary mt-0.5" />
          <div className="text-sm text-foreground">
            <p className="font-medium mb-1">Need Help?</p>
            <p className="text-muted-foreground">
              If you have any questions about booking or need assistance, please contact us at{' '}
              <a href="mailto:bookings@psychicsue.com" className="text-primary hover:underline">
                bookings@psychicsue.com
              </a>{' '}
              or call{' '}
              <a href="tel:+447123456789" className="text-primary hover:underline">
                +44 7123 456789
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPolicies;