import type { Metadata } from 'next';
import AuthNavigation from '@/components/common/AuthNavigation';
import MemberQuickActions from '@/components/common/MemberQuickActions';
import MobileNavToggle from '@/components/common/MobileNavToggle';
import YourReadingsInteractive from './components/YourReadingsInteractive';

export const metadata: Metadata = {
  title: 'Your Readings - PsychicSue',
  description: 'Manage your scheduled psychic readings, access session history, and book new appointments with Sue. View countdown timers, preparation materials, and past reading insights.',
};

export default function YourReadingsPage() {
  return (
    <AuthNavigation isAuthenticated={true}>
      <MemberQuickActions />
      
      <main className="min-h-screen bg-background pb-24 md:pb-8">
        <div className="mx-auto px-6 py-8 lg:py-12">
          <YourReadingsInteractive />
        </div>
      </main>

      <MobileNavToggle isAuthenticated={true} />
    </AuthNavigation>
  );
}