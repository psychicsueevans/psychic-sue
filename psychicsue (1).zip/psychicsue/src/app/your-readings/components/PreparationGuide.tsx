import Icon from '@/components/ui/AppIcon';

interface PreparationStep {
  icon: string;
  title: string;
  description: string;
}

const PreparationGuide = () => {
  const preparationSteps: PreparationStep[] = [
    {
      icon: 'PencilSquareIcon',
      title: 'Formulate Your Questions',
      description: 'Write down 3-5 specific questions you want guidance on. Focus on open-ended questions that explore possibilities rather than yes/no answers.'
    },
    {
      icon: 'SparklesIcon',
      title: 'Create Sacred Space',
      description: 'Find a quiet, comfortable location where you won\'t be disturbed. Light a candle or incense if it helps you feel centered and present.'
    },
    {
      icon: 'HeartIcon',
      title: 'Set Your Intention',
      description: 'Take a few moments to meditate and set a clear intention for your reading. Open your heart and mind to receive guidance with trust and clarity.'
    },
    {
      icon: 'SignalIcon',
      title: 'Check Technical Setup',
      description: 'For virtual readings, test your internet connection, camera, and microphone 10 minutes before your session. Ensure good lighting and minimal background noise.'
    }
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-12 h-12 bg-primary/20 rounded-full">
          <Icon name="BookOpenIcon" size={24} className="text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Reading Preparation Guide</h3>
          <p className="text-sm text-muted-foreground">Maximize your session with Sue</p>
        </div>
      </div>

      <div className="space-y-4">
        {preparationSteps.map((step, index) => (
          <div key={index} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-all duration-250">
            <div className="flex items-center justify-center w-10 h-10 bg-accent/20 rounded-full flex-shrink-0">
              <Icon name={step.icon as any} size={20} className="text-accent-foreground" />
            </div>
            <div className="flex-1">
              <h4 className="text-base font-semibold text-foreground mb-1">{step.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20">
        <div className="flex items-start space-x-3">
          <Icon name="LightBulbIcon" size={20} className="text-primary mt-0.5 flex-shrink-0" />
          <div className="text-sm text-foreground leading-relaxed">
            <p className="font-medium mb-2">Sue's Personal Tip</p>
            <p className="text-muted-foreground">
              "The most powerful readings happen when you come with an open heart and specific intentions. Trust the process and know that the messages you receive are exactly what you need to hear at this moment in your journey."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreparationGuide;