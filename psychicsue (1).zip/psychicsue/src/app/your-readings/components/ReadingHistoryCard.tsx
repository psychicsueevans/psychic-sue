import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface PastReading {
  id: string;
  type: string;
  date: string;
  duration: string;
  rating: number;
  insights: string;
  followUpNotes: string;
  recordingUrl?: string;
  imageUrl: string;
  imageAlt: string;
}

interface ReadingHistoryCardProps {
  reading: PastReading;
}

const ReadingHistoryCard = ({ reading }: ReadingHistoryCardProps) => {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="StarIcon"
        size={16}
        variant={index < rating ? 'solid' : 'outline'}
        className={index < rating ? 'text-accent' : 'text-muted-foreground'}
      />
    ));
  };

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm hover:shadow-md transition-all duration-250">
      <div className="flex flex-col sm:flex-row">
        <div className="relative w-full sm:w-48 h-48 sm:h-auto overflow-hidden flex-shrink-0">
          <AppImage
            src={reading.imageUrl}
            alt={reading.imageAlt}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex-1 p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-xl font-semibold text-foreground mb-1">{reading.type}</h3>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <Icon name="CalendarIcon" size={16} />
                  <span>{reading.date}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="ClockIcon" size={16} />
                  <span>{reading.duration}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              {renderStars(reading.rating)}
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1 font-caption">KEY INSIGHTS</p>
              <p className="text-sm text-foreground leading-relaxed">{reading.insights}</p>
            </div>

            {reading.followUpNotes && (
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1 font-caption">FOLLOW-UP NOTES</p>
                <p className="text-sm text-foreground leading-relaxed">{reading.followUpNotes}</p>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            {reading.recordingUrl && (
              <button className="flex items-center space-x-2 px-4 py-2 bg-primary/10 text-primary rounded-lg font-medium hover:bg-primary/20 transition-all duration-250 active:scale-95">
                <Icon name="PlayIcon" size={18} />
                <span className="text-sm">Listen to Recording</span>
              </button>
            )}
            <button className="flex items-center space-x-2 px-4 py-2 bg-accent/10 text-accent-foreground rounded-lg font-medium hover:bg-accent/20 transition-all duration-250 active:scale-95">
              <Icon name="ArrowPathIcon" size={18} />
              <span className="text-sm">Book Follow-Up</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReadingHistoryCard;