'use client';

import { useState, useRef } from 'react';
import Icon from '@/components/ui/AppIcon';

interface VoiceNoteUploadProps {
  onUploadComplete?: (file: File) => void;
}

const VoiceNoteUpload = ({ onUploadComplete }: VoiceNoteUploadProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [message, setMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        alert('File size must be less than 10MB');
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(0);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          if (onUploadComplete) {
            onUploadComplete(selectedFile);
          }
          setTimeout(() => {
            setSelectedFile(null);
            setMessage('');
            setUploadProgress(0);
          }, 2000);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-4">
        <div className="flex items-center justify-center w-12 h-12 bg-accent/20 rounded-full">
          <Icon name="MicrophoneIcon" size={24} className="text-accent-foreground" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Send Voice Note to Sue</h3>
          <p className="text-sm text-muted-foreground">Share questions or updates before your reading</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
            Message (Optional)
          </label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            placeholder="Add any context or specific questions..."
            className="w-full px-4 py-3 bg-background border border-input rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>

        {!selectedFile ? (
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileSelect}
              className="hidden"
              id="voice-note-upload"
            />
            <label
              htmlFor="voice-note-upload"
              className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-all duration-250"
            >
              <Icon name="CloudArrowUpIcon" size={32} className="text-muted-foreground mb-2" />
              <p className="text-sm font-medium text-foreground">Click to upload voice note</p>
              <p className="text-xs text-muted-foreground mt-1">MP3, WAV, M4A (Max 10MB)</p>
            </label>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                <Icon name="MusicalNoteIcon" size={24} className="text-primary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{selectedFile.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                  </p>
                </div>
              </div>
              {!isUploading && (
                <button
                  onClick={handleRemoveFile}
                  className="flex items-center justify-center w-8 h-8 text-muted-foreground hover:text-error hover:bg-error/10 rounded-lg transition-all duration-250"
                >
                  <Icon name="XMarkIcon" size={20} />
                </button>
              )}
            </div>

            {isUploading && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Uploading...</span>
                  <span className="text-sm font-medium text-primary">{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}

            {!isUploading && uploadProgress === 0 && (
              <button
                onClick={handleUpload}
                className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
              >
                <Icon name="PaperAirplaneIcon" size={20} />
                <span>Send Voice Note</span>
              </button>
            )}

            {uploadProgress === 100 && (
              <div className="flex items-center justify-center space-x-2 p-3 bg-success/10 text-success rounded-lg">
                <Icon name="CheckCircleIcon" size={20} />
                <span className="text-sm font-medium">Voice note sent successfully!</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-4 p-4 bg-primary/5 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="InformationCircleIcon" size={20} className="text-primary mt-0.5 flex-shrink-0" />
          <div className="text-sm text-muted-foreground leading-relaxed">
            <p className="font-medium text-foreground mb-1">Voice Note Guidelines</p>
            <ul className="space-y-1 list-disc list-inside">
              <li>Keep recordings under 5 minutes for best results</li>
              <li>Speak clearly and mention specific areas of focus</li>
              <li>Sue will review before your scheduled reading</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoiceNoteUpload;