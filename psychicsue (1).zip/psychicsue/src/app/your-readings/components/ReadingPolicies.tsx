import Icon from '@/components/ui/AppIcon';

interface Policy {
  icon: string;
  title: string;
  description: string;
}

const ReadingPolicies = () => {
  const policies: Policy[] = [
    {
      icon: 'ClockIcon',
      title: 'Cancellation Policy',
      description: 'Cancel or reschedule up to 24 hours before your reading for a full refund. Cancellations within 24 hours are non-refundable but can be rescheduled once.'
    },
    {
      icon: 'ShieldCheckIcon',
      title: 'Privacy & Confidentiality',
      description: 'All readings are completely confidential. Your personal information and session details are protected and never shared with third parties.'
    },
    {
      icon: 'VideoCameraIcon',
      title: 'Technical Requirements',
      description: 'Virtual readings require stable internet connection, working camera and microphone. We recommend using Chrome or Safari browsers for best experience.'
    },
    {
      icon: 'ArrowPathIcon',
      title: 'Rescheduling',
      description: 'Members can reschedule readings up to 3 times per booking. Please provide at least 24 hours notice to maintain your priority booking status.'
    }
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-12 h-12 bg-accent/20 rounded-full">
          <Icon name="DocumentTextIcon" size={24} className="text-accent-foreground" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Reading Policies</h3>
          <p className="text-sm text-muted-foreground">Important information for your sessions</p>
        </div>
      </div>

      <div className="space-y-4">
        {policies.map((policy, index) => (
          <div key={index} className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-center w-10 h-10 bg-primary/20 rounded-full flex-shrink-0">
              <Icon name={policy.icon as any} size={20} className="text-primary" />
            </div>
            <div className="flex-1">
              <h4 className="text-base font-semibold text-foreground mb-1">{policy.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{policy.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20">
        <div className="flex items-start space-x-3">
          <Icon name="InformationCircleIcon" size={20} className="text-primary mt-0.5 flex-shrink-0" />
          <div className="text-sm text-foreground leading-relaxed">
            <p className="font-medium mb-2">Questions About Policies?</p>
            <p className="text-muted-foreground">
              If you have any questions about our reading policies or need special accommodations, please contact us at{' '}
              <a href="mailto:readings@psychicsue.com" className="text-primary hover:underline">
                readings@psychicsue.com
              </a>{' '}
              or call us at{' '}
              <a href="tel:+442071234567" className="text-primary hover:underline">
                +44 20 7123 4567
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReadingPolicies;