'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface UpcomingReading {
  id: string;
  type: string;
  date: string;
  time: string;
  duration: string;
  focusAreas: string[];
  preparationNotes: string;
  sessionLink?: string;
  imageUrl: string;
  imageAlt: string;
}

interface UpcomingReadingCardProps {
  reading: UpcomingReading;
}

const UpcomingReadingCard = ({ reading }: UpcomingReadingCardProps) => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (!isHydrated) return;

    const calculateTimeRemaining = () => {
      const sessionDateTime = new Date(`${reading.date} ${reading.time}`);
      const now = new Date();
      const difference = sessionDateTime.getTime() - now.getTime();

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeRemaining({ days, hours, minutes, seconds });
      }
    };

    calculateTimeRemaining();
    const interval = setInterval(calculateTimeRemaining, 1000);

    return () => clearInterval(interval);
  }, [isHydrated, reading.date, reading.time]);

  const handleJoinSession = () => {
    if (reading.sessionLink) {
      window.open(reading.sessionLink, '_blank');
    }
  };

  const handleReschedule = () => {
    // Reschedule functionality
  };

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
          <div className="h-20 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm hover:shadow-md transition-all duration-250">
      <div className="relative h-48 overflow-hidden">
        <AppImage
          src={reading.imageUrl}
          alt={reading.imageAlt}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent"></div>
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-2xl font-semibold text-white mb-1">{reading.type}</h3>
          <p className="text-white/90 text-sm font-caption">{reading.duration}</p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-primary/5 rounded-lg p-4">
          <p className="text-sm font-medium text-muted-foreground mb-3 font-caption">TIME UNTIL YOUR READING</p>
          <div className="grid grid-cols-4 gap-3">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{timeRemaining.days}</div>
              <div className="text-xs text-muted-foreground mt-1 font-caption">DAYS</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{timeRemaining.hours}</div>
              <div className="text-xs text-muted-foreground mt-1 font-caption">HOURS</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{timeRemaining.minutes}</div>
              <div className="text-xs text-muted-foreground mt-1 font-caption">MINS</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{timeRemaining.seconds}</div>
              <div className="text-xs text-muted-foreground mt-1 font-caption">SECS</div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center space-x-3 text-foreground">
            <Icon name="CalendarIcon" size={20} className="text-primary" />
            <span className="font-medium">{reading.date}</span>
          </div>
          <div className="flex items-center space-x-3 text-foreground">
            <Icon name="ClockIcon" size={20} className="text-primary" />
            <span className="font-medium">{reading.time}</span>
          </div>
        </div>

        {reading.focusAreas.length > 0 && (
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-2 font-caption">YOUR FOCUS AREAS</p>
            <div className="flex flex-wrap gap-2">
              {reading.focusAreas.map((area, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-accent/20 text-accent-foreground rounded-full text-sm font-caption"
                >
                  {area}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="LightBulbIcon" size={20} className="text-accent mt-1 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-foreground mb-1">Preparation Guidance from Sue</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{reading.preparationNotes}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          {reading.sessionLink && (
            <button
              onClick={handleJoinSession}
              className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
            >
              <Icon name="VideoCameraIcon" size={20} />
              <span>Join Session</span>
            </button>
          )}
          <button
            onClick={handleReschedule}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-muted text-foreground rounded-lg font-medium hover:bg-muted/80 transition-all duration-250 active:scale-95"
          >
            <Icon name="ArrowPathIcon" size={20} />
            <span>Reschedule</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default UpcomingReadingCard;