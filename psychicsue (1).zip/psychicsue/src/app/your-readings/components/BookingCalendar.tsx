'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface TimeSlot {
  time: string;
  available: boolean;
}

interface BookingCalendarProps {
  onBookingComplete?: (date: string, time: string, type: string) => void;
}

const BookingCalendar = ({ onBookingComplete }: BookingCalendarProps) => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('');
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const readingTypes = [
    { id: 'quick', name: 'Quick Insight', duration: '15 mins', price: '£35' },
    { id: 'standard', name: 'Standard Reading', duration: '30 mins', price: '£65' },
    { id: 'deep', name: 'Deep Dive', duration: '60 mins', price: '£120' }
  ];

  const timeSlots: TimeSlot[] = [
    { time: '09:00', available: true },
    { time: '10:00', available: true },
    { time: '11:00', available: false },
    { time: '12:00', available: true },
    { time: '14:00', available: true },
    { time: '15:00', available: true },
    { time: '16:00', available: false },
    { time: '17:00', available: true }
  ];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    return { daysInMonth, startingDayOfWeek };
  };

  const handlePreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const handleDateSelect = (day: number) => {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    const formattedDate = date.toLocaleDateString('en-GB', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric' 
    });
    setSelectedDate(formattedDate);
  };

  const handleBooking = () => {
    if (selectedDate && selectedTime && selectedType && onBookingComplete) {
      onBookingComplete(selectedDate, selectedTime, selectedType);
      setSelectedDate('');
      setSelectedTime('');
      setSelectedType('');
    }
  };

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/2"></div>
          <div className="h-64 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  const { daysInMonth, startingDayOfWeek } = getDaysInMonth(currentMonth);
  const monthName = currentMonth.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-12 h-12 bg-primary/20 rounded-full">
          <Icon name="CalendarIcon" size={24} className="text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Priority Booking</h3>
          <p className="text-sm text-muted-foreground">Schedule your next reading with Sue</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-3 font-caption">SELECT READING TYPE</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {readingTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`p-4 rounded-lg border-2 transition-all duration-250 ${
                  selectedType === type.id
                    ? 'border-primary bg-primary/10' :'border-border hover:border-primary/50'
                }`}
              >
                <p className="font-semibold text-foreground">{type.name}</p>
                <p className="text-sm text-muted-foreground mt-1">{type.duration}</p>
                <p className="text-lg font-bold text-primary mt-2">{type.price}</p>
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm font-medium text-muted-foreground mb-3 font-caption">SELECT DATE</p>
          <div className="bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={handlePreviousMonth}
                className="flex items-center justify-center w-10 h-10 rounded-lg hover:bg-muted transition-all duration-250"
              >
                <Icon name="ChevronLeftIcon" size={20} />
              </button>
              <h4 className="text-base font-semibold text-foreground">{monthName}</h4>
              <button
                onClick={handleNextMonth}
                className="flex items-center justify-center w-10 h-10 rounded-lg hover:bg-muted transition-all duration-250"
              >
                <Icon name="ChevronRightIcon" size={20} />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2 font-caption">
                  {day}
                </div>
              ))}
              {Array.from({ length: startingDayOfWeek }, (_, i) => (
                <div key={`empty-${i}`} />
              ))}
              {Array.from({ length: daysInMonth }, (_, i) => {
                const day = i + 1;
                const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                const formattedDate = date.toLocaleDateString('en-GB', { 
                  day: '2-digit', 
                  month: '2-digit', 
                  year: 'numeric' 
                });
                const isSelected = selectedDate === formattedDate;
                const isPast = date < new Date(new Date().setHours(0, 0, 0, 0));

                return (
                  <button
                    key={day}
                    onClick={() => !isPast && handleDateSelect(day)}
                    disabled={isPast}
                    className={`aspect-square rounded-lg text-sm font-medium transition-all duration-250 ${
                      isPast
                        ? 'text-muted-foreground/30 cursor-not-allowed'
                        : isSelected
                        ? 'bg-primary text-primary-foreground shadow-sm'
                        : 'text-foreground hover:bg-muted'
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {selectedDate && (
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3 font-caption">SELECT TIME</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {timeSlots.map((slot) => (
                <button
                  key={slot.time}
                  onClick={() => slot.available && setSelectedTime(slot.time)}
                  disabled={!slot.available}
                  className={`px-4 py-3 rounded-lg font-medium transition-all duration-250 ${
                    !slot.available
                      ? 'bg-muted/50 text-muted-foreground cursor-not-allowed'
                      : selectedTime === slot.time
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'bg-muted text-foreground hover:bg-muted/80'
                  }`}
                >
                  {slot.time}
                </button>
              ))}
            </div>
          </div>
        )}

        {selectedDate && selectedTime && selectedType && (
          <button
            onClick={handleBooking}
            className="w-full flex items-center justify-center space-x-2 px-6 py-4 bg-primary text-primary-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
          >
            <Icon name="CheckCircleIcon" size={20} />
            <span>Confirm Booking</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default BookingCalendar;