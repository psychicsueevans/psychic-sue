'use client';

import { useState } from 'react';
import UpcomingReadingCard from './UpcomingReadingCard';
import ReadingHistoryCard from './ReadingHistoryCard';
import VoiceNoteUpload from './VoiceNoteUpload';
import PreparationGuide from './PreparationGuide';
import BookingCalendar from './BookingCalendar';
import ReadingPolicies from './ReadingPolicies';
import Icon from '@/components/ui/AppIcon';

interface UpcomingReading {
  id: string;
  type: string;
  date: string;
  time: string;
  duration: string;
  focusAreas: string[];
  preparationNotes: string;
  sessionLink?: string;
  imageUrl: string;
  imageAlt: string;
}

interface PastReading {
  id: string;
  type: string;
  date: string;
  duration: string;
  rating: number;
  insights: string;
  followUpNotes: string;
  recordingUrl?: string;
  imageUrl: string;
  imageAlt: string;
}

const YourReadingsInteractive = () => {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'history' | 'book'>('upcoming');

  const upcomingReadings: UpcomingReading[] = [
  {
    id: '1',
    type: 'Deep Dive Reading',
    date: '15/01/2026',
    time: '14:00',
    duration: '60 minutes',
    focusAreas: ['Career Transition', 'Relationship Clarity', 'Life Purpose'],
    preparationNotes: 'Take some quiet time before our session to reflect on the areas where you feel most stuck or uncertain. Write down any specific questions that have been weighing on your mind. Remember, there are no wrong questions - trust your intuition about what you need guidance on.',
    sessionLink: 'https://zoom.us/j/example',
    imageUrl: "https://images.unsplash.com/photo-1711352632315-c0fd4757f14b",
    imageAlt: 'Peaceful meditation space with candles, crystals, and tarot cards arranged on purple velvet cloth'
  }];


  const pastReadings: PastReading[] = [
  {
    id: '1',
    type: 'Standard Reading',
    date: '28/12/2025',
    duration: '30 minutes',
    rating: 5,
    insights: 'The cards revealed a significant transformation period ahead, particularly around career opportunities. The Tower card suggests necessary changes that will ultimately lead to growth. Trust the process and remain open to unexpected opportunities.',
    followUpNotes: 'Continue your daily meditation practice. Pay attention to synchronicities over the next two weeks, especially related to communication and new connections.',
    recordingUrl: 'https://example.com/recording1.mp3',
    imageUrl: "https://images.unsplash.com/photo-1627764574768-539effd9af35",
    imageAlt: 'Mystical tarot card spread on dark wooden table with soft candlelight illumination'
  },
  {
    id: '2',
    type: 'Quick Insight',
    date: '10/12/2025',
    duration: '15 minutes',
    rating: 5,
    insights: 'The Three of Cups appeared, indicating celebration and positive social connections coming your way. Your energy is aligned with abundance and joy. Continue nurturing your relationships.',
    followUpNotes: 'Focus on gratitude practices this week. The universe is responding to your positive vibrations.',
    imageUrl: "https://images.unsplash.com/photo-1704527496704-b39fa191586a",
    imageAlt: 'Colorful tarot cards fanned out showing mystical imagery and symbols on purple background'
  },
  {
    id: '3',
    type: 'Deep Dive Reading',
    date: '22/11/2025',
    duration: '60 minutes',
    rating: 5,
    insights: 'A comprehensive reading revealed patterns in your relationships and career path. The Empress and Emperor cards together suggest a need for balance between nurturing and structure. Your intuition is strong right now - trust it.',
    followUpNotes: 'Work on setting healthy boundaries while maintaining compassion. Journal about your dreams this month as they contain important messages.',
    recordingUrl: 'https://example.com/recording3.mp3',
    imageUrl: "https://images.unsplash.com/photo-1556739442-4c892bcbe8ba",
    imageAlt: 'Professional psychic reading setup with ornate tarot deck, amethyst crystals, and sage bundle'
  }];


  const handleVoiceNoteUpload = (file: File) => {
    console.log('Voice note uploaded:', file.name);
  };

  const handleBookingComplete = (date: string, time: string, type: string) => {
    console.log('Booking confirmed:', { date, time, type });
  };

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
        <div className="flex items-start space-x-4">
          <div className="flex items-center justify-center w-14 h-14 bg-primary/20 rounded-full flex-shrink-0">
            <Icon name="SparklesIcon" size={28} className="text-primary" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-semibold text-foreground mb-2">Your Spiritual Journey</h2>
            <p className="text-muted-foreground leading-relaxed">
              Welcome to your personal readings space. Here you can manage upcoming sessions, review past insights, and book new readings with priority member access. Sue is here to guide you on your path to clarity and transformation.
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-3 border-b border-border">
        <button
          onClick={() => setActiveTab('upcoming')}
          className={`flex items-center space-x-2 px-6 py-3 font-medium transition-all duration-250 border-b-2 ${
          activeTab === 'upcoming' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`
          }>

          <Icon name="CalendarDaysIcon" size={20} />
          <span>Upcoming Readings</span>
          {upcomingReadings.length > 0 &&
          <span className="flex items-center justify-center w-6 h-6 bg-primary text-primary-foreground rounded-full text-xs font-bold">
              {upcomingReadings.length}
            </span>
          }
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center space-x-2 px-6 py-3 font-medium transition-all duration-250 border-b-2 ${
          activeTab === 'history' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`
          }>

          <Icon name="ClockIcon" size={20} />
          <span>Reading History</span>
        </button>
        <button
          onClick={() => setActiveTab('book')}
          className={`flex items-center space-x-2 px-6 py-3 font-medium transition-all duration-250 border-b-2 ${
          activeTab === 'book' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`
          }>

          <Icon name="PlusCircleIcon" size={20} />
          <span>Book New Reading</span>
        </button>
      </div>

      {activeTab === 'upcoming' &&
      <div className="space-y-8">
          {upcomingReadings.length > 0 ?
        <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {upcomingReadings.map((reading) =>
            <UpcomingReadingCard key={reading.id} reading={reading} />
            )}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <VoiceNoteUpload onUploadComplete={handleVoiceNoteUpload} />
                <PreparationGuide />
              </div>
            </> :

        <div className="text-center py-16">
              <div className="flex items-center justify-center w-20 h-20 bg-muted rounded-full mx-auto mb-4">
                <Icon name="CalendarDaysIcon" size={40} className="text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">No Upcoming Readings</h3>
              <p className="text-muted-foreground mb-6">Book your next session with Sue to continue your spiritual journey</p>
              <button
            onClick={() => setActiveTab('book')}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250">

                <Icon name="PlusCircleIcon" size={20} />
                <span>Book a Reading</span>
              </button>
            </div>
        }
        </div>
      }

      {activeTab === 'history' &&
      <div className="space-y-6">
          {pastReadings.length > 0 ?
        <>
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Showing {pastReadings.length} past reading{pastReadings.length !== 1 ? 's' : ''}
                </p>
              </div>
              {pastReadings.map((reading) =>
          <ReadingHistoryCard key={reading.id} reading={reading} />
          )}
            </> :

        <div className="text-center py-16">
              <div className="flex items-center justify-center w-20 h-20 bg-muted rounded-full mx-auto mb-4">
                <Icon name="ClockIcon" size={40} className="text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">No Reading History</h3>
              <p className="text-muted-foreground">Your completed readings will appear here</p>
            </div>
        }
        </div>
      }

      {activeTab === 'book' &&
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <BookingCalendar onBookingComplete={handleBookingComplete} />
          </div>
          <div className="space-y-6">
            <PreparationGuide />
            <ReadingPolicies />
          </div>
        </div>
      }
    </div>);

};

export default YourReadingsInteractive;