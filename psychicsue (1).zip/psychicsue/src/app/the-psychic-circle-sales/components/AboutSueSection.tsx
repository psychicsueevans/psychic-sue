import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

const AboutSueSection = () => {
  const mediaBadges = ['BBC', 'Channel 4', 'Paul O\'Grady Show', 'ITV', 'Amazon Prime'];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 rounded-full bg-accent/20 px-4 py-2 text-sm font-medium text-accent-foreground mb-4">
            <Icon name="UserIcon" size={16} />
            <span className="font-caption">Your Guide</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl">
            Learn From Someone Who's Actually Done It
          </h2>
        </div>
        
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          {/* Photo placeholder */}
          <div className="relative">
            <div className="absolute -top-4 -right-4 z-10">
              <div className="inline-flex items-center space-x-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg">
                <Icon name="StarIcon" size={16} variant="solid" />
                <span>50+ Years Experience</span>
              </div>
            </div>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border aspect-square bg-gradient-to-br from-primary/20 to-accent/20">
              <AppImage
                src="/assets/images/no_image.png"
                alt="Psychic Sue - 50+ years experience in tarot reading"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          {/* Text content */}
          <div className="space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed">
              I'm Psychic Sue. 50+ years helping people through tarot. Featured on BBC, Channel 4, Paul O'Grady Show, ITV, and Amazon Prime - Psychic Investigators watched worldwide. Everything I know is inside The Psychic Circle.
            </p>
            
            {/* Media badges */}
            <div>
              <p className="text-sm font-semibold text-muted-foreground mb-3">AS FEATURED ON:</p>
              <div className="flex flex-wrap gap-3">
                {mediaBadges?.map((badge, index) => (
                  <div
                    key={index}
                    className="inline-flex items-center rounded-lg bg-card px-4 py-2 text-sm font-medium border border-border shadow-sm"
                  >
                    <Icon name="TvIcon" size={16} className="mr-2 text-primary" />
                    {badge}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSueSection;