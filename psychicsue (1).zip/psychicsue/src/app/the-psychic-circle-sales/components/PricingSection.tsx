'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface PricingSectionProps {
  onSelectPayment: (plan: string) => void;
}

const PricingSection = ({ onSelectPayment }: PricingSectionProps) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (!isHydrated) return;

    const launchDate = new Date('2026-01-15T00:00:00').getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = launchDate - now;

      if (distance > 0) {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [isHydrated]);

  const pricingPlans = [
    {
      name: 'Monthly Membership',
      price: '£97',
      period: 'per month',
      description: 'Perfect for those wanting to explore The Psychic Circle with flexibility',
      features: [
        'Full access to all 8 course modules',
        'Direct messaging with Sue',
        'Weekly spiritual guidance',
        'Community forum access',
        'Resources library',
        'Priority booking privileges',
        '20% discount on readings',
        'Monthly live Q&A sessions'
      ],
      popular: false,
      savings: null
    },
    {
      name: 'Annual Membership',
      price: '£997',
      period: 'per year',
      description: 'Best value for committed spiritual seekers - save over £160',
      features: [
        'Everything in Monthly Membership',
        'Save £167 compared to monthly',
        'Quarterly one-on-one guidance calls',
        'Exclusive annual retreat invitation',
        'Advanced masterclass access',
        'Lifetime community membership',
        'Birthday month complimentary reading',
        'Priority support response'
      ],
      popular: true,
      savings: 'Save £167'
    }
  ];

  const valueStack = [
    { item: '8 Comprehensive Course Modules', value: '£497' },
    { item: 'Direct WhatsApp Access to Sue', value: '£297' },
    { item: 'Weekly Spiritual Guidance', value: '£197' },
    { item: 'Resources Library & Meditations', value: '£147' },
    { item: 'Community Forum Access', value: '£97' },
    { item: 'Priority Booking Privileges', value: '£197' },
    { item: '20% Discount on All Readings', value: '£247' },
    { item: 'Monthly Live Q&A Sessions', value: '£147' }
  ];

  const totalValue = valueStack.reduce((sum, item) => {
    return sum + parseInt(item.value.replace('£', ''));
  }, 0);

  if (!isHydrated) {
    return (
      <section className="py-16 lg:py-24 bg-background">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-4">
              Choose Your Membership Plan
            </h2>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-12 lg:mb-16">
          <div className="inline-flex items-center space-x-2 rounded-full bg-error/10 px-4 py-2 text-sm font-medium text-error-foreground mb-6">
            <Icon name="ClockIcon" size={16} variant="solid" />
            <span className="font-caption">Limited Time Launch Offer - Ends January 15th</span>
          </div>
          
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-4">
            Choose Your Membership Plan
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Invest in your spiritual development with lifetime access to transformative content, personal guidance, and a supportive community.
          </p>
        </div>

        <div className="mb-12 rounded-2xl bg-gradient-to-br from-error/10 to-warning/10 p-8 border-2 border-error/20">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold mb-2">Launch Countdown</h3>
            <p className="text-muted-foreground">Secure your founding member discount before time runs out</p>
          </div>
          
          <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto">
            {[
              { label: 'Days', value: timeLeft.days },
              { label: 'Hours', value: timeLeft.hours },
              { label: 'Minutes', value: timeLeft.minutes },
              { label: 'Seconds', value: timeLeft.seconds }
            ].map((unit) => (
              <div key={unit.label} className="rounded-xl bg-card p-4 text-center shadow-lg border border-border">
                <div className="text-3xl font-bold text-primary data-text">{unit.value.toString().padStart(2, '0')}</div>
                <div className="text-sm text-muted-foreground font-caption mt-1">{unit.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-2 mb-16">
          {pricingPlans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl p-8 shadow-xl border-2 transition-all duration-250 hover:shadow-2xl hover:-translate-y-1 ${
                plan.popular
                  ? 'border-primary bg-gradient-to-br from-primary/5 to-secondary/10' :'border-border bg-card'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="inline-flex items-center space-x-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg">
                    <Icon name="StarIcon" size={16} variant="solid" />
                    <span>Most Popular</span>
                  </div>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-muted-foreground">{plan.description}</p>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline space-x-2">
                  <span className="text-5xl font-bold text-primary">{plan.price}</span>
                  <span className="text-lg text-muted-foreground">{plan.period}</span>
                </div>
                {plan.savings && (
                  <div className="mt-2 inline-flex items-center space-x-2 rounded-full bg-success/10 px-3 py-1">
                    <Icon name="CheckCircleIcon" size={16} variant="solid" className="text-success" />
                    <span className="text-sm font-semibold text-success-foreground">{plan.savings}</span>
                  </div>
                )}
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start space-x-3">
                    <Icon name="CheckCircleIcon" size={20} variant="solid" className="text-success flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onSelectPayment(plan.name)}
                className={`w-full rounded-lg px-6 py-4 text-lg font-semibold shadow-lg transition-all duration-250 hover:shadow-xl hover:-translate-y-0.5 active:scale-95 ${
                  plan.popular
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground'
                }`}
              >
                Join The Circle Now
              </button>

              <div className="mt-4 flex items-center justify-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <Icon name="LockClosedIcon" size={16} />
                  <span className="font-caption">Secure Checkout</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="ShieldCheckIcon" size={16} />
                  <span className="font-caption">SSL Protected</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-2xl bg-card p-8 shadow-xl border border-border">
          <h3 className="text-2xl font-bold text-center mb-8">Total Value Breakdown</h3>
          
          <div className="space-y-3 mb-6">
            {valueStack.map((item, index) => (
              <div key={index} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                <span className="text-foreground">{item.item}</span>
                <span className="font-semibold text-primary data-text">{item.value}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between py-4 border-t-2 border-primary">
            <span className="text-xl font-bold">Total Value</span>
            <span className="text-3xl font-bold text-primary data-text">£{totalValue.toLocaleString()}</span>
          </div>

          <div className="mt-6 text-center">
            <p className="text-lg text-muted-foreground mb-2">Your Investment</p>
            <p className="text-4xl font-bold text-success">From £97/month</p>
            <p className="text-sm text-muted-foreground mt-2 font-caption">Save over 95% on the total value</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;