'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';
import VIPWaitlistPopup from '@/components/common/VIPWaitlistPopup';

interface NewPricingSectionProps {
  onSelectPayment: (tier: string) => void;
}

export default function NewPricingSection({ onSelectPayment }: NewPricingSectionProps) {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  return (
    <section id="pricing" className="py-16 lg:py-24 bg-gradient-to-br from-secondary/5 to-accent/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-4">
            Choose Your Membership
          </h2>
          <p className="text-lg text-muted-foreground">
            Start with Circle Membership today, or join the VIP waitlist
          </p>
        </div>
        
        <div className="grid gap-8 lg:grid-cols-2 max-w-5xl mx-auto">
          {/* Circle Member */}
          <div className="relative rounded-2xl p-8 shadow-lg border-2 border-gray-200 bg-card transition-all duration-250 hover:shadow-xl hover:-translate-y-1">
            <div className="inline-flex items-center space-x-2 rounded-full bg-success/10 px-3 py-1 text-sm font-semibold text-success-foreground mb-4">
              <Icon name="CheckCircleIcon" size={16} variant="solid" className="text-success" />
              <span>AVAILABLE NOW</span>
            </div>
            
            <h3 className="text-2xl font-bold mb-2">Circle Member</h3>
            
            <div className="mb-6">
              <div className="flex items-baseline space-x-2">
                <span className="text-5xl font-bold text-primary">$35</span>
                <span className="text-lg text-muted-foreground">per month</span>
              </div>
            </div>
            
            <ul className="space-y-3 mb-8">
              {[
                'Complete 8-Module Course',
                '40+ Video Lessons',
                'Weekly Tarot Messages',
                'Guided Meditation Library',
                'Same-Day Digital Readings',
                'Exclusive Tools',
                'Cancel anytime'
              ].map((feature, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <Icon name="CheckCircleIcon" size={20} variant="solid" className="text-success flex-shrink-0 mt-0.5" />
                  <span className="text-foreground">{feature}</span>
                </li>
              ))}
            </ul>
            
            <button
              onClick={() => onSelectPayment('Circle Member - $35/month')}
              className="w-full rounded-lg bg-primary px-6 py-4 text-lg font-semibold text-primary-foreground shadow-lg transition-all duration-250 hover:shadow-xl hover:-translate-y-0.5 active:scale-95"
            >
              Join Now — $35/month
            </button>
          </div>
          
          {/* VIP Circle Member */}
          <div className="relative rounded-2xl p-8 shadow-2xl border-2 border-purple-300 bg-gradient-to-br from-white to-purple-50 transition-all duration-250 hover:shadow-[0_0_30px_rgba(168,85,247,0.4)] hover:-translate-y-1">
            {/* VIP FULL Badge - Top Right Corner */}
            <div className="absolute top-4 right-4 inline-flex items-center space-x-1 rounded-full bg-gradient-to-r from-orange-500 to-red-500 px-3 py-1.5 text-xs font-bold text-white shadow-lg">
              <Icon name="FireIcon" size={14} variant="solid" />
              <span>VIP FULL</span>
            </div>
            
            <div className="inline-flex items-center space-x-2 rounded-full bg-error/10 px-3 py-1 text-sm font-semibold text-error-foreground mb-4">
              <Icon name="XCircleIcon" size={16} variant="solid" className="text-error" />
              <span>CURRENTLY FULL</span>
            </div>
            
            <h3 className="text-2xl font-bold mb-2">VIP Circle Member</h3>
            
            <div className="mb-6">
              <div className="flex items-baseline space-x-2">
                <span className="text-5xl font-bold text-primary">$547</span>
                <span className="text-lg text-muted-foreground">for 6 months</span>
              </div>
            </div>
            
            <p className="text-sm font-semibold text-muted-foreground mb-3">Everything in Circle Member PLUS:</p>
            
            <ul className="space-y-3 mb-8">
              {[
                'Monthly 60-minute personal reading with Sue',
                'Direct WhatsApp access',
                'Voice note support',
                'Priority booking always',
                '20% discount on additional readings'
              ].map((feature, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <Icon name="CheckCircleIcon" size={20} variant="solid" className="text-success flex-shrink-0 mt-0.5" />
                  <span className="text-foreground">{feature}</span>
                </li>
              ))}
            </ul>
            
            <button
              onClick={() => setIsWaitlistOpen(true)}
              className="w-full rounded-lg bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4 text-lg font-semibold text-white shadow-lg transition-all duration-250 hover:shadow-xl hover:-translate-y-0.5 active:scale-95"
            >
              Join VIP Waitlist
            </button>
            
            <p className="text-xs text-muted-foreground text-center mt-4 font-caption">
              Only 30 VIP spots exist and all are currently taken. Join the waitlist to be notified when a space opens.
            </p>
          </div>
        </div>
      </div>

      <VIPWaitlistPopup isOpen={isWaitlistOpen} onClose={() => setIsWaitlistOpen(false)} />
    </section>
  );
}