import Icon from '@/components/ui/AppIcon';

const IsThisForYouSection = () => {
  const points = [
    "You've always felt drawn to tarot but don't know where to start",
    "You\'ve tried learning but it hasn\'t clicked",
    "You want to trust what comes through in readings",
    "You're curious about your abilities but unsure if they're real",
    "You'd love to read for others, maybe professionally",
    "You want ongoing guidance, not a one-time course"
  ];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-purple-100 via-purple-50 to-indigo-50">
      <div className="mx-auto max-w-4xl px-6">
        <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-12 text-center">
          The Psychic Circle Is For You If...
        </h2>
        
        <div className="space-y-4">
          {points?.map((point, index) => (
            <div
              key={index}
              className="flex items-start space-x-4 rounded-xl bg-white p-6 shadow-md border border-purple-100 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-250"
            >
              <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-success flex-shrink-0 mt-0.5" />
              <p className="text-lg text-foreground">{point}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IsThisForYouSection;