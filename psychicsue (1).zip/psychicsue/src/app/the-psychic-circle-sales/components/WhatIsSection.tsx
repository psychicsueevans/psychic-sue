const WhatIsSection = () => {
  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="mx-auto max-w-4xl px-6">
        <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-6 text-center">
          What Is The Psychic Circle?
        </h2>
        
        <p className="text-lg text-muted-foreground leading-relaxed text-center">
          My private membership for people serious about developing psychic abilities. Access everything I've learned over 50+ years — techniques, lessons, and tools that work. This isn't a course you buy and forget. It's an ongoing journey with weekly guidance and a clear path from beginner to confident reader.
        </p>
      </div>
    </section>
  );
};

export default WhatIsSection;