'use client';

import { useState } from 'react';
import NewHeroSection from './NewHeroSection';
import WhatIsSection from './WhatIsSection';
import EverythingYouGetSection from './EverythingYouGetSection';
import ModuleCourseSection from './ModuleCourseSection';
import IsThisForYouSection from './IsThisForYouSection';
import AboutSueSection from './AboutSueSection';
import NewPricingSection from './NewPricingSection';
import NewFAQSection from './NewFAQSection';
import NewFinalCTASection from './NewFinalCTASection';
import PaymentModal from './PaymentModal';

const PsychicCircleInteractive = () => {
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('');

  const handleJoinNow = () => {
    setSelectedPlan('Circle Member - $35/month');
    setIsPaymentModalOpen(true);
  };

  const handleSelectPayment = (plan: string) => {
    setSelectedPlan(plan);
    setIsPaymentModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsPaymentModalOpen(false);
  };

  return (
    <>
      <NewHeroSection onJoinNow={handleJoinNow} />
      <WhatIsSection />
      <EverythingYouGetSection />
      <ModuleCourseSection />
      <IsThisForYouSection />
      <AboutSueSection />
      <NewPricingSection onSelectPayment={handleSelectPayment} />
      <NewFAQSection />
      <NewFinalCTASection onJoinNow={handleJoinNow} />
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={handleCloseModal}
        selectedPlan={selectedPlan}
      />
    </>
  );
};

export default PsychicCircleInteractive;