import Icon from '@/components/ui/AppIcon';

const ModuleCourseSection = () => {
  const modules = [
    { number: 1, title: 'Developing Your Abilities', special: false },
    { number: 2, title: 'Protection & Energy', special: false },
    { number: 3, title: 'Working with Spirit', special: false },
    { number: 4, title: 'Knowing What\'s Real', special: false },
    { number: 5, title: 'Tarot & Divination', special: false },
    { number: 6, title: 'Healing & Manifestation', special: false },
    { number: 7, title: 'Working with Others', special: false },
    { number: 8, title: 'From Gift to Career', special: true }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-gray-50 via-purple-50 to-indigo-50">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-4">
            Complete 8-Module Psychic Development Course
          </h2>
          <p className="text-lg text-muted-foreground">
            The ONLY course that teaches you how to turn your gift into a career
          </p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {modules?.map((module) => (
            <div
              key={module.number}
              className={`rounded-xl p-6 shadow-xl border transition-all duration-250 hover:shadow-2xl hover:-translate-y-1 ${
                module.special
                  ? 'bg-gradient-to-br from-purple-100 via-purple-50 to-indigo-100 border-purple-300 shadow-purple-200' : 'bg-white border-gray-200'
              }`}
            >
              {module.special && (
                <div className="inline-flex items-center space-x-1 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground mb-3">
                  <Icon name="StarIcon" size={12} variant="solid" />
                  <span>Special Module</span>
                </div>
              )}
              <div className="flex items-center space-x-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20 text-primary font-bold text-lg">
                  {module.number}
                </div>
                <h3 className="text-lg font-semibold flex-1">{module.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ModuleCourseSection;