import Icon from '@/components/ui/AppIcon';

interface FinalCTASectionProps {
  onJoinNow: () => void;
}

const FinalCTASection = ({ onJoinNow }: FinalCTASectionProps) => {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <div className="mb-8">
          <div className="inline-flex items-center space-x-2 rounded-full bg-accent/20 px-4 py-2 text-sm font-medium text-accent-foreground mb-6">
            <Icon name="SparklesIcon" size={16} variant="solid" />
            <span className="font-caption">Limited Founding Member Spots Available</span>
          </div>
          
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-6">
            Your Spiritual Transformation Awaits
          </h2>
          
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join The Psychic Circle today and begin your journey toward intuitive mastery, spiritual confidence, and a supportive community that understands your path. With 50+ years of Sue\'s wisdom guiding you, there\'s never been a better time to invest in your spiritual development.
          </p>
        </div>

        <div className="space-y-6 mb-8">
          <div className="flex items-center justify-center space-x-3">
            <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-success" />
            <span className="text-lg font-medium">Lifetime access to all course content</span>
          </div>
          <div className="flex items-center justify-center space-x-3">
            <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-success" />
            <span className="text-lg font-medium">Direct personal guidance from Sue</span>
          </div>
          <div className="flex items-center justify-center space-x-3">
            <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-success" />
            <span className="text-lg font-medium">Supportive community of spiritual seekers</span>
          </div>
          <div className="flex items-center justify-center space-x-3">
            <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-success" />
            <span className="text-lg font-medium">14-day satisfaction guarantee</span>
          </div>
        </div>

        <button
          onClick={onJoinNow}
          className="inline-flex items-center justify-center space-x-2 rounded-lg bg-primary px-10 py-5 text-xl font-bold text-primary-foreground shadow-2xl hover:shadow-3xl hover:-translate-y-1 transition-all duration-250 active:scale-95 mb-6"
        >
          <span>Join The Psychic Circle Now</span>
          <Icon name="ArrowRightIcon" size={24} />
        </button>

        <p className="text-sm text-muted-foreground font-caption">
          Secure checkout • SSL protected • 14-day money-back guarantee
        </p>

        <div className="mt-12 pt-8 border-t border-border">
          <p className="text-muted-foreground mb-4">Prefer to speak with someone first?</p>
          <a
            href="/contact"
            className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors duration-250 font-semibold"
          >
            <Icon name="PhoneIcon" size={20} />
            <span>Contact us for a personal consultation</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default FinalCTASection;