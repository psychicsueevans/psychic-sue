'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface FAQ {
  question: string;
  answer: string;
}

const NewFAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQ[] = [
    {
      question: 'How is this different from buying a course?',
      answer: 'The Psychic Circle is an ongoing membership with weekly guidance, not a one-time purchase. You get continuous support, new content regularly, and direct access to Sue. It\'s a living, evolving journey rather than a static course you complete and forget.'
    },
    {
      question: 'I\'m a complete beginner — is this too advanced?',
      answer: 'Not at all! The course starts from the very beginning. Module 1 covers the basics of developing your abilities, and everything builds from there. Many of our most successful members started with zero experience.'
    },
    {
      question: 'What if I\'m not sure I\'m psychic?',
      answer: 'That\'s exactly why this membership exists. The early modules help you discover and develop your natural abilities. Everyone has intuitive gifts — this course teaches you how to recognize and strengthen yours.'
    },
    {
      question: 'What are Same-Day Digital Readings?',
      answer: 'These are written tarot readings delivered digitally within 24 hours. Submit your question, and Sue provides a detailed reading with card interpretations and guidance. Perfect for when you need answers quickly.'
    },
    {
      question: 'Can I cancel anytime?',
      answer: 'Yes! Circle Membership is month-to-month with no long-term commitment. You can cancel anytime and retain access until the end of your billing period. VIP Circle is a one-time 6-month payment with no auto-renewal.'
    },
    {
      question: 'What\'s the difference between Circle Member and VIP?',
      answer: 'Circle Member ($35/month) gives you full access to all course content, weekly messages, and community. VIP Circle Member ($547/6 months) adds monthly personal readings with Sue, direct WhatsApp access, voice note support, and priority booking. VIP is currently full with only 30 spots available.'
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="mx-auto max-w-4xl px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-4">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-xl bg-card shadow-md border border-border overflow-hidden transition-all duration-250 hover:shadow-lg"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full flex items-center justify-between p-6 text-left transition-colors duration-250 hover:bg-muted"
              >
                <span className="text-lg font-semibold pr-4">{faq.question}</span>
                <Icon
                  name="ChevronDownIcon"
                  size={24}
                  className={`flex-shrink-0 text-primary transition-transform duration-250 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-6 animate-slide-down">
                  <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewFAQSection;