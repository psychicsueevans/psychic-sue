import Icon from '@/components/ui/AppIcon';

const TrustBadgesSection = () => {
  const trustBadges = [
    {
      icon: 'ShieldCheckIcon',
      title: 'SSL Secured',
      description: 'Bank-level encryption'
    },
    {
      icon: 'LockClosedIcon',
      title: 'Secure Payments',
      description: 'Stripe & PayPal protected'
    },
    {
      icon: 'CheckBadgeIcon',
      title: '50+ Years Experience',
      description: 'Proven track record'
    },
    {
      icon: 'TvIcon',
      title: 'Media Featured',
      description: 'BBC & Channel 4'
    },
    {
      icon: 'UserGroupIcon',
      title: '500+ Members',
      description: 'Trusted community'
    },
    {
      icon: 'StarIcon',
      title: '5-Star Rated',
      description: 'Excellent reviews'
    }
  ];

  return (
    <section className="py-12 bg-card border-y border-border">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {trustBadges.map((badge, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center space-y-2"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Icon name={badge.icon as any} size={24} variant="solid" className="text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm">{badge.title}</p>
                <p className="text-xs text-muted-foreground font-caption">{badge.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustBadgesSection;