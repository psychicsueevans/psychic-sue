import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface NewHeroSectionProps {
  onJoinNow: () => void;
}

const NewHeroSection = ({ onJoinNow }: NewHeroSectionProps) => {
  const scrollToPricing = () => {
    const pricingSection = document.getElementById('pricing');
    pricingSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 py-24 lg:py-32 overflow-hidden">
      {/* Hero Background Image */}
      <div className="absolute inset-0">
        <AppImage
          src="/assets/images/tarot-3864316_1280-1768071845541.jpg"
          alt="Mystical tarot cards spread on purple velvet cloth with candles, crystals, and atmospheric lighting"
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/60 via-purple-800/70 to-indigo-900/80"></div>
      
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        {/* Join Today Badge */}
        <div className="inline-flex items-center space-x-2 rounded-full bg-white/10 backdrop-blur-sm px-4 py-2 text-sm font-medium text-white mb-6 border border-white/20">
          <Icon name="SparklesIcon" size={16} variant="solid" />
          <span className="font-caption">Join Today</span>
        </div>
        
        {/* Heading */}
        <h1 className="text-4xl font-bold tracking-tight lg:text-5xl xl:text-6xl text-white mb-6">
          Welcome to The Psychic Circle
        </h1>
        
        {/* Subtext */}
        <p className="text-lg lg:text-xl text-purple-100 mb-8 max-w-3xl mx-auto leading-relaxed">
          Your path to developing real psychic abilities — with guidance from one of the UK's most experienced tarot readers.
        </p>
        
        {/* Join Button */}
        <button
          onClick={scrollToPricing}
          className="inline-flex items-center justify-center space-x-2 rounded-lg bg-white px-8 py-4 text-lg font-semibold text-purple-900 shadow-xl hover:shadow-2xl hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
        >
          <span>Join The Circle</span>
          <Icon name="ArrowRightIcon" size={20} />
        </button>
      </div>
    </section>
  );
};

export default NewHeroSection;