import Icon from '@/components/ui/AppIcon';

const EverythingYouGetSection = () => {
  const benefits = [
    {
      title: 'Complete 8-Module Course',
      value: 'Worth over $1,200',
      icon: 'AcademicCapIcon'
    },
    {
      title: '40+ Video Lessons',
      value: 'Lifetime access',
      icon: 'VideoCameraIcon'
    },
    {
      title: 'Weekly Tarot Messages',
      value: 'Personal guidance every week',
      icon: 'EnvelopeIcon'
    },
    {
      title: 'Guided Meditation Library',
      value: 'Available 24/7',
      icon: 'MusicalNoteIcon'
    },
    {
      title: 'Same-Day Digital Readings',
      value: 'Answers when you need them',
      icon: 'BoltIcon'
    },
    {
      title: 'Exclusive Tools',
      value: 'Tarot journal, manifestation workbook & more',
      icon: 'SparklesIcon'
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-purple-50 via-lavender-50 to-purple-100">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="text-3xl font-bold tracking-tight lg:text-4xl mb-12 text-center">
          Everything You Get as a Circle Member
        </h2>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="rounded-xl bg-white p-6 shadow-lg border border-purple-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-250"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon name={benefit.icon as any} size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-muted-foreground">{benefit.value}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EverythingYouGetSection;