import Icon from '@/components/ui/AppIcon';

interface HeroSectionProps {
  onJoinNow: () => void;
}

const HeroSection = ({ onJoinNow }: HeroSectionProps) => {
  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-secondary/10 to-accent/5 py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center space-x-2 rounded-full bg-accent/20 px-4 py-2 text-sm font-medium text-accent-foreground">
              <Icon name="SparklesIcon" size={16} variant="solid" />
              <span className="font-caption">Limited Time Offer - Launching January 15th</span>
            </div>
            
            <h1 className="text-4xl font-bold tracking-tight lg:text-5xl xl:text-6xl">
              Join The Psychic Circle
              <span className="block text-primary mt-2">Your Spiritual Journey Begins Here</span>
            </h1>
            
            <p className="text-lg text-muted-foreground lg:text-xl">
              Unlock exclusive access to 50+ years of psychic wisdom through comprehensive courses, direct messaging with Sue, weekly spiritual guidance, and a supportive community of like-minded souls.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onJoinNow}
                className="inline-flex items-center justify-center space-x-2 rounded-lg bg-primary px-8 py-4 text-lg font-semibold text-primary-foreground shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
              >
                <span>Join The Circle Now</span>
                <Icon name="ArrowRightIcon" size={20} />
              </button>
              
              <button
                onClick={() => {
                  const benefitsSection = document.getElementById('benefits');
                  benefitsSection?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center space-x-2 rounded-lg border-2 border-primary px-8 py-4 text-lg font-semibold text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-250 active:scale-95"
              >
                <span>Learn More</span>
                <Icon name="ChevronDownIcon" size={20} />
              </button>
            </div>
            
            <div className="flex items-center space-x-8 pt-4">
              <div className="flex items-center space-x-2">
                <Icon name="CheckBadgeIcon" size={24} variant="solid" className="text-success" />
                <span className="text-sm font-medium text-muted-foreground font-caption">50+ Years Experience</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="UserGroupIcon" size={24} variant="solid" className="text-success" />
                <span className="text-sm font-medium text-muted-foreground font-caption">Exclusive Community</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-3xl"></div>
            <div className="relative rounded-3xl bg-card p-8 shadow-2xl border border-border">
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Icon name="AcademicCapIcon" size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">8 Comprehensive Modules</h3>
                    <p className="text-sm text-muted-foreground">Master tarot, intuition & spiritual development</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                    <Icon name="ChatBubbleLeftRightIcon" size={24} className="text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Direct Messaging Access</h3>
                    <p className="text-sm text-muted-foreground">Connect with Sue via WhatsApp & voice notes</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary/10">
                    <Icon name="CalendarDaysIcon" size={24} className="text-secondary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Priority Booking</h3>
                    <p className="text-sm text-muted-foreground">Exclusive access to reading slots</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success/10">
                    <Icon name="DocumentTextIcon" size={24} className="text-success" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Resources Library</h3>
                    <p className="text-sm text-muted-foreground">PDFs, meditations & exclusive content</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;