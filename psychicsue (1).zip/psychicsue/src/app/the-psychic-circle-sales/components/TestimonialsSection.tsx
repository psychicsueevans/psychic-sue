import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface Testimonial {
  id: number;
  name: string;
  location: string;
  rating: number;
  image: string;
  alt: string;
  quote: string;
  transformation: string;
}

const TestimonialsSection = () => {
  const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Mitchell',
    location: 'London, UK',
    rating: 5,
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_17f4e1b32-1763300403727.png",
    alt: 'Smiling woman with long brown hair wearing white blouse in bright indoor setting',
    quote: 'Joining The Psychic Circle transformed my spiritual practice completely. Sue\'s guidance helped me develop confidence in my intuitive abilities, and the community support has been invaluable. I\'ve gone from doubting my gifts to reading professionally for clients.',
    transformation: 'Now reading professionally after 6 months'
  },
  {
    id: 2,
    name: 'Emma Thompson',
    location: 'Manchester, UK',
    rating: 5,
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_1e68cdedb-1763301318205.png",
    alt: 'Professional woman with blonde hair in navy blazer smiling confidently',
    quote: 'The course modules are incredibly comprehensive and Sue\'s personal feedback on my readings accelerated my learning exponentially. The priority booking privilege means I never miss my monthly session with Sue. Best investment in my spiritual journey.',
    transformation: 'Completed all 8 modules in 4 months'
  },
  {
    id: 3,
    name: 'Rachel Green',
    location: 'Birmingham, UK',
    rating: 5,
    image: "https://images.unsplash.com/photo-1678935903557-98ae7d37e1ca",
    alt: 'Young woman with curly brown hair wearing casual sweater with warm smile',
    quote: 'I was skeptical about online spiritual courses, but The Psychic Circle exceeded all expectations. The direct WhatsApp access to Sue means I get answers when I need them most. The meditation library alone is worth the membership fee.',
    transformation: 'Developed daily spiritual practice'
  },
  {
    id: 4,
    name: 'Jennifer Collins',
    location: 'Edinburgh, UK',
    rating: 5,
    image: "https://images.unsplash.com/photo-1592899436871-a50d9a3c1aac",
    alt: 'Woman with red hair in green cardigan smiling warmly at camera',
    quote: 'The community aspect of The Psychic Circle has been life-changing. Connecting with other spiritual seekers who understand this journey has given me confidence and support I never had before. Sue\'s weekly messages keep me grounded and inspired.',
    transformation: 'Built lasting spiritual friendships'
  },
  {
    id: 5,
    name: 'Lisa Anderson',
    location: 'Bristol, UK',
    rating: 5,
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_13eb405cb-1763293852066.png",
    alt: 'Professional woman with dark hair in business attire with confident expression',
    quote: 'Sue\'s teaching style is clear, practical, and deeply spiritual. The course structure takes you from complete beginner to confident reader. The certification I received has opened doors professionally, and the ongoing support keeps me growing.',
    transformation: 'Launched spiritual coaching business'
  },
  {
    id: 6,
    name: 'Amanda Roberts',
    location: 'Leeds, UK',
    rating: 5,
    image: "https://img.rocket.new/generatedImages/rocket_gen_img_188063e16-1766529745014.png",
    alt: 'Smiling woman with shoulder-length brown hair in casual attire outdoors',
    quote: 'The resources library is constantly updated with new content. I love the guided meditations and the monthly spiritual forecasts. Having lifetime access means I can revisit modules as I grow. The 20% discount on readings is a fantastic bonus.',
    transformation: 'Deepened meditation practice significantly'
  }];


  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center space-x-1">
        {[...Array(5)].map((_, index) =>
        <Icon
          key={index}
          name="StarIcon"
          size={18}
          variant={index < rating ? 'solid' : 'outline'}
          className={index < rating ? 'text-warning' : 'text-muted-foreground'} />

        )}
      </div>);

  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-secondary/5 to-accent/5">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-4">
            Member Success Stories
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Discover how The Psychic Circle has transformed the spiritual journeys of our members, helping them develop their intuitive gifts and build meaningful practices.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial) =>
          <div
            key={testimonial.id}
            className="rounded-2xl bg-card p-6 shadow-lg border border-border hover:shadow-xl hover:-translate-y-1 transition-all duration-250">

              <div className="flex items-center space-x-4 mb-4">
                <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-full">
                  <AppImage
                  src={testimonial.image}
                  alt={testimonial.alt}
                  className="h-full w-full object-cover" />

                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground font-caption">{testimonial.location}</p>
                  {renderStars(testimonial.rating)}
                </div>
              </div>

              <blockquote className="mb-4">
                <p className="text-foreground leading-relaxed italic">
                  &quot;{testimonial.quote}&quot;
                </p>
              </blockquote>

              <div className="flex items-center space-x-2 rounded-lg bg-success/10 px-3 py-2">
                <Icon name="SparklesIcon" size={16} variant="solid" className="text-success" />
                <span className="text-sm font-medium text-success-foreground font-caption">
                  {testimonial.transformation}
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center space-x-2 rounded-full bg-card px-6 py-3 shadow-md border border-border">
            <Icon name="UserGroupIcon" size={24} variant="solid" className="text-primary" />
            <span className="text-lg font-semibold">Join 500+ Members on Their Spiritual Journey</span>
          </div>
        </div>
      </div>
    </section>);

};

export default TestimonialsSection;