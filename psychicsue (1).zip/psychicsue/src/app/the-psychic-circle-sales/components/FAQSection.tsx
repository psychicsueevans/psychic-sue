'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface FAQ {
  question: string;
  answer: string;
}

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQ[] = [
    {
      question: 'What exactly is included in The Psychic Circle membership?',
      answer: 'Your membership includes complete access to 8 comprehensive course modules covering tarot, intuition development, and spiritual practice. You\'ll receive direct messaging access to Sue via WhatsApp, weekly spiritual guidance messages, monthly live Q&A sessions, a resources library with downloadable PDFs and guided meditations, community forum access, priority booking for readings with 20% discount, and lifetime access to all content with ongoing updates.'
    },
    {
      question: 'How long does it take to complete the course modules?',
      answer: 'The 8 modules are designed to be completed at your own pace. Most members finish the core content within 3-6 months, dedicating 2-3 hours per week. However, you have lifetime access, so you can take as long as you need and revisit modules whenever you wish. Many members continue to reference the materials years after joining as their practice deepens.'
    },
    {
      question: 'Can I really message Sue directly? How quickly will she respond?',
      answer: 'Yes! All members receive WhatsApp access to Sue for questions and guidance. Sue personally responds to all member messages within 48 hours, often much sooner. You can send text messages or voice notes. Annual members also receive quarterly one-on-one guidance calls for deeper personal support.'
    },
    {
      question: 'Is this suitable for complete beginners with no tarot experience?',
      answer: 'Absolutely! The course is designed to take you from complete beginner to confident reader. Module 1 starts with the fundamentals of tarot card meanings and basic spreads. Sue\'s teaching style is clear, practical, and accessible. Many of our most successful members started with zero experience and are now reading professionally.'
    },
    {
      question: 'What\'s the difference between monthly and annual membership?',
      answer: 'Both memberships include full access to all course content, community, and resources. Annual membership saves you £167 compared to paying monthly and includes additional benefits: quarterly one-on-one guidance calls with Sue, exclusive annual retreat invitation, advanced masterclass access, birthday month complimentary reading, and priority support response. Annual members also receive lifetime community access even if they don\'t renew.'
    },
    {
      question: 'Can I cancel my membership at any time?',
      answer: 'Monthly memberships can be cancelled at any time with no penalties - you\'ll retain access until the end of your billing period. Annual memberships are non-refundable but provide significantly better value. All members keep lifetime access to any downloaded resources and completed course materials, even after cancellation.'
    },
    {
      question: 'Will I receive a certificate upon completion?',
      answer: 'Yes! Upon completing all 8 modules and the final assessment, you\'ll receive a digital certificate of completion from Sue\'s 50+ year practice. This certificate demonstrates your training and can be used professionally. Many members display it on their websites and social media when offering readings.'
    },
    {
      question: 'How does the priority booking privilege work?',
      answer: 'Members receive exclusive early access to Sue\'s booking calendar before slots are released to the public. You\'ll be notified 48 hours in advance when new availability opens. Members also receive 20% discount on all reading services, flexible rescheduling options, and priority placement on the waitlist if your preferred time isn\'t available.'
    },
    {
      question: 'Is there a money-back guarantee?',
      answer: 'We offer a 14-day satisfaction guarantee for monthly memberships. If you\'re not completely satisfied within the first 14 days, contact us for a full refund. This gives you time to explore the first module, experience the community, and ensure The Psychic Circle is right for you. Annual memberships are non-refundable due to the significant discount provided.'
    },
    {
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit and debit cards through Stripe, as well as PayPal. All transactions are secured with SSL encryption and processed through industry-leading payment providers. Your payment information is never stored on our servers. Monthly memberships are automatically billed on the same date each month.'
    },
    {
      question: 'Can I upgrade from monthly to annual membership later?',
      answer: 'Yes! You can upgrade to annual membership at any time. We\'ll credit your previous monthly payments toward the annual fee, so you never pay twice. Simply contact our support team, and we\'ll process the upgrade immediately. Many members start monthly to try the program and upgrade once they experience the value.'
    },
    {
      question: 'What makes The Psychic Circle different from other online courses?',
      answer: 'The Psychic Circle combines comprehensive structured learning with unprecedented personal access to Sue\'s 50+ years of experience. Unlike pre-recorded courses, you receive ongoing guidance, personal feedback on your readings, and direct communication with Sue. The supportive community and lifetime access ensure you\'re never learning alone. Sue\'s media credentials (BBC, Channel 4) and proven track record provide credibility rarely found in spiritual education.'
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-secondary/5 to-accent/5">
      <div className="mx-auto max-w-4xl px-6">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground">
            Everything you need to know about The Psychic Circle membership
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-xl bg-card shadow-md border border-border overflow-hidden transition-all duration-250 hover:shadow-lg"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full flex items-center justify-between p-6 text-left transition-colors duration-250 hover:bg-muted"
              >
                <span className="text-lg font-semibold pr-4">{faq.question}</span>
                <Icon
                  name="ChevronDownIcon"
                  size={24}
                  className={`flex-shrink-0 text-primary transition-transform duration-250 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-6 animate-slide-down">
                  <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-4">Still have questions?</p>
          <a
            href="/contact"
            className="inline-flex items-center space-x-2 rounded-lg bg-primary px-6 py-3 text-lg font-semibold text-primary-foreground shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
          >
            <Icon name="EnvelopeIcon" size={20} />
            <span>Contact Us</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;