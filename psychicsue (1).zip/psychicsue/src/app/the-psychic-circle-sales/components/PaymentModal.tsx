'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: string;
}

const PaymentModal = ({ isOpen, onClose, selectedPlan }: PaymentModalProps) => {
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'paypal'>('stripe');
  const [formData, setFormData] = useState({
    email: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    name: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Payment processing for ${selectedPlan} via ${paymentMethod}. This is a demo - no actual payment will be processed.`);
    onClose();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-card shadow-2xl border border-border animate-slide-up">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-card px-6 py-4">
          <h3 className="text-2xl font-bold">Secure Checkout</h3>
          <button
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-all duration-250 active:scale-95"
            aria-label="Close payment modal"
          >
            <Icon name="XMarkIcon" size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="rounded-lg bg-primary/5 p-4 border border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Selected Plan:</span>
              <span className="text-lg font-bold text-primary">{selectedPlan}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold">Amount:</span>
              <span className="text-2xl font-bold text-primary">
                {selectedPlan.includes('Annual') ? '£997' : '£97'}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-4 p-4 rounded-lg bg-success/10 border border-success/20">
            <Icon name="ShieldCheckIcon" size={24} variant="solid" className="text-success" />
            <div className="flex-1">
              <p className="font-semibold text-success-foreground">Secure Payment</p>
              <p className="text-sm text-muted-foreground font-caption">Your payment information is encrypted and secure</p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-3">Payment Method</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setPaymentMethod('stripe')}
                className={`flex items-center justify-center space-x-2 rounded-lg border-2 px-4 py-3 font-semibold transition-all duration-250 ${
                  paymentMethod === 'stripe' ?'border-primary bg-primary/10 text-primary' :'border-border bg-card text-foreground hover:border-primary/50'
                }`}
              >
                <Icon name="CreditCardIcon" size={20} />
                <span>Credit Card</span>
              </button>
              <button
                onClick={() => setPaymentMethod('paypal')}
                className={`flex items-center justify-center space-x-2 rounded-lg border-2 px-4 py-3 font-semibold transition-all duration-250 ${
                  paymentMethod === 'paypal' ?'border-primary bg-primary/10 text-primary' :'border-border bg-card text-foreground hover:border-primary/50'
                }`}
              >
                <Icon name="BanknotesIcon" size={20} />
                <span>PayPal</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-semibold mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                placeholder="your.email@example.com"
                className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-250"
              />
            </div>

            {paymentMethod === 'stripe' && (
              <>
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold mb-2">
                    Cardholder Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    placeholder="John Smith"
                    className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-250"
                  />
                </div>

                <div>
                  <label htmlFor="cardNumber" className="block text-sm font-semibold mb-2">
                    Card Number
                  </label>
                  <input
                    type="text"
                    id="cardNumber"
                    name="cardNumber"
                    value={formData.cardNumber}
                    onChange={handleInputChange}
                    required
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                    className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-250 data-text"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="expiryDate" className="block text-sm font-semibold mb-2">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      id="expiryDate"
                      name="expiryDate"
                      value={formData.expiryDate}
                      onChange={handleInputChange}
                      required
                      placeholder="MM/YY"
                      maxLength={5}
                      className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-250 data-text"
                    />
                  </div>
                  <div>
                    <label htmlFor="cvv" className="block text-sm font-semibold mb-2">
                      CVV
                    </label>
                    <input
                      type="text"
                      id="cvv"
                      name="cvv"
                      value={formData.cvv}
                      onChange={handleInputChange}
                      required
                      placeholder="123"
                      maxLength={4}
                      className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all duration-250 data-text"
                    />
                  </div>
                </div>
              </>
            )}

            {paymentMethod === 'paypal' && (
              <div className="rounded-lg bg-muted p-6 text-center">
                <Icon name="BanknotesIcon" size={48} className="text-primary mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  You will be redirected to PayPal to complete your payment securely.
                </p>
              </div>
            )}

            <div className="flex items-start space-x-3 rounded-lg bg-muted p-4">
              <Icon name="InformationCircleIcon" size={20} className="text-primary flex-shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                By completing this purchase, you agree to our terms of service and privacy policy. You will receive immediate access to The Psychic Circle upon successful payment.
              </p>
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-primary px-6 py-4 text-lg font-bold text-primary-foreground shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-250 active:scale-95"
            >
              Complete Payment
            </button>

            <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Icon name="LockClosedIcon" size={16} />
                <span className="font-caption">SSL Encrypted</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="ShieldCheckIcon" size={16} />
                <span className="font-caption">PCI Compliant</span>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;