import Icon from '@/components/ui/AppIcon';

const BenefitsSection = () => {
  const benefits = [
    {
      icon: 'AcademicCapIcon',
      title: '8 Transformative Course Modules',
      description: 'Comprehensive training covering tarot fundamentals, intuitive development, spiritual protection, reading techniques, and advanced divination methods.',
      features: [
        'Module 1: Introduction to Tarot & Card Meanings',
        'Module 2: Developing Your Intuition',
        'Module 3: Spiritual Protection & Grounding',
        'Module 4: Reading Techniques & Spreads',
        'Module 5: Advanced Divination Methods',
        'Module 6: Ethics & Professional Practice',
        'Module 7: Building Your Spiritual Business',
        'Module 8: Mastery & Certification'
      ]
    },
    {
      icon: 'ChatBubbleLeftRightIcon',
      title: 'Direct Access to Sue',
      description: 'Unprecedented personal connection through multiple communication channels for guidance, questions, and spiritual support.',
      features: [
        'WhatsApp messaging for quick questions',
        'Voice note submissions for detailed queries',
        'Weekly live Q&A sessions',
        'Personal feedback on your readings',
        'Priority response within 48 hours',
        'One-on-one guidance calls (quarterly)',
        'Email support for course materials',
        'Community forum participation'
      ]
    },
    {
      icon: 'UserGroupIcon',
      title: 'Exclusive Community Access',
      description: 'Join a supportive network of spiritual seekers and practitioners sharing their journey, insights, and experiences.',
      features: [
        'Private members-only community feed',
        'Weekly spiritual guidance from Sue',
        'Monthly group meditation sessions',
        'Peer support and accountability',
        'Share readings and receive feedback',
        'Networking with fellow practitioners',
        'Exclusive member events and workshops',
        'Lifetime community membership'
      ]
    },
    {
      icon: 'CalendarDaysIcon',
      title: 'Priority Booking Privileges',
      description: 'Members receive exclusive access to reading slots before public availability, ensuring you never miss an opportunity.',
      features: [
        'Early access to booking calendar',
        '20% discount on all reading services',
        'Flexible rescheduling options',
        'Extended session times available',
        'Priority waitlist placement',
        'Special member-only reading packages',
        'Birthday month complimentary reading',
        'Referral rewards program'
      ]
    },
    {
      icon: 'DocumentTextIcon',
      title: 'Comprehensive Resources Library',
      description: 'Access an ever-growing collection of downloadable materials, guided meditations, and exclusive spiritual content.',
      features: [
        'Downloadable PDF workbooks & guides',
        'Guided meditation audio recordings',
        'Tarot card meaning reference sheets',
        'Spread templates and layouts',
        'Monthly spiritual forecasts',
        'Exclusive video tutorials',
        'Reading journal templates',
        'Certification upon course completion'
      ]
    },
    {
      icon: 'SparklesIcon',
      title: 'Ongoing Spiritual Development',
      description: 'Continuous learning through weekly content updates, seasonal workshops, and advanced training opportunities.',
      features: [
        'Weekly spiritual insights and messages',
        'Monthly themed workshops',
        'Seasonal celebration rituals',
        'Advanced technique masterclasses',
        'Guest expert sessions',
        'New course modules added regularly',
        'Exclusive member webinars',
        'Lifetime access to all content'
      ]
    }
  ];

  return (
    <section id="benefits" className="py-16 lg:py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-4">
            What You'll Receive as a Member
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            The Psychic Circle offers comprehensive spiritual education, personal guidance, and community support to accelerate your intuitive development and deepen your connection to the divine.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:gap-12">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="rounded-2xl bg-card p-8 shadow-lg border border-border hover:shadow-xl hover:-translate-y-1 transition-all duration-250"
            >
              <div className="flex items-start space-x-4 mb-6">
                <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <Icon name={benefit.icon as any} size={28} className="text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </div>
              </div>
              
              <ul className="space-y-3">
                {benefit.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start space-x-3">
                    <Icon name="CheckCircleIcon" size={20} variant="solid" className="text-success flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;