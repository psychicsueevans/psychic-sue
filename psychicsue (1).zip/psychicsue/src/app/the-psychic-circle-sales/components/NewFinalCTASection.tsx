import Icon from '@/components/ui/AppIcon';

interface NewFinalCTASectionProps {
  onJoinNow: () => void;
}

const NewFinalCTASection = ({ onJoinNow }: NewFinalCTASectionProps) => {
  const scrollToPricing = () => {
    const pricingSection = document.getElementById('pricing');
    pricingSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <h2 className="text-3xl font-bold tracking-tight lg:text-4xl xl:text-5xl mb-8">
          Ready to Begin?
        </h2>
        
        <button
          onClick={scrollToPricing}
          className="inline-flex items-center justify-center space-x-2 rounded-lg bg-primary px-10 py-5 text-xl font-bold text-primary-foreground shadow-2xl hover:shadow-3xl hover:-translate-y-1 transition-all duration-250 active:scale-95"
        >
          <span>Join Now — $35/month</span>
          <Icon name="ArrowRightIcon" size={24} />
        </button>
      </div>
    </section>
  );
};

export default NewFinalCTASection;