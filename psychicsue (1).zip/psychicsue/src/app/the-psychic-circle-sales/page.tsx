import type { Metadata } from 'next';
import AuthNavigation from '@/components/common/AuthNavigation';
import MobileNavToggle from '@/components/common/MobileNavToggle';
import PsychicCircleInteractive from './components/PsychicCircleInteractive';

export const metadata: Metadata = {
  title: 'The Psychic Circle - Exclusive Membership | PsychicSue',
  description: 'Join The Psychic Circle for exclusive access to 8 comprehensive tarot courses, direct messaging with Sue, weekly spiritual guidance, and a supportive community. Transform your spiritual practice with 50+ years of psychic wisdom.',
};

export default function PsychicCircleSalesPage() {
  return (
    <AuthNavigation isAuthenticated={false}>
      <main className="min-h-screen bg-background pb-20 md:pb-0">
        <PsychicCircleInteractive />
      </main>
      <MobileNavToggle isAuthenticated={false} />
    </AuthNavigation>
  );
}