'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import { useAuth } from '@/contexts/AuthContext';

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

const MemberLoginInteractive = () => {
  const router = useRouter();
  const { signIn } = useAuth();
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: '',
    rememberMe: false,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof LoginFormData, string>>>({});
  const [loginError, setLoginError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
    if (errors[name as keyof LoginFormData]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
    if (loginError) {
      setLoginError('');
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof LoginFormData, string>> = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setLoginError('');

    try {
      const { data, error } = await signIn(formData.email, formData.password);

      if (error) {
        setLoginError(error.message || 'Invalid email or password. Please try again.');
        setIsLoading(false);
        return;
      }

      if (data?.user) {
        // Redirect to member dashboard
        router.push('/member-dashboard');
      }
    } catch (error) {
      setLoginError('Something went wrong. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md space-y-8">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center justify-center lg:justify-start">
            <svg
              width="160"
              height="40"
              viewBox="0 0 160 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="h-10 w-auto"
            >
              <circle cx="20" cy="20" r="18" fill="var(--color-primary)" opacity="0.1" />
              <circle cx="20" cy="20" r="12" fill="var(--color-primary)" opacity="0.2" />
              <circle cx="20" cy="20" r="6" fill="var(--color-primary)" />
              <path
                d="M20 8L22.5 15H30L24 19.5L26.5 27L20 22L13.5 27L16 19.5L10 15H17.5L20 8Z"
                fill="var(--color-accent)"
              />
              <text
                x="45"
                y="26"
                fontFamily="Crimson Text, serif"
                fontSize="20"
                fontWeight="600"
                fill="var(--color-primary)"
              >
                PsychicSue
              </text>
            </svg>
          </Link>

          {/* Header */}
          <div className="text-center lg:text-left">
            <h1 className="text-3xl font-bold text-foreground lg:text-4xl">Welcome Back</h1>
            <p className="mt-2 text-muted-foreground">Sign in to access your Circle membership</p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {loginError && (
              <div className="flex items-center space-x-2 rounded-lg bg-error/10 border border-error/20 px-4 py-3 text-sm text-error">
                <Icon name="ExclamationCircleIcon" size={20} variant="solid" />
                <span>{loginError}</span>
              </div>
            )}

            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                Email address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg border ${
                  errors.email ? 'border-error' : 'border-input'
                } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200`}
                placeholder="you@example.com"
                disabled={isLoading}
              />
              {errors.email && <p className="mt-1 text-sm text-error">{errors.email}</p>}
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-foreground mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg border ${
                    errors.password ? 'border-error' : 'border-input'
                  } bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all duration-200`}
                  placeholder="Enter your password"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  disabled={isLoading}
                >
                  <Icon name={showPassword ? 'EyeSlashIcon' : 'EyeIcon'} size={20} />
                </button>
              </div>
              {errors.password && <p className="mt-1 text-sm text-error">{errors.password}</p>}
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleInputChange}
                  className="w-4 h-4 rounded border-input text-primary focus:ring-2 focus:ring-ring transition-all"
                  disabled={isLoading}
                />
                <span className="text-sm text-foreground">Remember me</span>
              </label>
              <Link
                href="/forgot-password"
                className="text-sm font-medium text-primary hover:text-primary/80 transition-colors"
              >
                Forgot password?
              </Link>
            </div>

            {/* Sign In Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2 rounded-lg bg-primary px-8 py-4 text-lg font-semibold text-primary-foreground shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-250 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
            >
              {isLoading ? (
                <>
                  <Icon name="ArrowPathIcon" size={20} className="animate-spin" />
                  <span>Signing in...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <Icon name="ArrowRightIcon" size={20} />
                </>
              )}
            </button>

            {/* Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-background px-4 text-muted-foreground">or</span>
              </div>
            </div>

            {/* Sign Up Link */}
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Don't have an account?{' '}
                <Link
                  href="/member-sign-up"
                  className="font-medium text-primary hover:text-primary/80 transition-colors"
                >
                  Sign Up
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>

      {/* Right Side - Mystical Background (Desktop Only) */}
      <div className="hidden lg:block lg:w-1/2 relative bg-gradient-to-br from-primary via-primary/90 to-secondary overflow-hidden">
        {/* Decorative Elements */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-20"></div>
        
        {/* Content */}
        <div className="relative h-full flex flex-col items-center justify-center px-12 text-center text-white">
          <div className="space-y-6 max-w-md">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm">
              <Icon name="SparklesIcon" size={40} variant="solid" className="text-accent" />
            </div>
            <h2 className="text-3xl font-bold">Your Spiritual Journey Awaits</h2>
            <p className="text-lg text-white/90">
              Access exclusive courses, personalized guidance, and a supportive community of spiritual seekers.
            </p>
            <div className="pt-4 space-y-3">
              <div className="flex items-center space-x-3 text-left">
                <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-accent flex-shrink-0" />
                <span>8-Module Psychic Development Course</span>
              </div>
              <div className="flex items-center space-x-3 text-left">
                <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-accent flex-shrink-0" />
                <span>Direct Messaging with Sue</span>
              </div>
              <div className="flex items-center space-x-3 text-left">
                <Icon name="CheckCircleIcon" size={24} variant="solid" className="text-accent flex-shrink-0" />
                <span>Weekly Spiritual Guidance</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberLoginInteractive;