import type { Metadata } from 'next';
import MemberLoginInteractive from './components/MemberLoginInteractive';

export const metadata: Metadata = {
  title: 'Member Login - PsychicSue',
  description: 'Sign in to access your Circle membership dashboard with exclusive courses, readings, and spiritual guidance.',
};

export default function MemberLoginPage() {
  return <MemberLoginInteractive />;
}