import type { Metadata } from 'next';
import MemberSignUpInteractive from './components/MemberSignUpInteractive';

export const metadata: Metadata = {
  title: 'Sign Up - The Psychic Circle',
  description: 'Join The Psychic Circle membership to access exclusive courses, readings, and spiritual guidance.',
};

export default function MemberSignUpPage() {
  return <MemberSignUpInteractive />;
}