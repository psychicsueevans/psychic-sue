'use client';

import { useState } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

interface Lesson {
  id: number;
  title: string;
  duration: string;
  status: 'completed' | 'current' | 'not-started' | 'locked';
}

interface ModuleData {
  moduleNumber: number;
  title: string;
  totalLessons: number;
  completedLessons: number;
  lessons: Lesson[];
}

export default function ModuleViewInteractive() {
  // Mock data - Module 3 example from requirements
  const [moduleData] = useState<ModuleData>({
    moduleNumber: 3,
    title: 'Working with Spirit',
    totalLessons: 7,
    completedLessons: 3,
    lessons: [
      { id: 1, title: 'Introduction to Spirit Communication', duration: '8 min', status: 'completed' },
      { id: 2, title: 'Preparing Your Space', duration: '10 min', status: 'completed' },
      { id: 3, title: 'Grounding Techniques', duration: '12 min', status: 'completed' },
      { id: 4, title: 'Recognizing Signs', duration: '15 min', status: 'current' },
      { id: 5, title: 'Working with Spirit Guides', duration: '14 min', status: 'not-started' },
      { id: 6, title: 'Protection During Spirit Work', duration: '11 min', status: 'not-started' },
      { id: 7, title: 'Closing & Cleansing', duration: '9 min', status: 'not-started' },
    ],
  });

  const progressPercentage = Math.round((moduleData.completedLessons / moduleData.totalLessons) * 100);

  const getStatusIcon = (status: Lesson['status']) => {
    switch (status) {
      case 'completed':
        return (
          <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
            <Icon name="CheckIcon" size={20} className="text-white" />
          </div>
        );
      case 'current':
        return (
          <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
            <Icon name="PlayIcon" size={16} className="text-white" variant="solid" />
          </div>
        );
      case 'locked':
        return (
          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center flex-shrink-0">
            <Icon name="LockClosedIcon" size={16} className="text-gray-600" />
          </div>
        );
      case 'not-started':
        return (
          <div className="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center flex-shrink-0">
            <div className="w-3 h-3 rounded-full bg-gray-300"></div>
          </div>
        );
    }
  };

  const getStatusBadge = (status: Lesson['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
            ✓ Completed
          </span>
        );
      case 'current':
        return (
          <span className="inline-flex items-center px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
            Current
          </span>
        );
      case 'locked':
        return (
          <span className="inline-flex items-center px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
            🔒 Locked
          </span>
        );
      case 'not-started':
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <Link
            href="/member-dashboard"
            className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-700 font-medium mb-4 transition-colors"
          >
            <Icon name="ArrowLeftIcon" size={20} />
            <span>Back to Course</span>
          </Link>

          <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-1">
                  Module {moduleData.moduleNumber}: {moduleData.title}
                </h1>
                <p className="text-purple-600">
                  {moduleData.completedLessons} of {moduleData.totalLessons} lessons completed
                </p>
              </div>
              <div className="text-center flex-shrink-0">
                <div className="text-4xl font-bold text-purple-700">{progressPercentage}%</div>
                <div className="text-sm text-purple-600">Complete</div>
              </div>
            </div>
            <div className="w-full bg-purple-100 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-green-500 to-purple-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Lesson List */}
        <div className="space-y-3">
          <h2 className="text-xl font-bold text-purple-950 mb-4">Lessons</h2>
          {moduleData.lessons.map((lesson) => (
            <Link
              key={lesson.id}
              href={lesson.status === 'locked' ? '#' : `/lesson-view?module=${moduleData.moduleNumber}&lesson=${lesson.id}`}
              className={`block bg-white rounded-xl p-5 shadow-sm border border-purple-100 transition-all ${
                lesson.status === 'locked' ?'opacity-60 cursor-not-allowed' :'hover:shadow-md hover:border-purple-200'
              }`}
              onClick={(e) => {
                if (lesson.status === 'locked') {
                  e.preventDefault();
                }
              }}
            >
              <div className="flex items-center gap-4">
                {/* Status Icon */}
                {getStatusIcon(lesson.status)}

                {/* Lesson Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 mb-1">
                    <h3 className="text-base sm:text-lg font-semibold text-purple-950">
                      {lesson.id}. {lesson.title}
                    </h3>
                    {getStatusBadge(lesson.status)}
                  </div>
                  <p className="text-sm text-purple-600">{lesson.duration}</p>
                </div>

                {/* Arrow Icon */}
                {lesson.status !== 'locked' && (
                  <Icon name="ChevronRightIcon" size={24} className="text-purple-400 flex-shrink-0" />
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}