'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeftIcon, BookOpenIcon, CheckCircleIcon, PlayIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';
import { courseService } from '@/services/courseService';
import type { ModuleWithLessons, Lesson } from '@/types/course.types';

// Error Boundary Component
function ErrorFallback({ error, resetError }: { error: string; resetError: () => void }) {
  return (
    <div className="min-h-screen bg-[#FDFCFE] flex items-center justify-center">
      <div className="text-center max-w-md mx-auto px-4">
        <ExclamationTriangleIcon className="w-16 h-16 text-red-600 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-purple-950 mb-4">Something Went Wrong</h1>
        <p className="text-red-600 text-lg mb-6">{error}</p>
        <div className="flex gap-3 justify-center">
          <button
            onClick={resetError}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            Try Again
          </button>
          <Link
            href="/member-dashboard"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}

function ModuleViewContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const moduleNumber = searchParams?.get('module');
  
  const [module, setModule] = useState<ModuleWithLessons | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dataValidated, setDataValidated] = useState(false);

  // Reset error handler
  const resetError = () => {
    setError(null);
    setIsLoading(true);
    loadModuleData();
  };

  // Load module data with proper error handling
  const loadModuleData = async () => {
    // Validate module number parameter
    if (!moduleNumber || isNaN(parseInt(moduleNumber))) {
      setError('Invalid module number. Please return to dashboard and select a module.');
      setIsLoading(false);
      setDataValidated(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Get all modules to find the one we need
      const { data: modules, error: modulesError } = await courseService.getModulesWithLessons();
      
      if (modulesError) {
        setError('Unable to load course modules. Please check your connection and try again.');
        setIsLoading(false);
        setDataValidated(false);
        return;
      }

      // Validate modules data exists
      if (!modules || modules.length === 0) {
        setError('No course modules found. Please contact support.');
        setIsLoading(false);
        setDataValidated(false);
        return;
      }

      // Find the specific module
      const foundModule = modules.find(m => m.module_number === parseInt(moduleNumber));
      
      if (!foundModule) {
        setError(`Module ${moduleNumber} not found. It may have been removed or is not available.`);
        setIsLoading(false);
        setDataValidated(false);
        return;
      }

      // Validate module has required properties
      if (!foundModule.id || !foundModule.title) {
        setError('Module data is incomplete. Please contact support.');
        setIsLoading(false);
        setDataValidated(false);
        return;
      }

      setModule(foundModule);

      // Get lessons for this module
      const { data: lessonsData, error: lessonsError } = await courseService.getLessonsByModuleId(foundModule.id);
      
      if (lessonsError) {
        setError('Unable to load module lessons. Please try again.');
        setIsLoading(false);
        setDataValidated(false);
        return;
      }

      // Set lessons (empty array is valid - module might not have lessons yet)
      setLessons(lessonsData || []);
      setDataValidated(true);
      
    } catch (err: any) {
      setError(err?.message || 'An unexpected error occurred while loading module data.');
      setDataValidated(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Load data when component mounts or moduleNumber changes
  useEffect(() => {
    loadModuleData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moduleNumber]);

  // Loading state with skeleton
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FDFCFE]">
        <div className="mx-auto px-4 sm:px-6 py-6 sm:py-8 max-w-7xl">
          <div className="animate-pulse space-y-6">
            {/* Back button skeleton */}
            <div className="h-6 w-32 bg-purple-200 rounded"></div>
            
            {/* Module header skeleton */}
            <div className="bg-white rounded-xl p-8 shadow-sm border border-purple-100">
              <div className="flex items-start gap-6">
                <div className="w-16 h-16 rounded-full bg-purple-200"></div>
                <div className="flex-1 space-y-3">
                  <div className="h-8 w-3/4 bg-purple-200 rounded"></div>
                  <div className="h-4 w-full bg-purple-100 rounded"></div>
                  <div className="flex gap-3">
                    <div className="h-6 w-24 bg-purple-100 rounded-full"></div>
                    <div className="h-6 w-24 bg-green-100 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Lessons skeleton */}
            <div className="space-y-4">
              <div className="h-8 w-32 bg-purple-200 rounded"></div>
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-purple-200"></div>
                    <div className="flex-1 space-y-3">
                      <div className="h-6 w-2/3 bg-purple-200 rounded"></div>
                      <div className="h-4 w-full bg-purple-100 rounded"></div>
                      <div className="h-10 w-32 bg-purple-200 rounded-lg"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state with error boundary
  if (error || !dataValidated || !module) {
    return <ErrorFallback error={error || 'Failed to load module data'} resetError={resetError} />;
  }

  // Calculate progress
  const completedLessons = 0; // TODO: Calculate from lesson_progress
  const progress = lessons.length > 0 ? Math.round((completedLessons / lessons.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#FDFCFE]">
      <div className="mx-auto px-4 sm:px-6 py-6 sm:py-8 max-w-7xl">
        {/* Back Button */}
        <Link
          href="/member-dashboard"
          className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-700 mb-6 transition-colors"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          Back to Course
        </Link>

        {/* Module Header */}
        <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100 mb-8">
          <div className="flex items-start gap-6">
            <div className="w-16 h-16 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl font-bold text-white">{module.module_number}</span>
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-purple-950 mb-2">{module.title}</h1>
              <p className="text-purple-600 mb-4">{module.description}</p>
              <div className="flex flex-wrap gap-3">
                <span className="inline-flex items-center px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
                  {lessons.length} {lessons.length === 1 ? 'Lesson' : 'Lessons'}
                </span>
                <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                  {progress}% Complete
                </span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          {progress > 0 && (
            <div className="mt-6">
              <div className="w-full bg-purple-100 rounded-full h-3">
                <div
                  className="bg-purple-600 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-sm text-purple-600 mt-2">
                {completedLessons} of {lessons.length} lessons completed
              </p>
            </div>
          )}
        </div>

        {/* Lessons List */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-purple-950 mb-4">Lessons</h2>
          
          {lessons.length === 0 ? (
            <div className="bg-white rounded-xl p-12 shadow-sm border border-purple-100 text-center">
              <BookOpenIcon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-purple-950 mb-2">No Lessons Yet</h3>
              <p className="text-purple-600">Lessons for this module will be available soon.</p>
            </div>
          ) : (
            lessons.map((lesson, index) => {
              const isCompleted = false; // TODO: Check from lesson_progress
              const isLocked = index > 0 && !isCompleted; // First lesson always unlocked

              return (
                <div
                  key={lesson.id}
                  className={`bg-white rounded-xl p-6 shadow-sm border border-purple-100 transition-all ${
                    isLocked ? 'opacity-60' : 'hover:shadow-md'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                      isCompleted ? 'bg-green-500' : isLocked ? 'bg-gray-300' : 'bg-purple-600'
                    }`}>
                      {isCompleted ? (
                        <CheckCircleIcon className="w-6 h-6 text-white" />
                      ) : isLocked ? (
                        <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                      ) : (
                        <PlayIcon className="w-6 h-6 text-white" />
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-purple-950 mb-2">{lesson.title}</h3>
                      <p className="text-purple-600 mb-3">{lesson.description}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        <span className="inline-flex items-center px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-xs font-medium">
                          Lesson {lesson.lesson_number}
                        </span>
                        {isCompleted && (
                          <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                            ✓ Completed
                          </span>
                        )}
                        {isLocked && (
                          <span className="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
                            🔒 Locked
                          </span>
                        )}
                      </div>

                      {!isLocked && (
                        <Link
                          href={`/lesson-view?module=${moduleNumber}&lesson=${lesson.lesson_number}`}
                          className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
                        >
                          {isCompleted ? 'Review Lesson' : 'Start Lesson'}
                          <ArrowLeftIcon className="w-4 h-4 rotate-180" />
                        </Link>
                      )}
                      
                      {isLocked && (
                        <p className="text-sm text-gray-500 italic">Complete previous lessons to unlock</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

export default function ModuleView() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-[#FDFCFE] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-purple-600 font-medium">Loading module...</p>
        </div>
      </div>
    }>
      <ModuleViewContent />
    </Suspense>
  );
}