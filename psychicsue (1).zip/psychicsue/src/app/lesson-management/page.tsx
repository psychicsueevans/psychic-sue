// This file has been deleted as requested
// Lesson management is now part of /admin/courses