'use client';

import React from 'react';
import { CourseManagerInteractive } from './components/CourseManagerInteractive';

export default function CourseManagerPage() {
  return <CourseManagerInteractive />;
}