'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

import AuthNavigation from '@/components/common/AuthNavigation';
import MemberQuickActions from '@/components/common/MemberQuickActions';
import MobileNavToggle from '@/components/common/MobileNavToggle';
import MemberDashboardInteractive from './components/MemberDashboardInteractive';

function MemberDashboardContent() {
  const router = useRouter();

  // TEMPORARILY DISABLED FOR DEVELOPMENT - Uncomment when ready to enable authentication
  // useEffect(() => {
  //   // Check authentication status
  //   const isAuthenticatedLocal = localStorage.getItem('isAuthenticated');
  //   const isAuthenticatedSession = sessionStorage.getItem('isAuthenticated');

  //   if (!isAuthenticatedLocal && !isAuthenticatedSession) {
  //     // Redirect to login if not authenticated
  //     router.push('/member-login');
  //   }
  // }, [router]);

  return (
    <AuthNavigation isAuthenticated={true}>
      <MemberQuickActions hasNotifications={true} memberId="demo-member-123" />
      <MemberDashboardInteractive />
      <MobileNavToggle isAuthenticated={true} />
    </AuthNavigation>
  );
}

export default function MemberDashboardPage() {
  return <MemberDashboardContent />;
}