'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Module {
  id: number;
  title: string;
  completed: boolean;
  duration: string;
  lessons: number;
}

interface MembershipProgressProps {
  modules: Module[];
  overallProgress: number;
}

const MembershipProgress = ({ modules, overallProgress }: MembershipProgressProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
        <h2 className="text-2xl font-bold text-foreground mb-4">Course Progress</h2>
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-20 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  const completedModules = modules.filter(m => m.completed).length;
  const totalModules = modules.length;

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1">Course Progress</h2>
          <p className="text-sm text-muted-foreground">
            {completedModules} of {totalModules} modules completed
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-primary">{overallProgress}%</div>
          <p className="text-xs text-muted-foreground">Complete</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
          <div
            className="bg-gradient-to-r from-primary to-accent h-full rounded-full transition-all duration-500"
            style={{ width: `${overallProgress}%` }}
          ></div>
        </div>
      </div>

      <div className="space-y-3">
        {modules.map((module) => (
          <div
            key={module.id}
            className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-250 ${
              module.completed
                ? 'bg-success/10 border-success/20' :'bg-muted/50 border-border hover:border-primary/30'
            }`}
          >
            <div className="flex items-center gap-3 flex-1">
              <div
                className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  module.completed ? 'bg-success text-success-foreground' : 'bg-muted text-muted-foreground'
                }`}
              >
                {module.completed ? (
                  <Icon name="CheckIcon" size={20} variant="solid" />
                ) : (
                  <span className="font-bold text-sm">{module.id}</span>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-foreground">{module.title}</h3>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Icon name="ClockIcon" size={14} />
                    {module.duration}
                  </span>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Icon name="BookOpenIcon" size={14} />
                    {module.lessons} lessons
                  </span>
                </div>
              </div>
            </div>
            {!module.completed && (
              <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95">
                Continue
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-lg">
        <div className="flex items-start gap-3">
          <Icon name="LightBulbIcon" size={24} className="text-accent flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-foreground mb-1">Next Recommended Action</h4>
            <p className="text-sm text-muted-foreground">
              {completedModules === 0
                ? 'Start with Module 1: Introduction to Tarot Fundamentals to begin your journey'
                : completedModules === totalModules
                ? 'Congratulations! You\'ve completed all modules. Review your favorite lessons or book a reading with Sue'
                : `Continue with Module ${completedModules + 1} to maintain your learning momentum`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MembershipProgress;