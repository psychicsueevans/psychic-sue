'use client';

import { useState } from 'react';
import { QuestionMarkCircleIcon, ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/outline';

interface FAQ {
  id: number;
  category: string;
  question: string;
  answer: string;
}

const HelpTab = () => {
  const [expandedFAQs, setExpandedFAQs] = useState<Set<number>>(new Set());

  const toggleFAQ = (id: number) => {
    const newExpanded = new Set(expandedFAQs);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedFAQs(newExpanded);
  };

  // FAQ data organized by categories
  const faqs: FAQ[] = [
    // Membership & Billing
    {
      id: 1,
      category: 'Membership & Billing',
      question: 'How do I cancel my membership?',
      answer: 'You can cancel anytime from your dashboard. Go to the sidebar and click \'Manage Subscription\'. Your access continues until the end of your billing period.',
    },
    {
      id: 2,
      category: 'Membership & Billing',
      question: 'When will I be billed?',
      answer: 'Circle Members are billed monthly on the same date they joined. You can see your next billing date in the sidebar.',
    },
    {
      id: 3,
      category: 'Membership & Billing',
      question: 'Can I upgrade to VIP?',
      answer: 'VIP spaces are limited and open periodically. Join the waitlist and we\'ll notify you when a spot becomes available.',
    },
    // Course & Content
    {
      id: 4,
      category: 'Course & Content',
      question: 'How do I access the course?',
      answer: 'Click the \'Course\' tab in your dashboard. Start with Module 1 and work through at your own pace.',
    },
    {
      id: 5,
      category: 'Course & Content',
      question: 'Do I get a certificate?',
      answer: 'Yes! Complete all 8 modules and you\'ll receive a Certificate of Completion.',
    },
    {
      id: 6,
      category: 'Course & Content',
      question: 'How often is new content added?',
      answer: 'Sue adds new weekly messages every week, and new meditations and resources are added regularly.',
    },
    // Digital Readings
    {
      id: 7,
      category: 'Digital Readings',
      question: 'How do the digital readings work?',
      answer: 'Choose a category, pick a number from 0-21, and watch Sue\'s pre-recorded guidance video for that card. It\'s a way to receive instant tarot guidance anytime.',
    },
    {
      id: 8,
      category: 'Digital Readings',
      question: 'Can I do multiple digital readings?',
      answer: 'Yes! You can do as many as you like. Many members find it helpful to do a reading whenever they need guidance.',
    },
    // Technical
    {
      id: 9,
      category: 'Technical',
      question: 'I can\'t play the videos - what should I do?',
      answer: 'Try refreshing the page or using a different browser. If problems persist, email us and we\'ll help troubleshoot.',
    },
    {
      id: 10,
      category: 'Technical',
      question: 'How do I update my email or password?',
      answer: 'Click \'Manage Subscription\' in the sidebar to access your account settings.',
    },
  ];

  // Group FAQs by category
  const categories = Array.from(new Set(faqs.map((faq) => faq.category)));

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center flex-shrink-0">
          <QuestionMarkCircleIcon className="w-8 h-8 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-purple-950 mb-2">Help & Support</h1>
          <p className="text-purple-600">Got questions? We're here to help</p>
        </div>
      </div>

      {/* Quick Contact Box */}
      <div className="bg-purple-50 rounded-xl p-6 border border-purple-200">
        <h2 className="text-xl font-bold text-purple-950 mb-3">Need Personal Support?</h2>
        <p className="text-purple-900 mb-4">
          If you can't find your answer below, get in touch and we'll help you out.
        </p>
        <a
          href="mailto:psychicsueevans@gmail.com"
          className="inline-flex items-center text-purple-700 font-semibold hover:text-purple-800 transition-colors"
        >
          psychicsueevans@gmail.com
        </a>
        <p className="text-sm text-purple-600 mt-3">
          We typically respond within 24-48 hours
        </p>
      </div>

      {/* FAQ Section */}
      <div>
        <h2 className="text-2xl font-bold text-purple-950 mb-6">Frequently Asked Questions</h2>

        {categories.map((category) => (
          <div key={category} className="mb-8">
            <h3 className="text-lg font-bold text-purple-800 mb-4">{category}</h3>
            <div className="space-y-3">
              {faqs
                .filter((faq) => faq.category === category)
                .map((faq) => (
                  <div
                    key={faq.id}
                    className="bg-white rounded-lg border border-purple-200 overflow-hidden transition-all"
                  >
                    <button
                      onClick={() => toggleFAQ(faq.id)}
                      className="w-full flex items-center justify-between p-5 text-left hover:bg-purple-50 transition-colors"
                    >
                      <span className="font-semibold text-purple-950 pr-4">{faq.question}</span>
                      {expandedFAQs.has(faq.id) ? (
                        <ChevronUpIcon className="w-5 h-5 text-purple-600 flex-shrink-0" />
                      ) : (
                        <ChevronDownIcon className="w-5 h-5 text-purple-600 flex-shrink-0" />
                      )}
                    </button>
                    <div
                      className={`overflow-hidden transition-all duration-300 ease-in-out ${
                        expandedFAQs.has(faq.id) ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                      }`}
                    >
                      <div className="px-5 pb-5 pt-0 text-purple-900 leading-relaxed">
                        {faq.answer}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>

      {/* Still Need Help Section */}
      <div className="bg-white rounded-xl p-6 border-2 border-purple-200">
        <p className="text-purple-900 mb-4 text-center">
          Can't find what you're looking for?
        </p>
        <div className="flex justify-center">
          <a
            href="mailto:psychicsueevans@gmail.com"
            className="inline-block bg-purple-600 text-white font-semibold px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Contact Us
          </a>
        </div>
      </div>
    </div>
  );
};

export default HelpTab;