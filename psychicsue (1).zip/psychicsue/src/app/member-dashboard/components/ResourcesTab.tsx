'use client';

import { useState, useEffect } from 'react';
import { ArrowDownTrayIcon, DocumentIcon } from '@heroicons/react/24/outline';
import { resourceService } from '@/services/resourceService';
import type { Resource } from '@/types/admin.types';

type FilterType = 'All' | 'Journals' | 'Guides' | 'Workbooks' | 'Reference';

const ResourcesTab = () => {
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadResources();
  }, []);

  const loadResources = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await resourceService.getAllResources();
      
      if (fetchError) {
        setError('Failed to load resources. Please try again later.');
        return;
      }
      
      if (data) {
        setResources(data);
      }
    } catch (err) {
      setError('Failed to load resources. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const featuredResource = resources.find((r) => r.is_featured);
  const filters: FilterType[] = ['All', 'Journals', 'Guides', 'Workbooks', 'Reference'];

  const filteredResources = resources.filter((r) => {
    if (activeFilter === 'All') return true;
    return r.category.toLowerCase() === activeFilter.toLowerCase();
  });

  const handleDownload = (resourceUrl: string, resourceTitle: string) => {
    // Open the resource URL in a new tab
    window.open(resourceUrl, '_blank');
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return 'Unknown size';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const capitalizeCategory = (category: string) => {
    return category.charAt(0).toUpperCase() + category.slice(1).toLowerCase();
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center shadow-lg">
            <ArrowDownTrayIcon className="w-8 h-8 text-white" />
          </div>
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-2">Your Resources</h2>
          <p className="text-purple-600">Downloadable tools and guides to support your journey</p>
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="text-purple-600 mt-4">Loading resources...</p>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <p className="text-red-700">{error}</p>
          <button
            onClick={loadResources}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Featured Resource */}
      {!isLoading && !error && featuredResource && (
        <div className="bg-gradient-to-br from-purple-50 to-purple-100/50 rounded-xl p-6 sm:p-8 border border-purple-200 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
            <div className="flex-1">
              <span className="inline-block px-3 py-1 bg-purple-600 text-white text-xs font-semibold rounded-full mb-3">
                Essential
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-purple-950 mb-2">
                {featuredResource.title}
              </h3>
              {featuredResource.description && (
                <p className="text-purple-700 mb-4">{featuredResource.description}</p>
              )}
              <div className="flex items-center gap-2 text-sm text-purple-600 mb-4">
                <DocumentIcon className="w-4 h-4" />
                <span>
                  {featuredResource.file_type?.toUpperCase() || 'PDF'} • {formatFileSize(featuredResource.file_size)}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={() => handleDownload(featuredResource.file_url, featuredResource.title)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors shadow-md hover:shadow-lg"
          >
            <ArrowDownTrayIcon className="w-5 h-5" />
            Download
          </button>
        </div>
      )}

      {/* Resource Categories */}
      {!isLoading && !error && (
        <div>
          <h3 className="text-xl font-bold text-purple-950 mb-4">All Resources</h3>
          <div className="flex flex-wrap gap-2 mb-6">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeFilter === filter
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-white text-purple-700 border border-purple-200 hover:bg-purple-50'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Resource List */}
      {!isLoading && !error && (
        <div className="space-y-4">
          {filteredResources.length > 0 ? (
            filteredResources.map((resource) => (
              <div
                key={resource.id}
                className="bg-white rounded-xl p-6 border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                  {/* File Icon */}
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                      <DocumentIcon className="w-6 h-6 text-purple-600" />
                    </div>
                  </div>

                  {/* Resource Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-lg font-bold text-purple-950 mb-1">{resource.title}</h4>
                    {resource.description && (
                      <p className="text-sm text-purple-600 mb-3">{resource.description}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="inline-block px-3 py-1 bg-purple-50 text-purple-700 text-xs font-medium rounded-full">
                        {capitalizeCategory(resource.category)}
                      </span>
                      <span className="flex items-center gap-1 text-sm text-purple-500">
                        <DocumentIcon className="w-4 h-4" />
                        {resource.file_type?.toUpperCase() || 'PDF'} • {formatFileSize(resource.file_size)}
                      </span>
                    </div>
                  </div>

                  {/* Download Button */}
                  <div className="flex-shrink-0">
                    <button
                      onClick={() => handleDownload(resource.file_url, resource.title)}
                      className="inline-flex items-center gap-2 px-4 py-2 border-2 border-purple-600 text-purple-600 font-semibold rounded-lg hover:bg-purple-50 transition-colors"
                    >
                      <ArrowDownTrayIcon className="w-4 h-4" />
                      Download
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-purple-600">No resources found in this category.</p>
            </div>
          )}
        </div>
      )}

      {/* Empty State Message */}
      {!isLoading && !error && resources.length > 0 && (
        <div className="text-center py-8">
          <p className="text-purple-600">New resources are added regularly. Check back soon!</p>
        </div>
      )}

      {/* Empty State - No Resources */}
      {!isLoading && !error && resources.length === 0 && (
        <div className="text-center py-12">
          <ArrowDownTrayIcon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-purple-600 text-lg">No resources available yet. Check back soon!</p>
        </div>
      )}
    </div>
  );
};

export default ResourcesTab;