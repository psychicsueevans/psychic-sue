'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Booking {
  id: number;
  type: string;
  date: string;
  time: string;
  duration: string;
  hoursUntil: number;
  preparationMaterials: boolean;
}

interface UpcomingBookingsProps {
  bookings: Booking[];
}

const UpcomingBookings = ({ bookings }: UpcomingBookingsProps) => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [countdown, setCountdown] = useState<{ [key: number]: string }>({});

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (!isHydrated) return;

    const updateCountdowns = () => {
      const newCountdowns: { [key: number]: string } = {};
      bookings.forEach((booking) => {
        const hours = booking.hoursUntil;
        const days = Math.floor(hours / 24);
        const remainingHours = hours % 24;
        
        if (days > 0) {
          newCountdowns[booking.id] = `${days}d ${remainingHours}h`;
        } else if (hours > 0) {
          newCountdowns[booking.id] = `${hours}h`;
        } else {
          newCountdowns[booking.id] = 'Starting soon';
        }
      });
      setCountdown(newCountdowns);
    };

    updateCountdowns();
    const interval = setInterval(updateCountdowns, 60000);

    return () => clearInterval(interval);
  }, [bookings, isHydrated]);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
        <h2 className="text-2xl font-bold text-foreground mb-4">Upcoming Readings</h2>
        <div className="animate-pulse space-y-4">
          <div className="h-24 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground">Upcoming Readings</h2>
        {bookings.length > 0 && (
          <span className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
            {bookings.length} scheduled
          </span>
        )}
      </div>

      <div className="space-y-4">
        {bookings.length === 0 ? (
          <div className="text-center py-12">
            <Icon name="CalendarIcon" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground mb-4">No upcoming readings scheduled</p>
            <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95">
              Book Your Next Reading
            </button>
          </div>
        ) : (
          bookings.map((booking) => (
            <div
              key={booking.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg border border-border bg-gradient-to-r from-primary/5 to-accent/5 hover:border-primary/30 transition-all duration-250"
            >
              <div className="flex items-start gap-4 flex-1">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary text-primary-foreground flex-shrink-0">
                  <Icon name="SparklesIcon" size={24} variant="solid" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">{booking.type}</h3>
                  <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Icon name="CalendarIcon" size={16} />
                      {booking.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Icon name="ClockIcon" size={16} />
                      {booking.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <Icon name="VideoCameraIcon" size={16} />
                      {booking.duration}
                    </span>
                  </div>
                  {booking.preparationMaterials && (
                    <div className="mt-2 flex items-center gap-2 text-xs text-accent">
                      <Icon name="DocumentTextIcon" size={16} />
                      <span>Preparation materials available</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">{countdown[booking.id]}</div>
                  <p className="text-xs text-muted-foreground">until session</p>
                </div>
                <button className="px-4 py-2 bg-accent text-accent-foreground rounded-lg font-medium text-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95 whitespace-nowrap">
                  View Details
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default UpcomingBookings;