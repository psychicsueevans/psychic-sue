'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface WelcomeHeaderProps {
  memberName: string;
  membershipTier: string;
  renewalDate: string;
  daysUntilRenewal: number;
}

const WelcomeHeader = ({ memberName, membershipTier, renewalDate, daysUntilRenewal }: WelcomeHeaderProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) {
    return (
      <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 rounded-xl p-8 mb-8">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Welcome Back</h1>
            <p className="text-lg text-muted-foreground">Loading your membership details...</p>
          </div>
        </div>
      </div>
    );
  }

  const getTierColor = (tier: string) => {
    switch (tier.toLowerCase()) {
      case 'platinum':
        return 'bg-gradient-to-r from-purple-600 to-purple-800 text-white';
      case 'gold':
        return 'bg-gradient-to-r from-amber-500 to-amber-700 text-white';
      default:
        return 'bg-gradient-to-r from-primary to-secondary text-primary-foreground';
    }
  };

  const getRenewalStatus = () => {
    if (daysUntilRenewal <= 7) {
      return { color: 'text-warning', icon: 'ExclamationTriangleIcon', message: 'Renews soon' };
    } else if (daysUntilRenewal <= 30) {
      return { color: 'text-primary', icon: 'ClockIcon', message: 'Active' };
    }
    return { color: 'text-success', icon: 'CheckCircleIcon', message: 'Active' };
  };

  const renewalStatus = getRenewalStatus();

  return (
    <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 rounded-xl p-8 mb-8 shadow-sm">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            <Icon name="SparklesIcon" size={32} className="text-primary" />
            <h1 className="text-4xl font-bold text-foreground">Welcome Back, {memberName}</h1>
          </div>
          <p className="text-lg text-muted-foreground mb-4">
            Your spiritual journey continues with exclusive access to The Psychic Circle
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium shadow-sm ${getTierColor(membershipTier)}`}>
              <Icon name="StarIcon" size={20} variant="solid" />
              {membershipTier} Member
            </span>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Icon name={renewalStatus.icon as any} size={20} className={renewalStatus.color} />
              <span className="font-medium">{renewalStatus.message}</span>
            </div>
          </div>
        </div>
        <div className="bg-card rounded-lg p-6 shadow-sm border border-border min-w-[280px]">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="CalendarDaysIcon" size={20} className="text-primary" />
            <h3 className="font-semibold text-foreground">Membership Status</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-3">Your membership benefits</p>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Renewal Date:</span>
              <span className="font-medium text-foreground">{renewalDate}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Days Remaining:</span>
              <span className="font-bold text-primary">{daysUntilRenewal} days</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeHeader;