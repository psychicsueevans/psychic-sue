'use client';

import { useState, useEffect } from 'react';
import { PlayIcon, PauseIcon, HeartIcon } from '@heroicons/react/24/solid';
import { HeartIcon as HeartOutlineIcon } from '@heroicons/react/24/outline';
import { meditationService } from '@/services/meditationService';
import type { Meditation } from '@/types/admin.types';

type FilterType = 'All' | 'Relaxation' | 'Intuition' | 'Protection' | 'Sleep';

const MeditationsTab = () => {
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [playingMeditation, setPlayingMeditation] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [meditations, setMeditations] = useState<Meditation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMeditations();
  }, []);

  const loadMeditations = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await meditationService.getAllMeditations();
      
      if (fetchError) {
        setError('Failed to load meditations. Please try again later.');
        return;
      }
      
      if (data) {
        setMeditations(data);
      }
    } catch (err) {
      setError('Failed to load meditations. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const featuredMeditation = meditations.find((m) => m.is_featured);
  const filters: FilterType[] = ['All', 'Relaxation', 'Intuition', 'Protection', 'Sleep'];

  const filteredMeditations = meditations.filter((m) => {
    if (activeFilter === 'All') return true;
    return m.category.toLowerCase() === activeFilter.toLowerCase();
  });

  const handlePlayPause = (meditationId: string) => {
    if (playingMeditation === meditationId) {
      setPlayingMeditation(null);
    } else {
      setPlayingMeditation(meditationId);
    }
  };

  const toggleFavorite = (meditationId: string) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(meditationId)) {
      newFavorites.delete(meditationId);
    } else {
      newFavorites.add(meditationId);
    }
    setFavorites(newFavorites);
  };

  const formatDuration = (minutes: number | null) => {
    if (!minutes) return 'N/A';
    return `${minutes} mins`;
  };

  const capitalizeCategory = (category: string) => {
    return category.charAt(0).toUpperCase() + category.slice(1).toLowerCase();
  };

  return (
    <div className="space-y-6 pb-32">
      {/* Header Section */}
      <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center flex-shrink-0">
            <svg
              className="w-8 h-8 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
              />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-2">Guided Meditations</h1>
            <p className="text-purple-600">Relax, connect, and develop your intuition with Sue</p>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="text-purple-600 mt-4">Loading meditations...</p>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <p className="text-red-700">{error}</p>
          <button
            onClick={loadMeditations}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Featured Meditation */}
      {!isLoading && !error && featuredMeditation && (
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 sm:p-8 shadow-md border border-purple-200">
          <div className="mb-4">
            <span className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-full text-sm font-medium mb-3">
              Featured
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-2">
              {featuredMeditation.title}
            </h2>
            <div className="flex items-center gap-3 mb-4">
              <span className="text-sm font-medium text-purple-700">{formatDuration(featuredMeditation.duration_minutes)}</span>
              <span className="text-purple-400">•</span>
              <span className="text-sm text-purple-700">{capitalizeCategory(featuredMeditation.category)}</span>
            </div>
            {featuredMeditation.description && (
              <p className="text-purple-900 leading-relaxed mb-6">{featuredMeditation.description}</p>
            )}
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => handlePlayPause(featuredMeditation.id)}
              className="w-16 h-16 rounded-full bg-purple-600 hover:bg-purple-700 flex items-center justify-center shadow-lg hover:shadow-xl transition-all group"
            >
              {playingMeditation === featuredMeditation.id ? (
                <PauseIcon className="w-8 h-8 text-white" />
              ) : (
                <PlayIcon className="w-8 h-8 text-white ml-1" />
              )}
            </button>
            <button
              onClick={() => toggleFavorite(featuredMeditation.id)}
              className="p-3 rounded-full hover:bg-purple-200 transition-colors"
            >
              {favorites.has(featuredMeditation.id) ? (
                <HeartIcon className="w-6 h-6 text-purple-600" />
              ) : (
                <HeartOutlineIcon className="w-6 h-6 text-purple-600" />
              )}
            </button>
          </div>
        </div>
      )}

      {/* Meditation Library */}
      {!isLoading && !error && (
        <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
          <h2 className="text-2xl font-bold text-purple-950 mb-6">All Meditations</h2>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-2 mb-6">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeFilter === filter
                    ? 'bg-purple-600 text-white' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Meditation Grid */}
          {filteredMeditations.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredMeditations.map((meditation) => (
                <div
                  key={meditation.id}
                  className="bg-white rounded-lg p-5 border border-purple-200 hover:border-purple-300 hover:shadow-md transition-all"
                >
                  <div className="flex gap-4">
                    {/* Thumbnail */}
                    <div className="w-20 h-20 rounded-lg bg-gradient-to-br from-purple-400 to-purple-600 flex-shrink-0 flex items-center justify-center">
                      <svg
                        className="w-10 h-10 text-white opacity-50"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                        />
                      </svg>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-purple-950 mb-1 truncate">{meditation.title}</h3>
                      <div className="flex items-center gap-2 mb-3">
                        <span className="inline-flex items-center px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                          {formatDuration(meditation.duration_minutes)}
                        </span>
                        <span className="text-xs text-purple-600">{capitalizeCategory(meditation.category)}</span>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handlePlayPause(meditation.id)}
                          className="p-2 rounded-full border-2 border-purple-600 text-purple-600 hover:bg-purple-50 transition-colors"
                        >
                          {playingMeditation === meditation.id ? (
                            <PauseIcon className="w-4 h-4" />
                          ) : (
                            <PlayIcon className="w-4 h-4" />
                          )}
                        </button>
                        <button
                          onClick={() => toggleFavorite(meditation.id)}
                          className="p-2 rounded-full hover:bg-purple-50 transition-colors"
                        >
                          {favorites.has(meditation.id) ? (
                            <HeartIcon className="w-4 h-4 text-purple-600" />
                          ) : (
                            <HeartOutlineIcon className="w-4 h-4 text-purple-600" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="text-center py-12">
              <svg
                className="w-16 h-16 text-purple-300 mx-auto mb-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                />
              </svg>
              <p className="text-purple-600 text-lg">More meditations coming soon. Check back for new releases!</p>
            </div>
          )}
        </div>
      )}

      {/* Empty State - No Meditations */}
      {!isLoading && !error && meditations.length === 0 && (
        <div className="text-center py-12">
          <svg
            className="w-16 h-16 text-purple-300 mx-auto mb-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
            />
          </svg>
          <p className="text-purple-600 text-lg">No meditations available yet. Check back soon!</p>
        </div>
      )}
    </div>
  );
};

export default MeditationsTab;