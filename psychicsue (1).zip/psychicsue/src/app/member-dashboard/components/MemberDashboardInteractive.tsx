'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { SparklesIcon, CalendarIcon, BookOpenIcon, HeartIcon, HomeIcon } from '@heroicons/react/24/outline';
import AppImage from '@/components/ui/AppImage';
import Link from 'next/link';
import { courseService } from '@/services/courseService';
import type { ModuleWithLessons } from '@/types/course.types';


import WeeklyMessagesTab from '@/app/member-dashboard/components/WeeklyMessagesTab';
import MeditationsTab from '@/app/member-dashboard/components/MeditationsTab';
import DigitalReadingsTab from '@/app/member-dashboard/components/DigitalReadingsTab';
import ResourcesTab from '@/app/member-dashboard/components/ResourcesTab';
import HelpTab from '@/app/member-dashboard/components/HelpTab';
import VIPWaitlistPopup from '@/components/common/VIPWaitlistPopup';



type TabType = 'overview' | 'course' | 'weekly-messages' | 'meditations' | 'digital-readings' | 'resources' | 'help';

export default function MemberDashboardInteractive() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('overview');
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);
  const [showVIPView, setShowVIPView] = useState(false);
  const [isDemoAuth, setIsDemoAuth] = useState(false);
  const [demoUserName, setDemoUserName] = useState('');
  const [modules, setModules] = useState<ModuleWithLessons[]>([]);
  const [isLoadingModules, setIsLoadingModules] = useState(false);
  const [moduleError, setModuleError] = useState<string | null>(null);

  useEffect(() => {
    setIsHydrated(true);
    
    // Check for demo authentication
    const demoAuth = localStorage.getItem('demoAuth');
    const userName = localStorage.getItem('demoUserName');
    
    if (demoAuth === 'true') {
      setIsDemoAuth(true);
      setDemoUserName(userName || 'Guest');
      
      // Store membership tier in localStorage for MemberQuickActions to access
      // Default to Circle Member, but will change to VIP Member when showVIPView is true
      if (!localStorage.getItem('membershipTier')) {
        localStorage.setItem('membershipTier', 'Circle Member');
      }
    } else {
      // Redirect to login if not authenticated
      router.push('/member-login');
    }
  }, [router]);

  // Fetch modules from database
  useEffect(() => {
    if (activeTab === 'course') {
      loadModules();
    }
  }, [activeTab]);

  const loadModules = async () => {
    setIsLoadingModules(true);
    setModuleError(null);
    
    try {
      const { data, error } = await courseService.getModulesWithLessons();
      
      if (error) {
        setModuleError('Failed to load course modules. Please try again later.');
        return;
      }
      
      if (data) {
        setModules(data.filter(m => m.is_published));
      }
    } catch (err) {
      setModuleError('Failed to load course modules. Please try again later.');
    } finally {
      setIsLoadingModules(false);
    }
  };

  const handleLogout = () => {
    // Clear demo authentication
    localStorage.removeItem('demoAuth');
    localStorage.removeItem('demoUserEmail');
    localStorage.removeItem('demoUserName');
    
    // Redirect to login
    router.push('/member-login');
  };

  // Calculate stats based on actual module data
  const totalLessons = modules.reduce((acc, mod) => acc + (mod.published_lessons || 0), 0);
  const lessonsCompleted = 0; // TODO: Fetch from lesson_progress table
  const courseProgress = totalLessons > 0 ? Math.round((lessonsCompleted / totalLessons) * 100) : 0;

  const memberData = {
    name: demoUserName || 'Sarah Mitchell',
    tier: 'Circle Member',
    memberSince: 'October 2024',
    lessonsCompleted,
    totalLessons,
    courseProgress,
    meditationsPlayed: 8,
    daysAsMember: 94,
    nextBilling: 'March 1, 2025',
    messagesViewed: 15,
  };

  const tabs = [
    { id: 'overview' as TabType, label: 'Overview', icon: HomeIcon },
    { id: 'course' as TabType, label: 'Course' },
    { id: 'weekly-messages' as TabType, label: 'Weekly Messages' },
    { id: 'meditations' as TabType, label: 'Meditations' },
    { id: 'digital-readings' as TabType, label: 'Digital Readings' },
    { id: 'resources' as TabType, label: 'Resources' },
    { id: 'help' as TabType, label: 'Help' },
  ];

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-[#FDFCFE]">
        <div className="mx-auto px-6 py-8 max-w-7xl">
          <div className="animate-pulse space-y-8">
            <div className="h-40 bg-purple-100 rounded-xl"></div>
            <div className="h-64 bg-purple-100 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFCFE] pb-24 md:pb-8">
      <div className="mx-auto px-4 sm:px-6 py-6 sm:py-8 max-w-7xl">
        {/* Demo Auth Notice */}
        {isDemoAuth && (
          <div className="mb-6 bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                </svg>
                <div>
                  <p className="text-sm font-medium text-amber-900">Demo Mode Active</p>
                  <p className="text-xs text-amber-700 mt-1">
                    You're using temporary demo authentication. Real authentication will be implemented soon.
                  </p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="ml-4 text-sm font-medium text-amber-700 hover:text-amber-900 underline flex-shrink-0"
              >
                Logout
              </button>
            </div>
          </div>
        )}

        {/* Top Bar */}
        <div className="flex justify-end mb-6">
          <button
            onClick={() => {
              const newVIPView = !showVIPView;
              setShowVIPView(newVIPView);
              // Update membership tier in localStorage when switching views
              localStorage.setItem('membershipTier', newVIPView ? 'VIP Member' : 'Circle Member');
            }}
            className="px-4 py-2 text-sm font-medium text-purple-700 bg-white border border-purple-200 rounded-lg hover:bg-purple-50 transition-colors shadow-sm"
          >
            {showVIPView ? 'Switch to Member View' : 'Switch to VIP View'}
          </button>
        </div>

        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-purple-950 mb-4">
            Welcome Back, {memberData.name}
          </h1>
          <div className="flex flex-wrap gap-3">
            <span className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
              {memberData.tier}
            </span>
            <span className="inline-flex items-center px-4 py-2 bg-purple-50 text-purple-600 rounded-full text-sm">
              Member since {memberData.memberSince}
            </span>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
            <div className="text-2xl font-bold text-purple-950 mb-1">
              {memberData.lessonsCompleted} of {memberData.totalLessons}
            </div>
            <div className="text-sm text-purple-600">Lessons Completed</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
            <div className="text-2xl font-bold text-purple-950 mb-1">{memberData.courseProgress}%</div>
            <div className="text-sm text-purple-600 mb-3">Course Progress</div>
            <div className="w-full bg-purple-100 rounded-full h-2">
              <div
                className="bg-purple-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${memberData.courseProgress}%` }}
              ></div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
            <div className="text-2xl font-bold text-purple-950 mb-1">{memberData.meditationsPlayed}</div>
            <div className="text-sm text-purple-600">Meditations Played</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
            <div className="text-2xl font-bold text-purple-950 mb-1">{memberData.daysAsMember}</div>
            <div className="text-sm text-purple-600">Days as Member</div>
          </div>
        </div>

        {/* VIP Monthly Reading Section - Only shown in VIP View */}
        {showVIPView && (
          <div className="mb-8 space-y-4">
            {/* Your Monthly Reading */}
            <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl p-6 sm:p-8 shadow-lg text-white">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold mb-2">Your Monthly Reading</h2>
                  <div className="inline-flex items-center px-3 py-1 bg-green-500 text-white rounded-full text-sm font-medium">
                    Ready to Book
                  </div>
                </div>
              </div>
              
              <p className="text-purple-100 mb-4 text-base">
                60 minutes with Sue, included in your VIP membership
              </p>
              
              {/* TODO: Replace with actual Calendly link when integration is ready */}
              <a
                href="https://calendly.com/placeholder"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-white text-purple-700 font-bold py-3 px-6 rounded-lg hover:bg-purple-50 transition-colors mb-4"
              >
                Book Now
              </a>
              
              <p className="text-sm text-purple-200">
                You'll receive email confirmation and reminders once booked
              </p>
            </div>
          </div>
        )}

        {/* Priority Booking Banner - Shows for BOTH Circle Members and VIP */}
        <div className="mb-8">
          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 sm:p-8 shadow-lg text-white">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <CalendarIcon className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold mb-2">Priority Booking</h2>
                <p className="text-orange-100 mb-4">
                  {showVIPView 
                    ? 'As a VIP member, you get priority access to Sue\'s calendar for your monthly readings and any additional services.'
                    : 'Members get priority access when booking digital readings and other services. Book your reading and get same-day video responses.'}
                </p>
                <Link
                  href="/services-booking"
                  className="inline-block bg-white text-orange-700 font-bold py-3 px-6 rounded-lg hover:bg-orange-50 transition-colors"
                >
                  {showVIPView ? 'Book Now' : 'Book a Reading'}
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-8 border-b border-purple-200 overflow-x-auto">
          <div className="flex space-x-1 sm:space-x-2 min-w-max">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'text-white bg-purple-600 rounded-t-lg' : 'text-purple-600 hover:text-purple-700'
                }`}
              >
                {tab.icon && <tab.icon className="w-4 h-4" />}
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content - 2 Column Layout */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="lg:col-span-2 space-y-6">
              {/* Sue's Corner */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-purple-200 flex-shrink-0 overflow-hidden">
                    <AppImage
                      src="/assets/images/no_image.png"
                      alt="Sue - Psychic Circle founder and spiritual guide"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-purple-950 mb-1">Sue's Corner</h2>
                    <p className="text-sm text-purple-600">February 10, 2025</p>
                  </div>
                </div>
                <p className="text-purple-900 leading-relaxed">
                  Hi loves, this week I want you to focus on trusting your first instinct. When you get that
                  immediate feeling about something or someone, don't second-guess it. Your intuition is speaking to you, and it's usually right. Practice listening to that inner voice — it gets stronger the more you trust it. Remember, you're more psychic than you think you are. Love, Sue x
                </p>
              </div>

              {/* Card of the Week */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-2xl font-bold text-purple-950 mb-4">Card of the Week</h2>
                <div className="flex flex-col sm:flex-row gap-6">
                  <div className="w-full sm:w-48 h-80 bg-purple-100 rounded-lg flex-shrink-0 overflow-hidden">
                    <AppImage
                      src="/assets/images/no_image.png"
                      alt="The Tower tarot card showing dramatic transformation and sudden change"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-purple-950 mb-3">The Tower</h3>
                    <p className="text-purple-900 leading-relaxed">
                      Change is coming, and it might feel sudden or uncomfortable. But here's the truth — The Tower clears away what's no longer serving you. It's making space for something better. Don't resist
                      it. Trust that what's meant for you won't pass you by, and what's falling away needed to go.
                      This is transformation, not destruction.
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div>
                <h2 className="text-2xl font-bold text-purple-950 mb-4">Quick Actions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button className="bg-white rounded-xl p-6 shadow-sm border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all text-left group">
                    <BookOpenIcon className="w-8 h-8 text-purple-600 mb-3 group-hover:scale-110 transition-transform" />
                    <h3 className="font-bold text-purple-950 mb-1">Continue Course</h3>
                    <p className="text-sm text-purple-600">Module 3, Lesson 5</p>
                  </button>

                  <button className="bg-white rounded-xl p-6 shadow-sm border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all text-left group">
                    <SparklesIcon className="w-8 h-8 text-purple-600 mb-3 group-hover:scale-110 transition-transform" />
                    <h3 className="font-bold text-purple-950 mb-1">Weekly Messages</h3>
                    <p className="text-sm text-purple-600">New message available</p>
                  </button>

                  <button className="bg-white rounded-xl p-6 shadow-sm border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all text-left group">
                    <HeartIcon className="w-8 h-8 text-purple-600 mb-3 group-hover:scale-110 transition-transform" />
                    <h3 className="font-bold text-purple-950 mb-1">Meditation Library</h3>
                    <p className="text-sm text-purple-600">9 guided meditations</p>
                  </button>

                  <button className="bg-white rounded-xl p-6 shadow-sm border border-purple-100 hover:border-purple-300 hover:shadow-md transition-all text-left group">
                    <CalendarIcon className="w-8 h-8 text-purple-600 mb-3 group-hover:scale-110 transition-transform" />
                    <h3 className="font-bold text-purple-950 mb-1">Get Digital Reading</h3>
                    <p className="text-sm text-purple-600">Same-day video response</p>
                  </button>
                </div>
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Upgrade to VIP - Only shown for Circle Members */}
              {!showVIPView && (
                <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl p-6 shadow-lg text-white">
                  <h2 className="text-2xl font-bold mb-2">Upgrade to VIP</h2>
                  <p className="text-purple-100 mb-4 text-sm">Want monthly personal readings with Sue?</p>
                  <ul className="space-y-2 mb-6 text-sm">
                    <li className="flex items-start gap-2">
                      <span className="text-purple-300 mt-0.5">•</span>
                      <span>Monthly 60-min personal readings</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-purple-300 mt-0.5">•</span>
                      <span>Direct WhatsApp access to Sue</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-purple-300 mt-0.5">•</span>
                      <span>Priority booking & support</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-purple-300 mt-0.5">•</span>
                      <span>Everything in Circle included</span>
                    </li>
                  </ul>
                  <button
                    onClick={() => setIsWaitlistOpen(true)}
                    className="block w-full bg-white text-purple-700 font-bold py-3 px-4 rounded-lg hover:bg-purple-50 transition-colors text-center"
                  >
                    Join VIP Waitlist
                  </button>
                  <p className="text-xs text-purple-200 mt-3 text-center">Currently full — join the waitlist</p>
                </div>
              )}

              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Tier</span>
                    <span className="font-medium text-purple-950">{memberData.tier}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Status</span>
                    <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                      Active
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Next billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                </div>
                <button className="w-full mt-4 text-sm text-purple-700 font-medium hover:text-purple-800 transition-colors">
                  Manage Subscription
                </button>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="text-center py-8">
                  <HeartIcon className="w-12 h-12 text-purple-300 mx-auto mb-3" />
                  <p className="text-sm text-purple-600">No favourites saved yet</p>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Lessons completed</span>
                    <span className="font-bold text-purple-950">{memberData.lessonsCompleted}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Meditations played</span>
                    <span className="font-bold text-purple-950">{memberData.meditationsPlayed}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Messages viewed</span>
                    <span className="font-bold text-purple-950">{memberData.messagesViewed}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-purple-600">Days as member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'course' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Course Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Course Header */}
              <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-2">
                      8-Module Psychic Development Course
                    </h1>
                    <p className="text-purple-600">
                      The complete course that teaches you how to turn your gift into a career
                    </p>
                  </div>
                  <div className="text-center flex-shrink-0">
                    <div className="text-4xl sm:text-5xl font-bold text-purple-700">{courseProgress}%</div>
                    <div className="text-sm text-purple-600">Complete</div>
                  </div>
                </div>
                <div className="w-full bg-purple-100 rounded-full h-3 mb-2">
                  <div
                    className="bg-gradient-to-r from-green-500 to-purple-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${courseProgress}%` }}
                  ></div>
                </div>
                <p className="text-sm text-purple-600">{lessonsCompleted} of {totalLessons} lessons completed</p>
              </div>

              {/* Loading State */}
              {isLoadingModules && (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
                  <p className="text-purple-600 mt-4">Loading course modules...</p>
                </div>
              )}

              {/* Error State */}
              {moduleError && !isLoadingModules && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                  <p className="text-red-700">{moduleError}</p>
                  <button
                    onClick={loadModules}
                    className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {/* Module Cards Grid */}
              {!isLoadingModules && !moduleError && modules.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {modules.map((module, index) => {
                    const completedLessons = 0; // TODO: Calculate from lesson_progress
                    const progress = module.published_lessons > 0 
                      ? Math.round((completedLessons / module.published_lessons) * 100) 
                      : 0;
                    const isCompleted = progress === 100;
                    const isInProgress = progress > 0 && progress < 100;
                    const isNotStarted = progress === 0;

                    return (
                      <Link href={`/module-view?module=${module.module_number}`} key={module.id} className="block">
                        <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100 hover:shadow-md transition-shadow">
                          <div className="flex items-start gap-4 mb-4">
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                              isCompleted ? 'bg-green-500' : isInProgress ?'bg-purple-600': 'bg-gray-300'
                            }`}>
                              {isCompleted ? (
                                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                              ) : (
                                <span className={`font-bold text-lg ${
                                  isInProgress ? 'text-white' : 'text-gray-600'
                                }`}>{module.module_number}</span>
                              )}
                            </div>
                            <div className="flex-1">
                              <h3 className="text-lg font-bold text-purple-950 mb-1">{module.title}</h3>
                              <p className="text-sm text-purple-600 mb-2">{module.published_lessons} lessons</p>
                              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                                isCompleted ? 'bg-green-100 text-green-700' : isInProgress ?'border border-purple-600 text-purple-700': 'bg-gray-100 text-gray-600'
                              }`}>
                                {isCompleted ? '✓ Completed' : isInProgress ? 'In Progress' : 'Not Started'}
                              </span>
                            </div>
                          </div>
                          
                          {isInProgress && (
                            <div className="w-full bg-purple-100 rounded-full h-2 mb-3">
                              <div className="bg-purple-600 h-2 rounded-full" style={{ width: `${progress}%` }}></div>
                            </div>
                          )}
                          
                          <button className={`w-full font-medium py-2.5 px-4 rounded-lg transition-colors ${
                            isCompleted ? 'bg-purple-600 text-white hover:bg-purple-700' : isInProgress ? 'bg-purple-600 text-white hover:bg-purple-700': 'bg-white text-purple-600 border-2 border-purple-600 hover:bg-purple-50'
                          }`}>
                            {isCompleted ? 'Review Module' : isInProgress ? 'Continue' : 'Start Module'}
                          </button>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}

              {/* Empty State */}
              {!isLoadingModules && !moduleError && modules.length === 0 && (
                <div className="text-center py-12">
                  <BookOpenIcon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
                  <p className="text-purple-600 text-lg">No course modules available yet.</p>
                </div>
              )}

              {/* Certificate Section */}
              <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-xl p-6 sm:p-8 shadow-sm border border-orange-200">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 to-yellow-500 flex items-center justify-center flex-shrink-0">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-purple-950 mb-2">Earn Your Certificate</h2>
                    <p className="text-purple-900 mb-4">
                      Complete all 8 modules to receive your official Certificate of Completion
                    </p>
                    <p className="text-sm font-medium text-purple-700 mb-2">2 of 8 modules completed</p>
                    <div className="w-full bg-orange-200 rounded-full h-2.5 mb-3">
                      <div className="bg-gradient-to-r from-orange-500 to-yellow-500 h-2.5 rounded-full" style={{ width: '25%' }}></div>
                    </div>
                    <p className="text-sm text-purple-700 italic">
                      Keep going! You're 6 modules away from earning your certificate.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Sidebar - Same as Overview */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Messages Viewed</span>
                    <span className="font-bold text-purple-950">{memberData.messagesViewed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'weekly-messages' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Weekly Messages Content */}
            <div className="lg:col-span-2">
              <WeeklyMessagesTab />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Messages Viewed</span>
                    <span className="font-bold text-purple-950">{memberData.messagesViewed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'meditations' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Meditations Content */}
            <div className="lg:col-span-2">
              <MeditationsTab />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Meditations Played</span>
                    <span className="font-bold text-purple-950">{memberData.meditationsPlayed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'digital-readings' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Digital Readings Content */}
            <div className="lg:col-span-2">
              <DigitalReadingsTab />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Digital Readings Viewed</span>
                    <span className="font-bold text-purple-950">{memberData.messagesViewed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'resources' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Resources Content */}
            <div className="lg:col-span-2">
              <ResourcesTab />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'help' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Help Content */}
            <div className="lg:col-span-2">
              <HelpTab />
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Your Membership */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Membership</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Status</span>
                    <span className="font-medium text-purple-950">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Next Billing</span>
                    <span className="font-medium text-purple-950">{memberData.nextBilling}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Member Since</span>
                    <span className="font-medium text-purple-950">{memberData.memberSince}</span>
                  </div>
                </div>
              </div>

              {/* Your Favourites */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Favourites</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <HeartIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">5 Saved Meditations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <BookOpenIcon className="w-5 h-5 text-purple-600" />
                    <span className="text-sm text-purple-900">3 Bookmarked Lessons</span>
                  </div>
                </div>
              </div>

              {/* Your Stats */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-purple-100">
                <h2 className="text-xl font-bold text-purple-950 mb-4">Your Stats</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-600">Help Topics Viewed</span>
                    <span className="font-bold text-purple-950">{memberData.messagesViewed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-600">Days as Member</span>
                    <span className="font-bold text-purple-950">{memberData.daysAsMember}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Other Tab Content Placeholders */}
        {activeTab !== 'overview' && activeTab !== 'course' && activeTab !== 'digital-readings' && activeTab !== 'weekly-messages' && activeTab !== 'resources' && activeTab !== 'help' && (
          <div className="bg-white rounded-xl p-12 shadow-sm border border-purple-100 text-center">
            <h2 className="text-2xl font-bold text-purple-950 mb-2">
              {tabs.find((t) => t.id === activeTab)?.label}
            </h2>
            <p className="text-purple-600">Content coming soon...</p>
          </div>
        )}

        <VIPWaitlistPopup isOpen={isWaitlistOpen} onClose={() => setIsWaitlistOpen(false)} />
      </div>
    </div>
  );
}