'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Activity {
  id: number;
  type: 'message' | 'course' | 'announcement';
  title: string;
  description: string;
  timestamp: string;
  isNew: boolean;
}

interface RecentActivityProps {
  activities: Activity[];
}

const RecentActivity = ({ activities }: RecentActivityProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
        <h2 className="text-2xl font-bold text-foreground mb-4">Recent Activity</h2>
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 bg-muted rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'message':
        return { icon: 'ChatBubbleLeftRightIcon', color: 'text-primary' };
      case 'course':
        return { icon: 'AcademicCapIcon', color: 'text-accent' };
      case 'announcement':
        return { icon: 'MegaphoneIcon', color: 'text-warning' };
      default:
        return { icon: 'BellIcon', color: 'text-muted-foreground' };
    }
  };

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground">Recent Activity</h2>
        <span className="text-sm text-muted-foreground">Last 7 days</span>
      </div>

      <div className="space-y-4">
        {activities.length === 0 ? (
          <div className="text-center py-12">
            <Icon name="InboxIcon" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No recent activity</p>
          </div>
        ) : (
          activities.map((activity) => {
            const { icon, color } = getActivityIcon(activity.type);
            return (
              <div
                key={activity.id}
                className="flex items-start gap-4 p-4 rounded-lg border border-border hover:border-primary/30 hover:bg-muted/30 transition-all duration-250 cursor-pointer"
              >
                <div className={`flex items-center justify-center w-12 h-12 rounded-full bg-muted flex-shrink-0 ${color}`}>
                  <Icon name={icon as any} size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="font-semibold text-foreground">{activity.title}</h3>
                    {activity.isNew && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full bg-error text-error-foreground text-xs font-bold flex-shrink-0">
                        NEW
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{activity.description}</p>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Icon name="ClockIcon" size={14} />
                    {activity.timestamp}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {activities.length > 0 && (
        <button className="w-full mt-4 px-4 py-3 border border-border rounded-lg font-medium text-foreground hover:bg-muted hover:border-primary/30 transition-all duration-250">
          View All Activity
        </button>
      )}
    </div>
  );
};

export default RecentActivity;