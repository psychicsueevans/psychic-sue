'use client';

import { useState, useEffect } from 'react';
import { EnvelopeIcon } from '@heroicons/react/24/outline';
import { weeklyMessageService } from '@/services/weeklyMessageService';
import type { WeeklyMessage } from '@/types/admin.types';

const WeeklyMessagesTab = () => {
  const [expandedCurrentMessage, setExpandedCurrentMessage] = useState(false);
  const [expandedMessages, setExpandedMessages] = useState<Set<string>>(new Set());
  const [visibleCount, setVisibleCount] = useState(6);
  const [messages, setMessages] = useState<WeeklyMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMessages();
  }, []);

  const loadMessages = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await weeklyMessageService.getAllMessages();
      
      if (fetchError) {
        setError('Failed to load weekly messages. Please try again later.');
        return;
      }
      
      if (data) {
        setMessages(data);
      }
    } catch (err) {
      setError('Failed to load weekly messages. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const currentMessage = messages.find((m) => m.is_current);
  const pastMessages = messages.filter((m) => !m.is_current);
  const visiblePastMessages = pastMessages.slice(0, visibleCount);
  const hasMoreMessages = visibleCount < pastMessages.length;

  const toggleMessageExpansion = (messageId: string) => {
    const newExpanded = new Set(expandedMessages);
    if (newExpanded.has(messageId)) {
      newExpanded.delete(messageId);
    } else {
      newExpanded.add(messageId);
    }
    setExpandedMessages(newExpanded);
  };

  const loadMoreMessages = () => {
    setVisibleCount((prev) => prev + 6);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center flex-shrink-0">
            <EnvelopeIcon className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-purple-950 mb-2">Weekly Messages from Sue</h1>
            <p className="text-purple-600">Personal guidance and insights delivered every week</p>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="text-purple-600 mt-4">Loading messages...</p>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <p className="text-red-700">{error}</p>
          <button
            onClick={loadMessages}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Current Week Message */}
      {!isLoading && !error && currentMessage && (
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 sm:p-8 shadow-md border border-purple-200">
          <div className="mb-4">
            <span className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-full text-sm font-medium mb-3">
              This Week
            </span>
            <p className="text-sm text-purple-700 font-medium mb-2">{formatDate(currentMessage.published_date)}</p>
            <h2 className="text-2xl font-bold text-purple-950 mb-3">{currentMessage.title}</h2>
          </div>

          <div className="text-purple-900 leading-relaxed">
            {expandedCurrentMessage ? (
              <div className="space-y-4">
                {currentMessage.message_content.split('\n\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            ) : (
              <p className="line-clamp-3">{currentMessage.message_content}</p>
            )}
          </div>

          <button
            onClick={() => setExpandedCurrentMessage(!expandedCurrentMessage)}
            className="mt-4 inline-flex items-center px-6 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
          >
            {expandedCurrentMessage ? 'Show Less' : 'Read Full Message'}
          </button>
        </div>
      )}

      {/* Past Messages Section */}
      {!isLoading && !error && pastMessages.length > 0 && (
        <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-purple-100">
          <h2 className="text-2xl font-bold text-purple-950 mb-6">Previous Messages</h2>

          <div className="space-y-4">
            {visiblePastMessages.map((message) => {
              const isExpanded = expandedMessages.has(message.id);
              return (
                <div
                  key={message.id}
                  className="bg-white rounded-lg p-6 border border-purple-200 hover:border-purple-300 hover:shadow-md transition-all"
                >
                  <p className="text-sm text-purple-600 font-medium mb-2">{formatDate(message.published_date)}</p>
                  <h3 className="text-xl font-bold text-purple-950 mb-3">{message.title}</h3>

                  <div className="text-purple-900 leading-relaxed">
                    {isExpanded ? (
                      <div className="space-y-4">
                        {message.message_content.split('\n\n').map((paragraph, index) => (
                          <p key={index}>{paragraph}</p>
                        ))}
                      </div>
                    ) : (
                      <p className="line-clamp-2">{message.message_content}</p>
                    )}
                  </div>

                  <button
                    onClick={() => toggleMessageExpansion(message.id)}
                    className="mt-3 text-purple-700 font-medium hover:text-purple-800 transition-colors"
                  >
                    {isExpanded ? 'Show Less' : 'Read More →'}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Load More Button */}
          {hasMoreMessages && (
            <div className="mt-6 text-center">
              <button
                onClick={loadMoreMessages}
                className="px-6 py-3 bg-purple-100 text-purple-700 font-medium rounded-lg hover:bg-purple-200 transition-colors"
              >
                Load More Messages
              </button>
            </div>
          )}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && !error && messages.length === 0 && (
        <div className="bg-white rounded-xl p-12 shadow-sm border border-purple-100 text-center">
          <EnvelopeIcon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-purple-600 text-lg">
            Your message archive will grow each week. Check back soon!
          </p>
        </div>
      )}
    </div>
  );
};

export default WeeklyMessagesTab;