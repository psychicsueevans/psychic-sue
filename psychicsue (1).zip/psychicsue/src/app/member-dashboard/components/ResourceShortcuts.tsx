'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface Resource {
  id: number;
  title: string;
  type: 'meditation' | 'pdf' | 'video' | 'audio';
  thumbnail: string;
  alt: string;
  duration?: string;
  isNew: boolean;
}

interface ResourceShortcutsProps {
  resources: Resource[];
}

const ResourceShortcuts = ({ resources }: ResourceShortcutsProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
        <h2 className="text-2xl font-bold text-foreground mb-4">Quick Access Resources</h2>
        <div className="animate-pulse grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 bg-muted rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'meditation':
        return { icon: 'MusicalNoteIcon', color: 'text-primary' };
      case 'pdf':
        return { icon: 'DocumentTextIcon', color: 'text-accent' };
      case 'video':
        return { icon: 'VideoCameraIcon', color: 'text-warning' };
      case 'audio':
        return { icon: 'SpeakerWaveIcon', color: 'text-success' };
      default:
        return { icon: 'DocumentIcon', color: 'text-muted-foreground' };
    }
  };

  return (
    <div className="bg-card rounded-xl p-6 shadow-sm border border-border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground">Quick Access Resources</h2>
        <button className="text-sm text-primary font-medium hover:underline">View All</button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {resources.map((resource) => {
          const { icon, color } = getResourceIcon(resource.type);
          return (
            <div
              key={resource.id}
              className="group relative overflow-hidden rounded-lg border border-border hover:border-primary/30 hover:shadow-md transition-all duration-250 cursor-pointer"
            >
              <div className="relative h-40 overflow-hidden bg-muted">
                <AppImage
                  src={resource.thumbnail}
                  alt={resource.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-250"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                {resource.isNew && (
                  <span className="absolute top-2 right-2 inline-flex items-center px-2 py-1 rounded-full bg-error text-error-foreground text-xs font-bold">
                    NEW
                  </span>
                )}
                <div className="absolute bottom-2 left-2 flex items-center gap-2">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full bg-white/90 ${color}`}>
                    <Icon name={icon as any} size={18} />
                  </div>
                  {resource.duration && (
                    <span className="text-xs text-white font-medium bg-black/50 px-2 py-1 rounded">
                      {resource.duration}
                    </span>
                  )}
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-semibold text-foreground text-sm line-clamp-2">{resource.title}</h3>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-muted/50 rounded-lg border border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon name="FolderOpenIcon" size={24} className="text-primary" />
            <div>
              <h4 className="font-semibold text-foreground">Full Resource Library</h4>
              <p className="text-sm text-muted-foreground">Access all meditation recordings, PDFs, and exclusive content</p>
            </div>
          </div>
          <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-95 whitespace-nowrap">
            Browse All
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResourceShortcuts;