'use client';

import { Suspense } from 'react';
import AuthNavigation from '@/components/common/AuthNavigation';
import MobileNavToggle from '@/components/common/MobileNavToggle';
import ReadingProductPageContent from './components/ReadingProductPageContent';

export default function ReadingProductPage() {
  return (
    <AuthNavigation isAuthenticated={false}>
      <Suspense fallback={
        <div className="min-h-screen bg-background">
          <div className="mx-auto px-6 py-16">
            <div className="animate-pulse space-y-8">
              <div className="h-12 bg-muted rounded-lg w-1/3"></div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="h-96 bg-muted rounded-xl"></div>
                <div className="space-y-4">
                  <div className="h-8 bg-muted rounded"></div>
                  <div className="h-24 bg-muted rounded"></div>
                  <div className="h-48 bg-muted rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      }>
        <ReadingProductPageContent />
      </Suspense>
      <MobileNavToggle isAuthenticated={false} />
    </AuthNavigation>
  );
}