'use client';

import { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface Reading {
  id: string;
  title: string;
  price: string;
  deliveryTime: string;
  description: string;
  fullDescription: string;
  badge?: 'LIVE';
  image: string;
  alt: string;
}

const ReadingProductPageContent = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [reading, setReading] = useState<Reading | null>(null);
  const [questions, setQuestions] = useState('');
  const [charCount, setCharCount] = useState(0);
  const maxChars = 500;

  useEffect(() => {
    const readingParam = searchParams.get('reading');
    if (readingParam) {
      try {
        const decodedReading = JSON.parse(decodeURIComponent(readingParam));
        setReading(decodedReading);
      } catch (error) {
        console.error('Error parsing reading data:', error);
        router.push('/services-booking');
      }
    } else {
      router.push('/services-booking');
    }
  }, [searchParams, router]);

  const handleQuestionsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    if (text.length <= maxChars) {
      setQuestions(text);
      setCharCount(text.length);
    }
  };

  const handleBookNow = () => {
    if (!questions.trim()) {
      alert('Please tell me about your situation and questions before booking.');
      return;
    }

    alert(
      `Booking confirmed for ${reading?.title}!\n\nYour questions have been received. You will be redirected to payment and receive your reading details via email.`
    );
  };

  if (!reading) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-8">
      <div className="mx-auto px-6 py-12">
        <Link
          href="/services-booking"
          className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors duration-250 mb-8 group"
        >
          <Icon name="ArrowLeftIcon" size={20} className="group-hover:-translate-x-1 transition-transform duration-250" />
          <span className="font-medium">Back to All Readings</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          <div className="relative">
            <div className="sticky top-24">
              <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl">
                <AppImage
                  src={reading.image}
                  alt={reading.alt}
                  className="w-full h-full object-cover"
                />
                {reading.badge && (
                  <div className="absolute top-6 right-6 bg-amber-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                    {reading.badge}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                {reading.title}
              </h1>
              
              <div className="flex items-center space-x-6 mb-6">
                <div className="text-4xl font-bold text-primary">{reading.price}</div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Icon name="ClockIcon" size={20} />
                  <span className="text-lg">{reading.deliveryTime}</span>
                </div>
              </div>

              <div className="bg-card border-2 border-border rounded-xl p-6">
                <p className="text-foreground leading-relaxed text-lg">
                  {reading.fullDescription}
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-xl p-8 border-2 border-primary/20">
              <label htmlFor="questions" className="block text-lg font-semibold text-foreground mb-3">
                Your Questions & Situation
              </label>
              <p className="text-sm text-muted-foreground mb-4">
                The more detail you provide, the more accurate and helpful your reading will be.
              </p>
              <textarea
                id="questions"
                value={questions}
                onChange={handleQuestionsChange}
                placeholder="Tell me what's going on and what you want to know. The more detail you give me, the more accurate and helpful your reading will be..."
                className="w-full h-48 px-4 py-3 bg-background border-2 border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors duration-250 resize-none"
              />
              <div className="flex items-center justify-between mt-3">
                <span className="text-sm text-muted-foreground">
                  Be as specific as possible for the best guidance
                </span>
                <span className={`text-sm font-medium ${
                  charCount >= maxChars ? 'text-destructive' : 'text-muted-foreground'
                }`}>
                  {charCount}/{maxChars} characters
                </span>
              </div>
            </div>

            <button
              onClick={handleBookNow}
              className="w-full bg-primary text-primary-foreground py-5 rounded-xl font-semibold text-lg transition-all duration-250 hover:shadow-xl hover:-translate-y-1 active:scale-95 flex items-center justify-center space-x-3"
            >
              <Icon name="SparklesIcon" size={24} />
              <span>Book This Reading Now</span>
            </button>

            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-semibold text-foreground mb-3 flex items-center space-x-2">
                <Icon name="InformationCircleIcon" size={20} className="text-primary" />
                <span>What Happens Next</span>
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start space-x-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>Complete your booking and payment</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>I'll receive your questions and begin your reading</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>You'll receive your detailed reading within the timeframe shown</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-primary mt-0.5">•</span>
                  <span>Follow-up questions are welcome after you receive your reading</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReadingProductPageContent;