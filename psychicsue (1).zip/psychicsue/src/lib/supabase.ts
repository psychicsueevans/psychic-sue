'use client';
import { createClient } from '@supabase/supabase-js';

// Get Supabase URL and anon key from environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

// Validate that environment variables are set
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env file.');
}

// Create and export the Supabase client with proper auth configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
  global: {
    headers: {
      'x-application-name': 'psychic-sue-membership'
    }
  }
});

// Helper function to get current session
export const getCurrentSession = async () => {
  const { data: { session }, error } = await supabase?.auth?.getSession();
  return { session, error };
};

// Helper function to sign in (for admin/testing)
export const signInAnonymously = async () => {
  const { data, error } = await supabase?.auth?.signInAnonymously();
  return { data, error };
};