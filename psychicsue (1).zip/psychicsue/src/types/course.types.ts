export interface CourseModule {
  id: string;
  title: string;
  description: string | null;
  module_number: number;
  order_position: number;
  is_published: boolean;
  created_at: string;
}

export interface CourseLesson {
  id: string;
  title: string;
  description: string | null;
  video_url: string;
  duration_minutes: number | null;
  lesson_number: number;
  order_position: number;
  module_id: string;
  is_published: boolean;
  created_at: string;
  resource_url?: string | null;
  resource_title?: string | null;
}

export interface LessonProgress {
  id: string;
  lesson_id: string;
  member_id: string;
  is_completed: boolean;
  completed_at: string | null;
}

export interface ModuleWithLessons extends CourseModule {
  lessons?: CourseLesson[];
  total_lessons?: number;
  published_lessons?: number;
}

export interface InsertCourseModule {
  title: string;
  description?: string;
  module_number: number;
  order_position: number;
  is_published?: boolean;
}

export interface UpdateCourseModule {
  title?: string;
  description?: string;
  order_position?: number;
  is_published?: boolean;
}

export interface InsertCourseLesson {
  title: string;
  description?: string;
  video_url: string;
  duration_minutes?: number;
  lesson_number: number;
  order_position: number;
  module_id: string;
  is_published?: boolean;
  resource_url?: string;
  resource_title?: string;
}

export interface UpdateCourseLesson {
  title?: string;
  description?: string;
  video_url?: string;
  duration_minutes?: number;
  order_position?: number;
  is_published?: boolean;
  resource_url?: string;
  resource_title?: string;
}

export interface ContentStats {
  total_modules: number;
  published_modules: number;
  total_lessons: number;
  published_lessons: number;
  total_members: number;
  average_completion_rate: number;
}
function Lesson(...args: any[]): any {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: Lesson is not implemented yet.', args);
  return null;
}

export { Lesson };