// Weekly Messages Types
export interface WeeklyMessage {
  id: string;
  title: string;
  message_content: string;
  published_date: string;
  is_current: boolean;
  created_at: string;
}

export interface InsertWeeklyMessage {
  title: string;
  message_content: string;
  published_date: string;
  is_current?: boolean;
}

export interface UpdateWeeklyMessage {
  title?: string;
  message_content?: string;
  published_date?: string;
  is_current?: boolean;
}

// Meditations Types
export type MeditationCategory = 'relaxation' | 'intuition' | 'protection' | 'sleep';

export interface Meditation {
  id: string;
  title: string;
  description: string | null;
  audio_url: string;
  duration_minutes: number | null;
  category: MeditationCategory;
  is_featured: boolean;
  is_published: boolean;
  created_at: string;
}

export interface InsertMeditation {
  title: string;
  description?: string;
  audio_url: string;
  duration_minutes?: number;
  category: MeditationCategory;
  is_featured?: boolean;
  is_published?: boolean;
}

export interface UpdateMeditation {
  title?: string;
  description?: string;
  audio_url?: string;
  duration_minutes?: number;
  category?: MeditationCategory;
  is_featured?: boolean;
  is_published?: boolean;
}

// Resources Types
export type ResourceCategory = 'journals' | 'guides' | 'workbooks' | 'reference';
export type FileType = 'pdf';

export interface Resource {
  id: string;
  title: string;
  description: string | null;
  file_url: string;
  file_size: number | null;
  file_type: FileType;
  category: ResourceCategory;
  is_featured: boolean;
  is_published: boolean;
  created_at: string;
}

export interface InsertResource {
  title: string;
  description?: string;
  file_url: string;
  file_size?: number;
  file_type?: FileType;
  category: ResourceCategory;
  is_featured?: boolean;
  is_published?: boolean;
}

export interface UpdateResource {
  title?: string;
  description?: string;
  file_url?: string;
  file_size?: number;
  file_type?: FileType;
  category?: ResourceCategory;
  is_featured?: boolean;
  is_published?: boolean;
}

// Digital Readings Types
export type ReadingCategory = 'love_relationships' | 'general';

export interface DigitalReading {
  id: string;
  category: ReadingCategory;
  card_number: number;
  card_name: string;
  card_meaning: string | null;
  video_url: string;
  created_at: string;
}

export interface InsertDigitalReading {
  category: ReadingCategory;
  card_number: number;
  card_name: string;
  card_meaning?: string;
  video_url: string;
}

export interface UpdateDigitalReading {
  category?: ReadingCategory;
  card_number?: number;
  card_name?: string;
  card_meaning?: string;
  video_url?: string;
}

// Members Types
export type MembershipTier = 'circle_member' | 'vip';

export interface Member {
  id: string;
  full_name: string;
  email: string;
  membership_tier: MembershipTier;
  membership_start_date: string | null;
  membership_end_date: string | null;
  is_active: boolean;
  created_at?: string;
}

export interface InsertMember {
  full_name: string;
  email: string;
  membership_tier: MembershipTier;
  membership_start_date: string;
  membership_end_date?: string;
  is_active: boolean;
}

export interface UpdateMember {
  full_name?: string;
  email?: string;
  membership_tier?: MembershipTier;
  membership_start_date?: string;
  membership_end_date?: string;
  is_active?: boolean;
}

export interface ServiceResponse<T> {
  data: T | null;
  error: Error | null;
}

// Booking types
export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';
export type ReadingType = 'express' | 'general' | 'love_relationships' | 'money_career' | 'in_depth' | 'live_phone';

export interface Booking {
  id: string;
  member_id: string;
  reading_type: ReadingType;
  booking_date: string;
  status: BookingStatus;
  customer_questions?: string;
  special_requests?: string;
  payment_amount?: number;
  created_at: string;
  updated_at: string;
}

export interface ReadingHistory {
  id: string;
  booking_id: string;
  member_id: string;
  reading_date: string;
  reading_type: ReadingType;
  notes?: string;
  created_at: string;
}

export interface InsertBooking {
  member_id: string;
  reading_type: ReadingType;
  booking_date: string;
  status?: BookingStatus;
  customer_questions?: string;
  special_requests?: string;
  payment_amount?: number;
}

export interface UpdateBooking {
  reading_type?: ReadingType;
  booking_date?: string;
  status?: BookingStatus;
  customer_questions?: string;
  special_requests?: string;
  payment_amount?: number;
}

// Announcement types
export type AnnouncementDeliveryMethod = 'email' | 'dashboard' | 'both';

export interface Announcement {
  id: string;
  title: string;
  content: string;
  delivery_method: AnnouncementDeliveryMethod;
  is_sent: boolean;
  sent_at?: string;
  target_tier?: string;
  is_published: boolean;
  created_at: string;
  updated_at: string;
}

export interface InsertAnnouncement {
  title: string;
  content: string;
  delivery_method?: AnnouncementDeliveryMethod;
  target_tier?: string;
  is_published?: boolean;
}

export interface UpdateAnnouncement {
  title?: string;
  content?: string;
  delivery_method?: AnnouncementDeliveryMethod;
  target_tier?: string;
  is_published?: boolean;
}